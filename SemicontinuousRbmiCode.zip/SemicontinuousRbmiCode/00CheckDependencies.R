# Check dependencies and source syntax without running either analysis.
local({
  SourceFiles <- unlist(lapply(sys.frames(), function(Frame) Frame[["ofile"]]))
  Argument <- grep("^--file=", commandArgs(), value = TRUE)
  Path <- if (length(SourceFiles)) dirname(normalizePath(tail(SourceFiles, 1))) else
    if (length(Argument)) dirname(normalizePath(sub("^--file=", "", Argument[1]))) else "."
  Packages <- c("readxl", "ggplot2", "digest", "Rcpp", "RcppArmadillo", "posterior", "MASS", "jsonlite")
  Available <- vapply(Packages, requireNamespace, logical(1), quietly = TRUE)
  if (any(!Available)) stop("Install required packages: ", paste(Packages[!Available], collapse = ", "))
  Versions <- data.frame(Package = Packages,
    Version = vapply(Packages, function(Name) as.character(packageVersion(Name)), character(1)))
  print(Versions, row.names = FALSE)
  Files <- c(file.path(Path, "00CheckDependencies.R"),
    list.files(file.path(Path, "Application"), pattern = "[.]R$", recursive = TRUE, full.names = TRUE),
    list.files(file.path(Path, "Simulation"), pattern = "[.]R$", recursive = TRUE, full.names = TRUE))
  for (File in Files) parse(File)
  message("Dependencies available; ", length(Files), " R files parsed successfully.")
  message("C++17 compilation is checked by the numerical validation stages.")
})
