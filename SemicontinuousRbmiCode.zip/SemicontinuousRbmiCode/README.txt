SEMICONTINUOUS COPULA RBMI
Code supplement for The International Journal of Biostatistics
Release: 3 November 2026

This source distribution reproduces the EXALT application and the final
simulation study with 300 datasets per scenario and sample sizes 200 or 300.
Keep Application/ and Simulation/LargerSamples/ in their supplied locations.

START HERE
1. Extract the ZIP into a writable folder. Do not run files inside the ZIP.
2. Install R and a C++17 compiler compatible with R (Rtools on Windows).
   The release was checked with R 4.5.2 on Windows; see PackageVersions.csv.
3. Install the dependencies if needed:
   install.packages(c("readxl", "ggplot2", "digest", "Rcpp",
     "RcppArmadillo", "posterior", "MASS", "jsonlite"))
   PackageVersions.csv records tested versions; this command installs the
   versions available from the selected repository.
4. Set the R working directory to the extracted SemicontinuousRbmiCode folder.
   source("00CheckDependencies.R")
5. For the application, obtain the six EXALT input files described in
   DataSources.txt. The simulation and numerical validation need no trial data.

RUN THE APPLICATION
  source("Application/00RunAnalysis.R")

This runs preparation, numerical validation, model fitting, reporting, RBMI,
and publication exports. The four chains run sequentially. Individual stages
can also be run from a terminal, for example:
  Rscript --vanilla Application/00RunAnalysis.R --stage=Prepare
  Rscript --vanilla Application/00RunAnalysis.R --stage=Validate
  Rscript --vanilla Application/00RunAnalysis.R --stage=ValidateRbmi

See Application/00ReadMe.txt for the run order, output locations, and controls.

RUN THE SIMULATION
Before running, set Workers near the start of
Simulation/LargerSamples/01RunOvernight.R to suit the machine:
at most min(8, max(1, floor(0.7 * available logical cores))).
The default is eight workers and is rejected if it exceeds that limit.
Four chains run sequentially within each dataset worker.

  source("Simulation/LargerSamples/01RunOvernight.R")
  source("Simulation/LargerSamples/02RefreshReport.R")
  source("Simulation/LargerSamples/03ExportTables.R")

The first command prepares a fresh study and runs all four scenarios with
300 datasets each. Later invocations resume compatible checkpoints. The full
study is computationally substantial and may take several days, depending on
hardware and the sampling blocks needed. See the simulation readme for a
small commissioning run and separate numerical validation.

OUTPUTS AND REPRODUCIBILITY
Outputs are created inside the extracted folders. Application publication
outputs are in Application/Results/Paper. Simulation LaTeX tables and CSVs
are in Simulation/LargerSamples/Results/Tables. LaTeX and Overleaf are not
needed to fit either analysis or generate the tables.

The statistical implementation, priors, seeds, MCMC controls, and final
scenario plan match the manuscript programs. Release preparation removes
the unused COMBINE branch and private Overleaf export dependency. These
changes are described in ReleaseNotes.txt.

This ZIP contains source code and documentation, not participant data, saved
posterior draws, or completed simulation datasets. A fresh execution therefore
fits the models again. Keep generated checkpoints for resuming interrupted
runs. Never combine checkpoints from different versions or edit frozen
sources during a running study. Numerical differences across platforms and
package versions can affect adaptive chains and stopping times.

Checksums.sha256 records the supplied files (excluding itself).
ValidationSummary.txt describes checks of this release. The package does not
install software, download data, or upload files automatically.
