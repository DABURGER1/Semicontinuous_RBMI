# Stage 11. Publication outputs for the selected scheduled-visit EXALT analysis.
# Tables and figures are generated from the saved application summaries.
# This stage writes Results/Paper only. It does not edit or upload the manuscript.
CreatePaperOutputs <- function(ApplicationPath) {
  OutputPath <- file.path(ApplicationPath, "Results", "Paper")
  dir.create(OutputPath, recursive = TRUE, showWarnings = FALSE)
  View <- "TimingScreened"
  Label <- ApplicationGammaLabel()
  ResultPath <- file.path(ApplicationPath, "Results", "Rbmi", Label, "RbmiResults.rds")
  ParameterPath <- file.path(ApplicationPath, "Results", "Gamma", Label, "ParameterSummary.csv")
  PredictivePath <- file.path(ApplicationPath, "Results", "Gamma", Label, "Tables", "PredictiveChecks.csv")
  ChainPath <- file.path(ApplicationPath, "Results", "Gamma", Label, "Tables", "ChainSummary.csv")
  Result <- readRDS(ResultPath)
  Assert(identical(Result$Purpose, "EXALT under hypothetical survival"),
    "Paper outputs require the specified EXALT hypothetical survival analysis.")
  Assert(identical(Result$Data$ShapeStructure, "VisitSpecific"), "Paper outputs require visit-specific gamma shapes.")
  Primary <- Result$Summary
  PaperResults <- cbind(View = View, Primary)
  SaveTable(PaperResults, file.path(OutputPath, "RbmiResults.csv"))

  Numbers <- character()
  AddNumber <- function(Name, Value, Digits = 1) {
    # Ordinary LaTeX command names require letters; expand the numeric weights.
    Name <- gsub("100", "Full", Name, fixed = TRUE)
    Name <- gsub("50", "Half", Name, fixed = TRUE)
    Name <- gsub("0", "None", Name, fixed = TRUE)
    Assert(grepl("^[A-Za-z]+$", Name), paste("Invalid LaTeX command name:", Name))
    Assert(length(Value) == 1 && is.finite(Value), paste("Invalid paper value:", Name))
    Numbers <<- c(Numbers, sprintf("\\newcommand{\\%s}{%s}", Name, formatC(Value, format = "f", digits = Digits)))
  }
  for (Row in seq_len(nrow(Primary))) {
    for (Field in c("Estimate", "Lower", "Upper")) {
      AddNumber(paste0("Primary", Primary$Rule[Row], Field), Primary[[Field]][Row])
    }
  }
  AddNumber("MaximumPointMcsePercent", 100*max(Primary$McseFraction), 2)
  AddNumber("MaximumVarianceMcsePercent", 100*max(Primary$VarianceMcseFraction), 2)
  AddNumber("MaximumRbmiRhat", max(Primary$MaximumRhat), 4)
  AddNumber("MinimumRbmiBulkEss", min(Primary$MinimumBulkEss), 0)
  AddNumber("MinimumRbmiTailEss", min(Primary$MinimumTailEss), 0)
  AddNumber("CompletionsPerRule", unique(Primary$Imputations), 0)
  Parameters <- read.csv(ParameterPath)
  AddNumber("MaximumFitRhat", max(Parameters$Rhat), 4)
  AddNumber("MinimumFitBulkEss", min(Parameters$BulkEss), 0)
  AddNumber("MinimumFitTailEss", min(Parameters$TailEss), 0)
  Chains <- read.csv(ChainPath)
  Predictive <- read.csv(PredictivePath)
  AddNumber("ApplicationChains", nrow(Chains), 0)
  AddNumber("ApplicationDrawsPerChain", unique(Chains$Draws), 0)
  AddNumber("ApplicationMonitoredQuantities", nrow(Parameters), 0)
  AddNumber("ApplicationPredictiveSummaries", nrow(Predictive), 0)
  AddNumber("ApplicationPredictiveWithin", sum(!Predictive$OutsideInterval), 0)
  for (Name in c("AbstinenceOddsRatio", "PositiveMeanRatio", "AdjacentCorrelation")) {
    Parameter <- Parameters[Parameters$Parameter == Name, ]
    Assert(nrow(Parameter) == 1, "A model summary is missing.")
    for (Field in c("Median", "Lower", "Upper")) {
      AddNumber(paste0("Application", Name, Field), Parameter[[Field]], 2)
    }
  }
  FinalTail <- subset(Predictive, Group == "All participants" &
    Metric == "Positive 90th percentile (g)" & Week == max(Result$Data$Weeks))
  Assert(nrow(FinalTail) == 1, "The final predictive tail summary is missing.")
  for (Field in c("Observed", "Median", "Lower", "Upper")) {
    AddNumber(paste0("ApplicationFinalTail", Field), FinalTail[[Field]], 0)
  }
  writeLines(Numbers, file.path(OutputPath, "RbmiNumbers.tex"))

  Rows <- vapply(seq_len(nrow(Primary)), function(Index) paste0(
    paste(c(formatC(Primary$ZeroWeight[Index], format = "f", digits = 1),
      formatC(Primary$PositiveWeight[Index], format = "f", digits = 1),
      formatC(unlist(Primary[Index, c("Estimate", "Lower", "Upper")]), format = "f", digits = 1)),
      collapse = " & "), " \\\\"), character(1))
  writeLines(c(r"(\begin{table}[htbp]
\caption{Sensitivity of the adjusted mean difference in alcohol consumption at week~26 to reference borrowing.}
\label{tab:rbmi}
\centering
\begingroup
\small
\setlength{\tabcolsep}{5pt}
\begin{tabular}{@{}S[table-format=1.1]S[table-format=1.1]S[table-format=-3.1]S[table-format=-3.1]S[table-format=3.1]@{}}
\toprule
 & & & \multicolumn{2}{c@{}}{\TableHeading{95\% Rubin interval}}\\
\cmidrule(l){4-5}
{\TableHeading{$\omega_0$}} & {\TableHeading{$\omega_+$}} & {\TableHeading{Difference, g}} & {\TableHeading{Lower}} & {\TableHeading{Upper}}\\
\midrule)", Rows, r"(\bottomrule
\end{tabular}
\par\smallskip
\begin{minipage}{\textwidth}
\footnotesize\justifying
Differences compare exenatide with placebo and include zero amounts; negative values indicate lower consumption with exenatide. Amounts refer to the intended preceding 30 days. The weights $\left(\omega_0,\omega_+\right)$ remove the indicated fractions of the treatment coefficients for abstinence and positive amount at eligible missing visits. The rule $\left(0,0\right)$ retains both treatment effects and $\left(1,1\right)$ replaces both marginal components by their reference counterparts. Each rule uses \num[group-digits=integer]{\CompletionsPerRule} completions, with baseline adjustment, HC3 variances augmented for empirical standardization, and Rubin pooling as in \autoref{sec:analysis} and \autoref{sec:pooling}.
\end{minipage}
\endgroup
\end{table})"), file.path(OutputPath, "RbmiTable.tex"))

  ModelNames <- c("AbstinenceOddsRatio", "PositiveMeanRatio",
    paste0("GammaShapeWeek", Result$Data$Weeks), "AdjacentCorrelation")
  ModelLabels <- c("Abstinence odds ratio", "Positive mean ratio",
    paste0("Gamma shape at week~", Result$Data$Weeks), "Adjacent latent correlation")
  ModelRows <- vapply(seq_along(ModelNames), function(Index) {
    Values <- unlist(Parameters[Parameters$Parameter == ModelNames[Index],
      c("Median", "Lower", "Upper")], use.names = FALSE)
    Assert(length(Values) == 3 && all(is.finite(Values)), "A model summary is missing.")
    paste0(paste(c(ModelLabels[Index], formatC(Values, format = "f", digits = 2)),
      collapse = " & "), " \\\\")
  }, character(1))
  writeLines(c(r"(\begin{table}[tbp]
\caption{Selected posterior summaries for the EXALT gamma copula model fitted to the observed data.}
\label{tab:model}
\centering
\begingroup
\small
\setlength{\tabcolsep}{5pt}
\begin{tabular}{@{}lS[table-format=1.2]S[table-format=1.2]S[table-format=1.2]@{}}
\toprule
 & & \multicolumn{2}{c@{}}{\TableHeading{95\% credible interval}}\\
\cmidrule(l){3-4}
{\TableHeading{Quantity}} & {\TableHeading{Median}} & {\TableHeading{Lower}} & {\TableHeading{Upper}}\\
\midrule)", ModelRows, r"(\bottomrule
\end{tabular}
\par\smallskip
\begin{minipage}{\textwidth}
\footnotesize\justifying
Intervals are equal-tailed posterior intervals. Treatment ratios compare exenatide with placebo at the same visit and baseline consumption. Gamma shapes vary by visit and are shared across treatments. The correlation is on the latent Gaussian scale between adjacent scheduled visits. All retained posterior draws contribute to these summaries.
\end{minipage}
\endgroup
\end{table})"), file.path(OutputPath, "ModelTable.tex"))

  # Export saved predictive summaries; this stage does not generate new replicates.
  # Keep punctuation next to each bound while siunitx aligns the decimal points.
  FormatPredictiveRow <- function(Label, Values, Digits) {
    Values <- formatC(Values, format = "f", digits = Digits)
    Values[3] <- paste0("{(}", Values[3], "{,}")
    Values[4] <- paste0(Values[4], "{)}")
    paste0(paste(c(Label, Values), collapse = " & "), " \\\\")
  }
  Marginal <- subset(Predictive, Group == "All participants" & Pair == "")
  PredictiveRows <- character()
  for (Metric in unique(Marginal$Metric)) {
    Heading <- switch(Metric, "Zero percent" = "Zero responses (\\%)", Metric)
    PredictiveRows <- c(PredictiveRows,
      paste0("\\multicolumn{5}{@{}l}{\\textit{", Heading, "}}\\\\"))
    Selected <- Marginal[Marginal$Metric == Metric, ]
    for (Row in seq_len(nrow(Selected))) {
      Values <- unlist(Selected[Row, c("Observed", "Median", "Lower", "Upper")])
      PredictiveRows <- c(PredictiveRows, FormatPredictiveRow(Selected$Week[Row], Values, 1))
    }
    PredictiveRows <- c(PredictiveRows, "\\addlinespace[3pt]")
  }
  writeLines(c(r"(\begin{table}[p]
\caption{Posterior predictive assessment of marginal summaries pooled across treatment arms in EXALT.}
\label{tab:applicationpredictive}
\centering
\begingroup
\small
\setlength{\tabcolsep}{5pt}
\sisetup{table-align-text-before=false,table-align-text-after=false}
\begin{tabular}{@{}S[table-format=2.0]S[table-format=4.1]S[table-format=4.1]@{\,}S[table-format={(}4.1{,}]@{\,}S[table-format=5.1{)}]@{}}
\toprule
{\TableHeading{Week}} & {\TableHeading{Observed}} & \multicolumn{3}{c@{}}{\TableHeading{Replicated (95\% range)}}\\
\midrule)", PredictiveRows, r"(\bottomrule
\end{tabular}
\par\smallskip
\begin{minipage}{\textwidth}
\footnotesize\justifying
Replicated entries are posterior predictive medians, with the 2.5th and 97.5th percentiles in parentheses. Each retained posterior draw generates one joint set of outcomes at the observed baseline and treatment values. The observed missingness pattern is then imposed before calculating the summaries; the dropout process is not simulated. Positive summaries exclude zeros, whereas the overall mean includes them. Amounts are in grams over the intended preceding 30 days. These pointwise predictive ranges describe replicated statistics and are not confidence intervals for treatment effects.
\end{minipage}
\endgroup
\end{table})"), file.path(OutputPath, "PredictiveTable.tex"))

  Dependence <- subset(Predictive, Pair != "")
  DependenceRows <- character()
  for (Metric in unique(Dependence$Metric)) {
    Heading <- switch(Metric,
      "Spearman: all available pairs" = "Spearman correlation, all available pairs",
      "Spearman: both positive" = "Spearman correlation, both amounts positive",
      "Next zero given previous zero (%)" = "Zero at the next visit given zero at the preceding visit (\\%)")
    DependenceRows <- c(DependenceRows,
      paste0("\\multicolumn{5}{@{}l}{\\textit{", Heading, "}}\\\\"))
    Selected <- Dependence[Dependence$Metric == Metric, ]
    Digits <- if (grepl("Spearman", Metric, fixed = TRUE)) 2 else 1
    for (Row in seq_len(nrow(Selected))) {
      Pair <- sub(" weeks", "", Selected$Pair[Row], fixed = TRUE)
      Pair <- sub(" to ", ", ", Pair, fixed = TRUE)
      Values <- unlist(Selected[Row, c("Observed", "Median", "Lower", "Upper")])
      DependenceRows <- c(DependenceRows, FormatPredictiveRow(Pair, Values, Digits))
    }
    DependenceRows <- c(DependenceRows, "\\addlinespace[3pt]")
  }
  writeLines(c(r"(\begin{table}[p]
\caption{Posterior predictive assessment of longitudinal associations in EXALT.}
\label{tab:applicationdependence}
\centering
\begingroup
\small
\setlength{\tabcolsep}{5pt}
\sisetup{table-align-text-before=false,table-align-text-after=false}
\begin{tabular}{@{}lS[table-format=3.2]S[table-format=3.2]@{\,}S[table-format={(}3.2{,}]@{\,}S[table-format=3.2{)}]@{}}
\toprule
{\TableHeading{Visit pair (weeks)}} & {\TableHeading{Observed}} & \multicolumn{3}{c@{}}{\TableHeading{Replicated (95\% range)}}\\
\midrule)", DependenceRows, r"(\bottomrule
\end{tabular}
\par\smallskip
\begin{minipage}{\textwidth}
\footnotesize\justifying
Replicated summaries and ranges are defined in \autoref{tab:applicationpredictive}. Correlations use participants observed at both visits, either including zeros or restricted to two positive amounts. The final panel gives the percentage with a zero at the later visit among those with a zero at the earlier visit and both visits observed. A replicated percentage is omitted when its denominator is zero; the corresponding summaries use at least 99\% of the replicated datasets. These checks pool participants across treatment arms.
\end{minipage}
\endgroup
\end{table})"), file.path(OutputPath, "DependenceTable.tex"))

  Data <- Result$Data
  Missingness <- data.frame(View = View, Week = Data$Weeks,
    Observed = colSums(!is.na(Data$Outcome)), Missing = colSums(is.na(Data$Outcome)),
    Zeros = colSums(Data$Outcome == 0, na.rm = TRUE))
  SaveTable(Missingness, file.path(OutputPath, "Missingness.csv"))
  Plot <- ggplot2::ggplot(Primary, ggplot2::aes(PositiveWeight, Estimate,
    colour = factor(ZeroWeight), group = ZeroWeight)) +
    ggplot2::geom_hline(yintercept = 0, linetype = "dashed", colour = "grey60") +
    ggplot2::geom_linerange(ggplot2::aes(ymin = Lower, ymax = Upper),
      position = ggplot2::position_dodge(width = .08)) +
    ggplot2::geom_line(position = ggplot2::position_dodge(width = .08)) +
    ggplot2::geom_point(position = ggplot2::position_dodge(width = .08), size = 2) +
    ggplot2::scale_x_continuous(breaks = c(0, .5, 1)) +
    ggplot2::scale_colour_manual(values = c("#174A7E", "#B35B16", "#1C7C54")) +
    ggplot2::theme_bw(base_size = 11) + ggplot2::theme(legend.position = "bottom") +
    ggplot2::labs(x = "Positive-amount borrowing weight",
      y = "Adjusted mean difference (grams)", colour = "Abstinence borrowing weight")
  for (Extension in c("pdf", "png")) {
    ggplot2::ggsave(file.path(OutputPath, paste0("SensitivityEstimates.", Extension)),
      Plot, width = 6.5, height = 4.8, dpi = 180, bg = "white")
  }
  for (Name in c("ZeroChecks", "AmountChecks", "DependenceChecks")) {
    Copied <- file.copy(file.path(ApplicationPath, "Results", "Gamma", Label, "Figures", paste0(Name, ".pdf")),
      file.path(OutputPath, paste0(Name, ".pdf")), overwrite = TRUE)
    Assert(Copied, "Could not copy a model-check figure.")
  }
  Inputs <- c(ResultPath, ParameterPath, PredictivePath, ChainPath, file.path(ApplicationPath, "11CreatePaperOutputs.R"))
  SaveTable(data.frame(Path = Inputs, Sha256 = vapply(Inputs, FileHash, character(1))),
    file.path(OutputPath, "InputManifest.csv"))
  writeLines(capture.output(sessionInfo()), file.path(OutputPath, "SessionInfo.txt"))
  message("Paper tables and figures saved to ", OutputPath, ".")
  invisible(PaperResults)
}
