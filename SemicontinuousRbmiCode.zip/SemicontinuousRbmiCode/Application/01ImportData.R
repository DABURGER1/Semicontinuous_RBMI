# Stage 01. Import original data through the main analysis entry point.
# Original source files are read only. All derived imports go to Imported/.
ImportData <- function(ApplicationPath) {
  ExaltDirectory <- file.path(ApplicationPath, "Raw", "EXALT", "Data")
  Files <- c(
    Alcohol = "total_alkohol_in_the_last_30days.xlsx",
    AbstinentDays = "zero_days.xlsx", HeavyDays = "Heavy drinking days.xlsx",
    Dropout = "Drop_outs.xlsx", Bmi = "BMI.xlsx"
  )
  ExaltSources <- lapply(Files, function(File) {
    as.data.frame(readxl::read_excel(file.path(ExaltDirectory, File),
      na = c("NA", ""), .name_repair = "minimal"
    ))
  })
  ExaltSources$Gender <- read.csv2(file.path(ExaltDirectory, "gender.csv"), na.strings = c("NA", ""))[, c("projekt_id", "gender")]
  for (Name in names(ExaltSources)) CheckKey(ExaltSources[[Name]], "projekt_id", paste("EXALT", Name))
  Assert(nrow(ExaltSources$Alcohol) == 127, "EXALT participant count changed; review source version")
  Assert(all(ExaltSources$Alcohol[["random_group"]] %in% 1 : 2), "EXALT treatment codes changed")
  for (Name in c("AbstinentDays", "HeavyDays", "Bmi")) {
    Pos <- match(ExaltSources$Alcohol[["projekt_id"]], ExaltSources[[Name]][["projekt_id"]])
    Assert(!anyNA(Pos), paste("Missing EXALT IDs in", Name))
    Assert(all(ExaltSources$Alcohol[["random_group"]] == ExaltSources[[Name]][["random_group"]][Pos]), paste("EXALT arm codes disagree in", Name))
  }
  saveRDS(ExaltSources, file.path(ApplicationPath, "Imported", "01ExaltSources.rds"))
  RawFiles <- list.files(file.path(ApplicationPath, "Raw"), full.names = TRUE, recursive = TRUE)
  Manifest <- data.frame(
    RelativePath = substring(normalizePath(RawFiles, winslash = "/"), nchar(ApplicationPath) + 2),
    Bytes = file.info(RawFiles)[["size"]],
    # Reading bytes avoids false file.access failures for
    # readable OneDrive files in restricted Windows sessions.
    Sha256 = vapply(RawFiles, function(File) {
      digest::digest(
        readBin(File, what = "raw", n = file.info(File)[["size"]]),
        serialize = FALSE, algo = "sha256"
      )
    }, character(1))
  )
  SaveTable(Manifest, file.path(ApplicationPath, "Results", "Tables", "01SourceFileManifest.csv"))
  invisible(NULL)
}
