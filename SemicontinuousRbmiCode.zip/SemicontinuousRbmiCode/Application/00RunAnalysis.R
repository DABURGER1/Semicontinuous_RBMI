# Main entry point. From RStudio: source("Application/00RunAnalysis.R").
# From a terminal: Rscript --vanilla Application/00RunAnalysis.R --stage=All
# Additional stages: ValidateRbmi, RbmiExample, Rbmi, RbmiReport, Paper. No packages are installed.
local({
  SourceFiles <- unlist(lapply(sys.frames(), function(Frame) Frame[["ofile"]]))
  ScriptArgument <- grep("^--file=", commandArgs(), value = TRUE)
  ApplicationPath <- if (length(SourceFiles)) {
    dirname(normalizePath(tail(SourceFiles, 1)))
  } else if (length(ScriptArgument)) {
    dirname(normalizePath(sub("^--file=", "", ScriptArgument[1])))
  } else {
    "Application"
  }
  source(file.path(ApplicationPath, "R", "LoadProject.R"), local = TRUE)
  LoadProject(ApplicationPath, environment())
  StageArgument <- grep("^--stage=", commandArgs(trailingOnly = TRUE), value = TRUE)
  Stage <- if (length(StageArgument)) sub("^--stage=", "", StageArgument[1]) else "All"
  Stages <- if (Stage == "All") {
    c("Prepare", "Validate", "Fit", "Report", "ValidateRbmi", "Rbmi", "RbmiReport", "Paper")
  } else Stage
  # Adapt these explicit controls when a different block size is required.
  Settings <- GammaSettings(
    BlockDraws = 4000, AdaptiveWarmup = 8000,
    MaxWarmupBlocks = 5, MaxSamplingBlocks = 5, Chains = 4
  )
  RunAnalysis(ApplicationPath, Stages, Settings)
})
