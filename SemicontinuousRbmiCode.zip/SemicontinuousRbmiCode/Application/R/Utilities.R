# Shared functions, loaded before the numbered analysis stages.
Assert <- function(Condition, Message) {
  if (!isTRUE(Condition)) stop(Message, call. = FALSE)
}
CheckKey <- function(Values, Key, Name) {
  Assert(!anyNA(Values[[Key]]) && !anyDuplicated(Values[[Key]]), paste(Name, "has missing/duplicate IDs"))
}
SaveTable <- function(Values, Path) {
  write.csv(Values, Path, row.names = FALSE, na = "", fileEncoding = "UTF-8")
}
SaveDataset <- function(Values, ApplicationPath, Stem) {
  saveRDS(Values, file.path(ApplicationPath, "Derived", paste0(Stem, ".rds")))
  SaveTable(Values, file.path(ApplicationPath, "Derived", paste0(Stem, ".csv")))
}
SafeMean <- function(Values) if (all(is.na(Values))) NA_real_ else mean(Values, na.rm = TRUE)
SafeSd <- function(Values) if (sum(!is.na(Values)) < 2) NA_real_ else sd(Values, na.rm = TRUE)
SafeQuantile <- function(Values, Probability) if (all(is.na(Values)) || !length(Values)) NA_real_ else unname(quantile(Values, Probability, na.rm = TRUE))
SummarizeOutcome <- function(Data, Value, Groups) {
  GroupId <- do.call(interaction, c(Data[Groups], list(drop = TRUE, lex.order = TRUE)))
  Result <- lapply(split(Data, GroupId), function(Subset) {
    Outcome <- Subset[[Value]]
    Count <- sum(!is.na(Outcome))
    Positive <- Outcome[!is.na(Outcome) & Outcome > 0]
    cbind(Subset[1, Groups, drop = FALSE], data.frame(
      NScheduled = nrow(Subset), NObserved = Count, NMissing = sum(is.na(Outcome)),
      NZero = sum(Outcome == 0, na.rm = TRUE), NPositive = length(Positive),
      MissingPercent = 100*mean(is.na(Outcome)),
      ZeroPercentObserved = if (Count) 100*sum(Outcome == 0, na.rm = TRUE)/Count else NA_real_,
      MeanAllObserved = SafeMean(Outcome), SdAllObserved = SafeSd(Outcome),
      MedianAllObserved = SafeQuantile(Outcome, .5),
      MeanPositive = SafeMean(Positive), MedianPositive = SafeQuantile(Positive, .5),
      P90Positive = SafeQuantile(Positive, .9), P95Positive = SafeQuantile(Positive, .95),
      MaxObserved = if (Count) max(Outcome, na.rm = TRUE) else NA_real_
    ))
  })
  Result <- do.call(rbind, Result)
  rownames(Result) <- NULL
  Result[do.call(order, Result[Groups]), , drop = FALSE]
}
ObservationPatterns <- function(Long, Id, Visit, Value, Arm) {
  Pieces <- split(Long, Long[[Id]])
  Result <- lapply(Pieces, function(Subset) {
    Subset <- Subset[order(Subset[[Visit]]), ]
    Observed <- !is.na(Subset[[Value]])
    LastPosition <- if (any(Observed)) max(which(Observed)) else 0
    data.frame(
      Id = as.character(Subset[[Id]][1]), Arm = as.character(Subset[[Arm]][1]),
      Pattern1Missing = paste(as.integer(!Observed), collapse = ""),
      NObserved = sum(Observed),
      LastObservedVisit = if (LastPosition) Subset[[Visit]][LastPosition] else NA_real_,
      NIntermittentMissing = sum(!Observed & seq_along(Observed) < LastPosition),
      NTrailingMissing = sum(!Observed & seq_along(Observed) > LastPosition)
    )
  })
  do.call(rbind, Result)
}
PanelMatrix <- function(Data, Ids, Visits, Value) {
  Matrix <- matrix(NA_real_,
    nrow = length(Ids), ncol = length(Visits),
    dimnames = list(as.character(Ids), paste0("Visit", Visits))
  )
  Rows <- match(Data$Id, Ids)
  Cols <- match(Data$Visit, Visits)
  Assert(!anyNA(Rows) && !anyNA(Cols), paste("Invalid panel key for", Value))
  Assert(!anyDuplicated(paste(Rows, Cols)), paste("Duplicate panel key for", Value))
  Matrix[cbind(Rows, Cols)] <- Data[[Value]]
  Matrix
}
HtmlEscape <- function(Values) {
  Values <- gsub("&", "&amp;", as.character(Values), fixed = TRUE)
  Values <- gsub("<", "&lt;", Values, fixed = TRUE)
  gsub(">", "&gt;", Values, fixed = TRUE)
}
HtmlTable <- function(Data, Digits = 2) {
  Data[] <- lapply(Data, function(Values) if (is.numeric(Values)) ifelse(is.na(Values), "", format(round(Values, Digits), trim = TRUE)) else ifelse(is.na(Values), "", as.character(Values)))
  Rows <- apply(Data, 1, function(Values) paste0("<tr><td>", paste(HtmlEscape(Values), collapse = "</td><td>"), "</td></tr>"))
  paste0(
    "<div class='table-wrap'><table><thead><tr><th>",
    paste(HtmlEscape(names(Data)), collapse = "</th><th>"),
    "</th></tr></thead><tbody>", paste(Rows, collapse = "\n"), "</tbody></table></div>"
  )
}


# Hash actual bytes so readable OneDrive files do not fail a preliminary
# file.access check in a restricted Windows session.
FileHash <- function(Path) {
  digest::digest(readBin(Path, what = "raw", n = file.info(Path)$size),
    algo = "sha256", serialize = FALSE
  )
}

SaveCheckpoint <- function(Object, Path) {
  Assert(!file.exists(Path), "A checkpoint already exists at the requested path.")
  TemporaryPath <- tempfile(pattern = "Checkpoint", tmpdir = dirname(Path), fileext = ".rds")
  on.exit(unlink(TemporaryPath), add = TRUE)
  saveRDS(Object, TemporaryPath, compress = "gzip")
  Assert(file.rename(TemporaryPath, Path), "Could not finalize the chain checkpoint.")
  invisible(Path)
}

CheckPackages <- function(Packages) {
  Missing <- Packages[!vapply(Packages, requireNamespace, logical(1), quietly = TRUE)]
  Assert(!length(Missing), paste("Install the required R packages:", paste(Missing, collapse = ", ")))
}
