# Convergence is assessed on every model coordinate and reported transformation.
# Every retained draw is used. The posterior package supplies rank-normalized
# split R-hat and bulk/tail effective sample sizes.
SummarizeDrawArray <- function(DrawArray) {
  Summary <- as.data.frame(posterior::summarise_draws(
    posterior::as_draws_array(DrawArray),
    Mean = mean, Median = median, Sd = sd,
    Lower = function(Values) unname(quantile(Values, .025)),
    Upper = function(Values) unname(quantile(Values, .975)),
    Rhat = posterior::rhat, BulkEss = posterior::ess_bulk,
    TailEss = posterior::ess_tail, McseMean = posterior::mcse_mean
  ))
  names(Summary)[1] <- "Parameter"
  Summary
}

MonitoredDrawArray <- function(Chains, ParameterNames) {
  Sizes <- vapply(Chains, function(Chain) nrow(Chain$Draws), numeric(1))
  Assert(
    length(Chains) >= 2 && length(unique(Sizes)) == 1 && Sizes[1] >= 4,
    "Convergence checks require equal chain lengths and at least four draws."
  )
  TransformNames <- c(
    "AbstinenceOddsRatio", "PositiveMeanRatio",
    sub("LogDispersion", "GammaShape", ParameterNames[13 : 16], fixed = TRUE),
    "AdjacentCorrelation", "BaselineAbstinenceOddsRatio", "BaselinePositiveMeanRatio"
  )
  DrawArray <- array(NA_real_, c(Sizes[1], length(Chains), 26),
    dimnames = list(NULL, paste0("Chain", seq_along(Chains)), c(ParameterNames, TransformNames))
  )
  for (Index in seq_along(Chains)) {
    Draws <- as.matrix(Chains[[Index]]$Draws)
    Assert(ncol(Draws) == 17 && all(is.finite(Draws)), "A chain contains invalid parameter draws.")
    DrawArray[, Index, 1 : 17] <- Draws
    DrawArray[, Index, 18 : 26] <- cbind(
      exp(Draws[, 5]), exp(Draws[, 11]),
      1/expm1(exp(2*Draws[, 13 : 16])), tanh(Draws[, 17]/2),
      exp(Draws[, 6]), exp(Draws[, 12])
    )
  }
  DrawArray
}

CheckMcmc <- function(Chains, ParameterNames, RhatLimit = 1.05, EssLimit = 400, Data = NULL) {
  DrawArray <- MonitoredDrawArray(Chains, ParameterNames)
  if (!is.null(Data)) {
    ProfileValues <- MarginalProfileValues(Chains, Data)
    Differences <- ProfileDifferenceArray(ProfileValues, nrow(Chains[[1]]$Draws), length(Chains), Data$Weeks)
    Combined <- array(NA_real_, c(dim(DrawArray)[1 : 2], dim(DrawArray)[3] + dim(Differences)[3]),
      dimnames = list(NULL, NULL, c(dimnames(DrawArray)[[3]], dimnames(Differences)[[3]]))
    )
    Combined[, , seq_len(dim(DrawArray)[3])] <- DrawArray
    Combined[, , dim(DrawArray)[3] + seq_len(dim(Differences)[3])] <- Differences
    DrawArray <- Combined
  }
  Summary <- SummarizeDrawArray(DrawArray)
  Summary$RhatPassed <- is.finite(Summary$Rhat) & Summary$Rhat <= RhatLimit
  Summary$BulkEssPassed <- is.finite(Summary$BulkEss) & Summary$BulkEss >= EssLimit
  Summary$TailEssPassed <- is.finite(Summary$TailEss) & Summary$TailEss >= EssLimit
  Summary$Converged <- Summary$RhatPassed & Summary$BulkEssPassed & Summary$TailEssPassed
  list(
    Summary = Summary, RhatPassed = all(Summary$RhatPassed),
    EssPassed = all(Summary$BulkEssPassed & Summary$TailEssPassed),
    Converged = all(Summary$Converged)
  )
}

CombineChainBlocks <- function(BlockSets) {
  Assert(length(BlockSets) > 0, "No sampling blocks are available.")
  lapply(seq_along(BlockSets[[1]]), function(Index) {
    Parts <- lapply(BlockSets, function(Blocks) Blocks[[Index]])
    Combined <- Parts[[length(Parts)]]
    for (Field in c("Draws", "LogVZeros")) {
      Combined[[Field]] <- do.call(rbind, lapply(Parts, function(Part) Part[[Field]]))
    }
    for (Field in c("LogAugmentedLikelihood", "LogPosterior")) {
      Combined[[Field]] <- unlist(lapply(Parts, function(Part) Part[[Field]]), use.names = FALSE)
    }
    Counts <- vapply(Parts, function(Part) nrow(Part$Draws), numeric(1))
    Combined$Acceptance <- Reduce(`+`, lapply(
      seq_along(Parts),
      function(Position) Parts[[Position]]$Acceptance*Counts[Position]
    ))/sum(Counts)
    Combined$ElapsedSeconds <- sum(vapply(Parts, function(Part) Part$ElapsedSeconds, numeric(1)))
    Combined$InvalidProposals <- sum(vapply(Parts, function(Part) Part$InvalidProposals, numeric(1)))
    Combined$SummarizedBlocks <- vapply(Parts, function(Part) Part$Block, numeric(1))
    Combined
  })
}


# Standardize both arms to the same empirical distribution of baseline values.
# The positive population mean is weighted by positive-outcome probabilities.
MarginalProfileValues <- function(Chains, Data) {
  Draws <- do.call(rbind, lapply(Chains, function(Chain) Chain$Draws))
  Values <- array(NA_real_, c(nrow(Draws), 2, 4, 3),
    dimnames = list(
      NULL, c("Placebo", "Exenatide"), as.character(Data$Weeks),
      c("AbstinencePercent", "OverallMeanGrams", "PositiveMeanGrams")
    )
  )
  for (Treatment in 0 : 1) {
    for (Visit in 1 : 4) {
      ZeroPredictor <- outer(Draws[, 6], Data$Design[, 2]) + Draws[, Visit] + Treatment*Draws[, 5]
      PositivePredictor <- outer(Draws[, 12], Data$Design[, 2]) + Draws[, 6 + Visit] + Treatment*Draws[, 11]
      PositiveProbability <- plogis(ZeroPredictor, lower.tail = FALSE)
      PositiveMean <- Data$UnitScale*exp(PositivePredictor)
      OverallMean <- rowMeans(PositiveProbability*PositiveMean)
      Values[, Treatment + 1, Visit, 1] <- 100*rowMeans(plogis(ZeroPredictor))
      Values[, Treatment + 1, Visit, 2] <- OverallMean
      Values[, Treatment + 1, Visit, 3] <- OverallMean/rowMeans(PositiveProbability)
    }
  }
  Values
}

ProfileDifferenceArray <- function(Values, Iterations, Chains, Weeks) {
  Names <- unlist(lapply(Weeks, function(Week) {
    paste0(
      c("AbstinenceDifferenceWeek", "OverallMeanDifferenceWeek", "PositiveMeanDifferenceWeek"), Week
    )
  }))
  Result <- array(NA_real_, c(Iterations, Chains, 12), dimnames = list(NULL, NULL, Names))
  Position <- 0
  for (Visit in 1 : 4) {
    for (Quantity in 1 : 3) {
      Position <- Position + 1
      Result[, , Position] <- array(Values[, 2, Visit, Quantity] - Values[, 1, Visit, Quantity], c(Iterations, Chains))
    }
  }
  Result
}
