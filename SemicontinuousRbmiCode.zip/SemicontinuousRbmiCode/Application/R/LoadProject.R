# Load definitions into the caller's environment. Loading performs no fitting,
# data writes, package installation, downloads or manuscript edits.
LoadProject <- function(ApplicationPath, TargetEnvironment = parent.frame()) {
  ApplicationPath <- normalizePath(ApplicationPath, winslash = "/", mustWork = TRUE)
  Modules <- c(
    "R/Utilities.R", "01ImportData.R", "02PrepareData.R", "03ExploreData.R",
    "04CreateModelInputs.R", "R/GammaModel.R", "R/McmcDiagnostics.R",
    "R/McmcController.R", "R/PredictiveChecks.R", "R/ModelReports.R",
    "05ValidateGammaSampler.R", "06FitGammaModel.R", "07SummarizeGammaModel.R",
    "R/GammaRbmi.R", "08ValidateRbmi.R", "09RunRbmi.R", "10SummarizeRbmi.R", "11CreatePaperOutputs.R"
  )
  for (Module in Modules) sys.source(file.path(ApplicationPath, Module), envir = TargetEnvironment)
  invisible(ApplicationPath)
}

RunAnalysis <- function(ApplicationPath, Stages = c("Prepare", "Validate", "Fit", "Report"),
                        Settings = GammaSettings()) {
  Assert(all(Stages %in% c("Prepare", "Validate", "Fit", "Report", "ValidateRbmi", "RbmiExample", "Rbmi", "RbmiReport", "Paper")), "Unknown analysis stage.")
  CheckPackages(c("readxl", "ggplot2", "digest", "Rcpp", "RcppArmadillo", "posterior", "MASS"))
  for (Folder in c("Imported", "Derived", "Results", "Results/Tables", "Results/Figures", "Results/Validation")) {
    dir.create(file.path(ApplicationPath, Folder), recursive = TRUE, showWarnings = FALSE)
  }
  if ("Prepare" %in% Stages) {
    message("Preparing the original EXALT data.")
    ImportData(ApplicationPath)
    PrepareData(ApplicationPath)
    ExploreData(ApplicationPath)
    CreateModelInputs(ApplicationPath)
    writeLines(capture.output(sessionInfo()), file.path(ApplicationPath, "Results", "PreparationSessionInfo.txt"))
  }
  if ("Validate" %in% Stages) ValidateGammaSampler(ApplicationPath)
  if ("Fit" %in% Stages) FitApplicationModels(ApplicationPath, Settings)
  if ("Report" %in% Stages) SummarizeApplicationModels(ApplicationPath)
  if ("ValidateRbmi" %in% Stages) ValidateRbmi(ApplicationPath)
  if ("RbmiExample" %in% Stages) RunRbmiExample(ApplicationPath, Settings)
  if ("Rbmi" %in% Stages) RunApplicationRbmi(ApplicationPath)
  if ("RbmiReport" %in% Stages) SummarizeRbmi(ApplicationPath)
  if ("Paper" %in% Stages) CreatePaperOutputs(ApplicationPath)
  invisible(NULL)
}
