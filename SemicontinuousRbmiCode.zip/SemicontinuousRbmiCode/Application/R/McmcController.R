# The first stage screens each new block using R-hat alone. Earlier blocks
# become warmup. The first passing block starts the retained sample. The second
# stage checks R-hat and ESS cumulatively, keeping that block and every later draw.
RunMcmcStages <- function(NextBlock, Diagnose, MaxWarmupBlocks = 5, MaxSamplingBlocks = 5) {
  Blocks <- list()
  History <- list()
  AddHistory <- function(Stage, Block, SummaryBlocks, Check) {
    Table <- Check$Summary
    FiniteMaximum <- function(Values) if (all(is.finite(Values))) max(Values) else NA_real_
    FiniteMinimum <- function(Values) if (all(is.finite(Values))) min(Values) else NA_real_
    History[[length(History) + 1]] <<- data.frame(
      Stage = Stage, Block = Block,
      FirstSummaryBlock = min(SummaryBlocks), LastSummaryBlock = max(SummaryBlocks),
      MaxRhat = FiniteMaximum(Table$Rhat), MinBulkEss = FiniteMinimum(Table$BulkEss),
      MinTailEss = FiniteMinimum(Table$TailEss), RhatPassed = Check$RhatPassed,
      EssPassed = Check$EssPassed, Converged = Check$Converged
    )
  }
  FirstPassingBlock <- NA_real_
  for (Block in seq_len(MaxWarmupBlocks)) {
    Blocks[[Block]] <- NextBlock(Block)
    Check <- Diagnose(Blocks[[Block]])
    AddHistory("WarmupScreen", Block, Block, Check)
    message("Warmup block ", Block, ": R-hat ", if (Check$RhatPassed) "passed." else "not yet passed.")
    if (Check$RhatPassed) {
      FirstPassingBlock <- Block
      break
    }
  }
  if (is.na(FirstPassingBlock)) {
    LastBlock <- length(Blocks)
    return(list(
      Chains = Blocks[[LastBlock]], Check = Check,
      History = do.call(rbind, History), FirstPassingBlock = NA_real_,
      WarmupBlocks = seq_len(LastBlock), RetainedBlocks = numeric(),
      SummaryBlocks = LastBlock, SummaryScope = "LatestBlockWithoutRhatPass",
      Converged = FALSE, Status = "WarmupLimitReached"
    ))
  }
  SummaryBlocks <- FirstPassingBlock
  for (StageBlock in seq_len(MaxSamplingBlocks)) {
    if (StageBlock > 1) {
      Block <- length(Blocks) + 1
      Blocks[[Block]] <- NextBlock(Block)
      SummaryBlocks <- c(SummaryBlocks, Block)
    }
    Chains <- CombineChainBlocks(Blocks[SummaryBlocks])
    Check <- Diagnose(Chains)
    AddHistory("RetainedSample", max(SummaryBlocks), SummaryBlocks, Check)
    message(
      "Retained block ", StageBlock, ": ",
      if (Check$Converged) "R-hat and ESS passed." else "more sampling is needed."
    )
    if (Check$Converged) break
  }
  list(
    Chains = Chains, Check = Check, History = do.call(rbind, History),
    FirstPassingBlock = FirstPassingBlock,
    WarmupBlocks = if (FirstPassingBlock > 1) seq_len(FirstPassingBlock - 1) else numeric(),
    RetainedBlocks = SummaryBlocks, SummaryBlocks = SummaryBlocks,
    SummaryScope = "AllRetainedDraws", Converged = Check$Converged,
    Status = if (Check$Converged) "Converged" else "SamplingLimitReached"
  )
}

FitGammaModel <- function(ApplicationPath, View = c("TimingScreened", "OriginalColumns"),
                          Label = NULL, Settings = GammaSettings()) {
  View <- match.arg(View)
  if (is.null(Label)) Label <- paste0(View, "VisitShape")
  Assert(grepl("^[A-Za-z][A-Za-z0-9]*$", Label), "Use a simple PascalCase fit label.")
  ApplicationPath <- normalizePath(ApplicationPath, winslash = "/", mustWork = TRUE)
  Data <- PrepareGammaData(ApplicationPath, View)
  OutputPath <- file.path(ApplicationPath, "Results", "Gamma", Label)
  dir.create(OutputPath, recursive = TRUE, showWarnings = FALSE)
  SourceHashes <- c(
    Sampler = FileHash(file.path(ApplicationPath, "src", "GammaCopula.cpp")),
    Model = FileHash(file.path(ApplicationPath, "R", "GammaModel.R")),
    Controller = FileHash(file.path(ApplicationPath, "R", "McmcController.R"))
  )
  KernelSettings <- Settings[setdiff(
    names(Settings),
    c("MaxWarmupBlocks", "MaxSamplingBlocks", "RhatLimit", "EssLimit")
  )]
  SamplingKey <- digest::digest(list(Data, KernelSettings, SourceHashes), algo = "sha256")
  LoadGammaCpp(ApplicationPath)
  Initial <- GammaInitialValues(Data)
  Previous <- vector("list", Settings$Chains)
  NextBlock <- function(Block) {
    Chunks <- vector("list", Settings$Chains)
    for (Chain in seq_len(Settings$Chains)) {
      Checkpoint <- file.path(OutputPath, sprintf("Chain%02dBlock%03d.rds", Chain, Block))
      ParentKey <- if (Block == 1) {
        NA_character_
      } else {
        digest::digest(
          list(Previous[[Chain]]$ChainState, Previous[[Chain]]$RngState),
          algo = "sha256"
        )
      }
      if (file.exists(Checkpoint)) {
        Saved <- readRDS(Checkpoint)
        Assert(
          identical(Saved$SamplingKey, SamplingKey),
          paste("Saved chain settings differ. Use a new label for", Label)
        )
        Assert(Saved$Chain == Chain && Saved$Block == Block && identical(Saved$ParentKey, ParentKey) &&
          nrow(Saved$Draws) == Settings$BlockDraws, "A saved chain block has inconsistent provenance.")
        Chunks[[Chain]] <- Saved
        Previous[[Chain]] <<- Saved
        next
      }
      if (Block == 1) {
        set.seed(Settings$Seed + 1009*Chain)
        Theta <- Initial$Theta
        Theta[1 : 16] <- Theta[1 : 16] + rnorm(16, sd = .25)
        Theta[17] <- qlogis((1 + seq(-.6, .8, length.out = Settings$Chains)[Chain])/2)
        Continuation <- NULL
        Warmup <- Settings$AdaptiveWarmup
      } else {
        assign(".Random.seed", Previous[[Chain]]$RngState, envir = .GlobalEnv)
        Theta <- Previous[[Chain]]$ChainState$Theta
        Continuation <- Previous[[Chain]]$ChainState
        Warmup <- 0
      }
      Started <- proc.time()[[3]]
      message(Label, ": chain ", Chain, ", block ", Block, ".")
      Chunk <- RunGammaChainCpp(
        Data$Outcome/Data$UnitScale, Data$Design, Data$Weeks,
        Theta, Settings$PriorMean, Settings$PriorSd, Initial$Covariances,
        Warmup, Settings$BlockDraws, Settings$AdaptEvery, Settings$ZeroSweeps,
        Settings$RhoA, Settings$RhoB, Continuation
      )
      colnames(Chunk$Draws) <- Data$ParameterNames
      Chunk$ElapsedSeconds <- proc.time()[[3]] - Started
      Chunk$Chain <- Chain
      Chunk$Block <- Block
      Chunk$SamplingKey <- SamplingKey
      Chunk$ParentKey <- ParentKey
      Chunk$RngState <- get(".Random.seed", envir = .GlobalEnv)
      Chunk$Seed <- Settings$Seed + 1009*Chain
      SaveCheckpoint(Chunk, Checkpoint)
      Chunks[[Chain]] <- Chunk
      Previous[[Chain]] <<- Chunk
    }
    Chunks
  }
  Diagnose <- function(Chains) CheckMcmc(Chains, Data$ParameterNames, Settings$RhatLimit, Settings$EssLimit, Data = Data)
  Sampling <- RunMcmcStages(NextBlock, Diagnose, Settings$MaxWarmupBlocks, Settings$MaxSamplingBlocks)
  Fit <- list(
    Data = Data, Settings = Settings, Label = Label, PositiveFamily = "Gamma",
    SamplingKey = SamplingKey, SourceHashes = SourceHashes, Chains = Sampling$Chains,
    Convergence = Sampling[setdiff(names(Sampling), "Chains")],
    ParameterSummary = Sampling$Check$Summary,
    SessionInfo = capture.output(sessionInfo()), Notes = Data$Notes
  )
  saveRDS(Fit, file.path(OutputPath, "Fit.rds"), compress = "gzip")
  SaveTable(Sampling$History, file.path(OutputPath, "ConvergenceHistory.csv"))
  SaveTable(Fit$ParameterSummary, file.path(OutputPath, "ParameterSummary.csv"))
  writeLines(Fit$SessionInfo, file.path(OutputPath, "SessionInfo.txt"))
  if (nrow(Data$Exclusions)) SaveTable(Data$Exclusions, file.path(OutputPath, "TimingExclusions.csv"))
  message(Label, ": ", Sampling$Status, "; ", nrow(Fit$Chains[[1]]$Draws), " draws per chain summarized.")
  invisible(Fit)
}
