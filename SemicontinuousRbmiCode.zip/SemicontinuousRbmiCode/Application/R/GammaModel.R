# Model specification and application data. All amounts are reported in grams.
# The sampler internally uses units of 1000 grams for stable coefficient scales.
GammaSettings <- function(BlockDraws = 4000, AdaptiveWarmup = 8000,
                          MaxWarmupBlocks = 5, MaxSamplingBlocks = 5,
                          Chains = 4, Seed = 20261022, NormalPriorSd = 5,
                          RhatLimit = 1.05, EssLimit = 400) {
  Counts <- c(BlockDraws, AdaptiveWarmup, MaxWarmupBlocks, MaxSamplingBlocks, Chains, Seed)
  Assert(all(is.finite(Counts)) && all(Counts == floor(Counts)), "Sampling settings must be whole numbers.")
  Assert(
    BlockDraws >= 20 && AdaptiveWarmup >= 0 && MaxWarmupBlocks >= 1 &&
      MaxSamplingBlocks >= 1 && Chains >= 2 && Seed >= 0 && Seed + 1009*Chains < .Machine$integer.max,
    "Sampling settings are outside their allowed ranges."
  )
  Assert(is.finite(NormalPriorSd) && NormalPriorSd > 0, "Specify a positive normal prior SD.")
  Assert(
    is.finite(RhatLimit) && RhatLimit > 1 && is.finite(EssLimit) && EssLimit > 0,
    "Specify valid convergence thresholds."
  )
  list(
    BlockDraws = BlockDraws, AdaptiveWarmup = AdaptiveWarmup,
    MaxWarmupBlocks = MaxWarmupBlocks, MaxSamplingBlocks = MaxSamplingBlocks,
    Chains = Chains, Seed = Seed, AdaptEvery = 50, ZeroSweeps = 2,
    RhatLimit = RhatLimit, EssLimit = EssLimit,
    ShapeStructure = "VisitSpecific", PriorMean = rep(0, 16),
    PriorSd = rep(NormalPriorSd, 16),
    RhoA = 1, RhoB = 1, CorrelationStructure = "VisitOrderAR1",
    PriorDescription = paste0(
      "Independent N(0,", NormalPriorSd, "^2) priors for every regression coefficient ",
      "and visit-specific log d; gamma shapes shared across arms. ",
      "Positive means use units of 1000 grams; adjacent-visit correlation Uniform(-1,1)."
    )
  )
}

GammaParameterNames <- function(Weeks) {
  c(
    paste0("ZeroInterceptWeek", Weeks), "ZeroTreatment", "ZeroBaseline",
    paste0("PositiveLogMeanWeek", Weeks), "PositiveTreatment", "PositiveBaseline",
    paste0("LogDispersionWeek", Weeks), "LogitScaledAdjacentCorrelation"
  )
}

PrepareGammaData <- function(ApplicationPath, View = c("TimingScreened", "OriginalColumns")) {
  View <- match.arg(View)
  Bundle <- readRDS(file.path(ApplicationPath, "Derived", "04ExaltModelInputs.rds"))
  Outcome <- Bundle$OutcomeViews$AsReported$Outcome
  Subjects <- Bundle$Subjects
  Exclusions <- list()
  AddExclusions <- function(Rows, Visit, Reason) {
    for (Row in Rows) {
      Exclusions[[length(Exclusions) + 1]] <<- data.frame(
        Id = Bundle$Id[Row],
        Visit = Visit, NominalWeek = Bundle$NominalWeek[Visit],
        Value = Outcome[Row, Visit], Reason = Reason
      )
    }
  }
  if (View == "TimingScreened") {
    UncertainFinal <- !is.na(Outcome[, 4]) &
      is.na(Bundle$OutcomeViews$FinalVisitTimingChecked$Outcome[, 4])
    AddExclusions(which(UncertainFinal), 4, "Final assessment timing unresolved")
    Outcome[UncertainFinal, 4] <- NA_real_
    for (Visit in seq_len(ncol(Outcome))) {
      OffSchedule <- !is.na(Outcome[, Visit]) &
        !is.na(Subjects$FinalAssessmentWeekMetadata) &
        !is.na(Subjects$LastRegularAssessmentWeek) &
        Subjects$FinalAssessmentWeekMetadata < 26 &
        Bundle$NominalWeek[Visit] > Subjects$LastRegularAssessmentWeek &
        Bundle$NominalWeek[Visit] != Subjects$FinalAssessmentWeekMetadata
      AddExclusions(which(OffSchedule), Visit, "Candidate early final assessment in a different nominal column")
      Outcome[OffSchedule, Visit] <- NA_real_
    }
  }
  Baseline <- log1p(Subjects$BaselineAlcoholGrams30Days)
  Assert(
    all(is.finite(Baseline)) && sd(Baseline) > 0 && !anyDuplicated(Bundle$Id),
    "Baseline values or participant identifiers are invalid."
  )
  Design <- cbind(
    Treatment = as.integer(Subjects$GroupCode == 2),
    Baseline = (Baseline - mean(Baseline))/sd(Baseline)
  )
  list(
    Outcome = Outcome, Design = Design, Id = Bundle$Id,
    GroupCode = Subjects$GroupCode, Weeks = as.numeric(Bundle$NominalWeek),
    UnitScale = 1000, View = View, BaselineCenter = mean(Baseline), BaselineScale = sd(Baseline),
    Exclusions = if (length(Exclusions)) do.call(rbind, Exclusions) else data.frame(),
    ParameterNames = GammaParameterNames(Bundle$NominalWeek), PositiveFamily = "Gamma",
    ShapeStructure = "VisitSpecific",
    TreatmentLabels = c("Placebo", "Exenatide"),
    Notes = c(
      "Observed-data model with independent visit-specific shapes shared across treatments.",
      "All 127 participants are retained. Those without follow-up supply no outcome likelihood.",
      "Treatment coding is corroborated: Group 1 is placebo; Group 2 is exenatide.",
      "Timing exclusions are an inferred analysis convention, not verified assessment-date corrections.",
      "Treatment-stop and death dates are unavailable; RBMI uses the agreed final-tail trigger and hypothetical survival."
    )
  )
}

GammaInitialValues <- function(Data) {
  Positions <- which(!is.na(Data$Outcome), arr.ind = TRUE)
  Frame <- data.frame(
    Outcome = Data$Outcome[Positions]/Data$UnitScale,
    Visit = factor(Positions[, 2], levels = 1 : 4),
    Treatment = Data$Design[Positions[, 1], 1], Baseline = Data$Design[Positions[, 1], 2]
  )
  Assert(
    any(Frame$Outcome == 0) && any(Frame$Outcome > 0),
    "Initialization requires observed zero and positive outcomes."
  )
  ZeroFit <- glm(I(Outcome == 0) ~ 0 + Visit + Treatment + Baseline, data = Frame, family = binomial())
  PositiveFit <- glm(Outcome ~ 0 + Visit + Treatment + Baseline,
    data = Frame[Frame$Outcome > 0, ], family = Gamma(link = "log")
  )
  PositiveRows <- Frame$Outcome > 0
  PositiveFrame <- Frame[PositiveRows, ]
  PositiveMeans <- fitted(PositiveFit)
  Shape <- vapply(1 : 4, function(Visit) {
    Selected <- as.integer(PositiveFrame$Visit) == Visit
    Assert(any(Selected), "Each visit needs positive observations for initialization.")
    Objective <- function(LogShape) {
      -sum(dgamma(PositiveFrame$Outcome[Selected], shape = exp(LogShape),
        scale = PositiveMeans[Selected]/exp(LogShape), log = TRUE))
    }
    exp(optimize(Objective, c(-5, 5))$minimum)
  }, numeric(1))
  Dispersion <- sqrt(log1p(1/Shape))
  Theta <- c(coef(ZeroFit), coef(PositiveFit), log(Dispersion), qlogis((1 + .8)/2))
  Assert(length(Theta) == 17 && all(is.finite(Theta)), "Initial regressions did not produce finite coefficients.")
  names(Theta) <- Data$ParameterNames
  RegularizeCovariance <- function(Covariance) {
    Decomposition <- eigen((Covariance + t(Covariance))/2, symmetric = TRUE)
    Decomposition$vectors %*% diag(
      pmin(2, pmax(Decomposition$values, 1e-4)),
      nrow(Covariance)
    ) %*% t(Decomposition$vectors)
  }
  PositiveCovariance <- diag(.02, 10)
  PositiveCovariance[1 : 6, 1 : 6] <- vcov(PositiveFit)
  list(Theta = Theta, Covariances = list(
    RegularizeCovariance(vcov(ZeroFit)),
    RegularizeCovariance(PositiveCovariance), matrix(.15)
  ))
}

LoadGammaCpp <- function(ApplicationPath) {
  Cache <- file.path(ApplicationPath, "Results", "CompilerCache")
  dir.create(Cache, recursive = TRUE, showWarnings = FALSE)
  Rcpp::sourceCpp(file.path(ApplicationPath, "src", "GammaCopula.cpp"),
    cacheDir = Cache, env = environment(LoadGammaCpp), showOutput = FALSE, verbose = FALSE
  )
  invisible(NULL)
}

# The selected scheduled-visit application has its own immutable fit namespace.
ApplicationGammaLabel <- function() "TimingScreenedVisitShape"
