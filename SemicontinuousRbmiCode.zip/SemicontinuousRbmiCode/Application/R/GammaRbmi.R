# Component-specific RBMI for the saved four-visit gamma copula fit.
# Eligibility is supplied explicitly: FALSE means that an outcome is undefined,
# not that a difficult missing value should be excluded from imputation.
RbmiRules <- function(Weights = c(0, .5, 1)) {
  Assert(is.numeric(Weights) && length(Weights) && all(is.finite(Weights)) &&
    all(Weights >= 0 & Weights <= 1) && !anyDuplicated(Weights), "Invalid borrowing weights.")
  Rules <- expand.grid(ZeroWeight = Weights, PositiveWeight = Weights)
  Rules$Rule <- paste0("Zero", format(100*Rules$ZeroWeight, trim = TRUE, scientific = FALSE), "Positive", format(100*Rules$PositiveWeight, trim = TRUE, scientific = FALSE))
  Rules$Rule[Rules$ZeroWeight == 0 & Rules$PositiveWeight == 0] <- "Continuation"
  Rules$Rule[Rules$ZeroWeight == 1 & Rules$PositiveWeight == 0] <- "AbstinenceReference"
  Rules$Rule[Rules$ZeroWeight == 0 & Rules$PositiveWeight == 1] <- "PositiveReference"
  Rules$Rule[Rules$ZeroWeight == 1 & Rules$PositiveWeight == 1] <- "JumpToReference"
  Rules[, c("Rule", "ZeroWeight", "PositiveWeight")]
}

RbmiSettings <- function(Seed = 20261022, Confidence = .95, ExampleCount = 1,
                         McseFractionLimit = .05, VarianceMcseFractionLimit = .05) {
  Assert(length(Seed) == 1 && is.finite(Seed) && Seed == floor(Seed) && Seed >= 0,
    "Use a nonnegative whole-number imputation seed.")
  Assert(length(ExampleCount) == 1 && is.finite(ExampleCount) && ExampleCount >= 0 &&
    ExampleCount == floor(ExampleCount), "Use a nonnegative whole-number example count.")
  Assert(length(Confidence) == 1 && is.finite(Confidence) && Confidence > 0 && Confidence < 1,
    "Specify a confidence level between zero and one.")
  Assert(all(is.finite(c(McseFractionLimit, VarianceMcseFractionLimit))) &&
    McseFractionLimit > 0 && VarianceMcseFractionLimit > 0, "Specify positive Monte Carlo precision limits.")
  list(Seed = Seed, Confidence = Confidence, ExampleCount = ExampleCount,
    McseFractionLimit = McseFractionLimit, VarianceMcseFractionLimit = VarianceMcseFractionLimit)
}

RbmiLayout <- function(Data, Eligibility) {
  Outcome <- Data$Outcome
  Assert(is.matrix(Outcome) && ncol(Outcome) == 4 &&
    all(is.na(Outcome) | (is.finite(Outcome) & Outcome >= 0)), "Invalid four-visit outcome matrix.")
  Assert(is.matrix(Eligibility) && is.logical(Eligibility) && identical(dim(Eligibility), dim(Outcome)) &&
    !anyNA(Eligibility), "Specify TRUE or FALSE outcome eligibility at every position.")
  Assert(all(Eligibility[!is.na(Outcome)]), "A retained observation cannot have an undefined outcome.")
  Assert(all(Eligibility[, 4]),
    "A final outcome is undefined. Resolve the estimand and analysis population before running RBMI.")
  Observed <- !is.na(Outcome)
  Trigger <- apply(Observed, 1, function(Values) 1 + max(c(0, which(Values))))
  Visits <- matrix(rep(1 : 4, each = nrow(Outcome)), nrow(Outcome), 4)
  Missing <- !Observed & Eligibility
  Borrow <- Missing & Visits >= Trigger
  list(Observed = Observed, Eligible = Eligibility, Missing = Missing, Borrow = Borrow,
    Trigger = Trigger, HasMissingFinal = any(Missing[, 4]))
}

RbmiAnalysisDesign <- function(Data) {
  Design <- Data$Design
  Assert(is.matrix(Design) && ncol(Design) == 2 && nrow(Design) == nrow(Data$Outcome) &&
    all(is.finite(Design)) && all(Design[, 1] %in% c(0, 1)), "Invalid treatment or baseline design.")
  Baseline <- Design[, 2] - mean(Design[, 2])
  Treatment <- Design[, 1]
  W <- cbind(Intercept = 1, Treatment = Treatment, Baseline = Baseline, Interaction = Treatment*Baseline)
  Decomposition <- qr(W)
  Assert(nrow(W) > ncol(W) && Decomposition$rank == ncol(W), "The completed-data design is not full rank.")
  Projection <- qr.coef(Decomposition, diag(nrow(W)))
  Leverage <- rowSums(W*t(Projection))
  Assert(all(is.finite(Projection)) && all(Leverage < 1 - 1e-10), "The completed-data design has excessive leverage.")
  StandardizationFactor <- sum(Baseline^2)/(nrow(W)*(nrow(W) - 1))
  list(Design = W, Projection = Projection, Leverage = Leverage,
    StandardizationFactor = StandardizationFactor, VarianceMethod = "HC3PlusEmpiricalStandardization",
    DfComplete = nrow(W) - ncol(W))
}

LoadRbmiCpp <- function(ApplicationPath) {
  Cache <- file.path(ApplicationPath, "Results", "CompilerCache")
  dir.create(Cache, recursive = TRUE, showWarnings = FALSE)
  Rcpp::sourceCpp(file.path(ApplicationPath, "src", "GammaRbmi.cpp"),
    cacheDir = Cache, env = environment(LoadRbmiCpp), showOutput = FALSE, verbose = FALSE)
  invisible(NULL)
}

CompleteRbmiChain <- function(Fit, Chain, Layout, Rules, Analysis, ExampleCount = 1) {
  Assert(all(c("Rule", "ZeroWeight", "PositiveWeight") %in% names(Rules)) && nrow(Rules) > 0 &&
    !anyNA(Rules$Rule) && !anyDuplicated(Rules$Rule) && all(nzchar(Rules$Rule)), "Invalid sensitivity-rule names.")
  Weights <- as.matrix(Rules[, c("ZeroWeight", "PositiveWeight")])
  Assert(is.numeric(Weights) && all(is.finite(Weights)) && all(Weights >= 0 & Weights <= 1),
    "Borrowing weights must lie between zero and one.")
  Assert(identical(colnames(Chain$Draws), Fit$Data$ParameterNames), "The parameter column order has changed.")
  Result <- CompleteGammaRbmiCpp(
    Fit$Data$Outcome, Fit$Data$Design, Fit$Data$Weeks, Fit$Data$UnitScale,
    Chain$Draws, Chain$LogVZeros, Chain$ZeroIndex, Layout$Eligible*1, Layout$Borrow*1,
    Weights, Analysis$Design, Analysis$Projection, Analysis$Leverage, ExampleCount)
  dimnames(Result$Statistics) <- list(NULL, Rules$Rule, c("Estimate", "WithinVariance",
    "UnadjustedDifference", "ReferenceMean", "ActiveMean", "ReferenceZero", "ActiveZero"))
  dimnames(Result$CoefficientVariance) <- dimnames(Result$StandardizationVariance) <- list(NULL, Rules$Rule)
  dim(Result$Examples) <- c(nrow(Fit$Data$Outcome), 4, nrow(Rules), ExampleCount)
  dimnames(Result$Examples) <- list(as.character(Fit$Data$Id), paste0("Week", Fit$Data$Weeks), Rules$Rule, NULL)
  Result
}

# A matrix has iterations in rows and chains in columns. Constant summaries
# have no imputation Monte Carlo error; they do not imply a zero sampling SE.
RbmiMonteCarlo <- function(Values) {
  Assert(is.matrix(Values) && all(is.finite(Values)), "Invalid Monte Carlo diagnostic input.")
  Constant <- diff(range(Values)) <= 1e-12*max(1, max(abs(Values)))
  if (Constant) return(c(Rhat = 1, BulkEss = length(Values), TailEss = length(Values), Mcse = 0))
  c(Rhat = posterior::rhat(Values), BulkEss = posterior::ess_bulk(Values),
    TailEss = posterior::ess_tail(Values), Mcse = posterior::mcse_mean(Values))
}

RubinPool <- function(Estimates, Variances, DfComplete, Confidence = .95, CompleteOutcome = FALSE) {
  Assert(length(Estimates) >= 2 && length(Estimates) == length(Variances) &&
    all(is.finite(Estimates)) && all(is.finite(Variances)) && all(Variances >= 0), "Invalid estimates for Rubin pooling.")
  Assert(length(DfComplete) == 1 && is.finite(DfComplete) && DfComplete > 0 &&
    Confidence > 0 && Confidence < 1, "Invalid confidence or complete-data degrees of freedom.")
  M <- length(Estimates)
  Estimate <- mean(Estimates)
  Within <- mean(Variances)
  Between <- if (CompleteOutcome) 0 else var(Estimates)
  Total <- Within + (1 + 1/M)*Between
  if (CompleteOutcome) {
    Assert(diff(range(Estimates)) <= 1e-10*max(1, abs(Estimate)) &&
      diff(range(Variances)) <= 1e-10*max(1, Within), "A complete outcome produced different analyses.")
  }
  Lambda <- if (Total > 0) (1 + 1/M)*Between/Total else 0
  OldDf <- if (Lambda > 0) (M - 1)/Lambda^2 else Inf
  ObservedDf <- (DfComplete + 1)/(DfComplete + 3)*DfComplete*(1 - Lambda)
  Df <- if (CompleteOutcome || Total == 0) DfComplete else 1/(1/OldDf + 1/ObservedDf)
  Assert(is.finite(Df) && Df > 0, "Rubin degrees of freedom are undefined.")
  Se <- sqrt(Total)
  Critical <- qt((1 + Confidence)/2, Df)
  c(Estimate = Estimate, StandardError = Se, Lower = Estimate - Critical*Se,
    Upper = Estimate + Critical*Se, WithinVariance = Within, BetweenVariance = Between,
    TotalVariance = Total, Lambda = Lambda, Df = Df, Imputations = M)
}

PoolRbmiChains <- function(Chains, Rules, DfComplete, Settings, CompleteOutcome = FALSE,
                           FitConverged = TRUE, RhatLimit = 1.05, EssLimit = 400) {
  Sizes <- vapply(Chains, function(Chain) dim(Chain$Statistics)[1], numeric(1))
  Assert(length(Sizes) >= 2 && length(unique(Sizes)) == 1 && Sizes[1] >= 4,
    "Pooling diagnostics require equal chain lengths and at least four draws per chain.")
  Rows <- lapply(seq_len(nrow(Rules)), function(Rule) {
    Q <- vapply(Chains, function(Chain) Chain$Statistics[, Rule, "Estimate"], numeric(Sizes[1]))
    U <- vapply(Chains, function(Chain) Chain$Statistics[, Rule, "WithinVariance"], numeric(Sizes[1]))
    Pooled <- RubinPool(as.vector(Q), as.vector(U), DfComplete, Settings$Confidence, CompleteOutcome)
    M <- length(Q)
    Influence <- U + (1 + 1/M)*M/(M - 1)*(Q - mean(Q))^2
    PointCheck <- RbmiMonteCarlo(Q)
    VarianceCheck <- RbmiMonteCarlo(Influence)
    Fraction <- if (Pooled["StandardError"] > 0) PointCheck["Mcse"]/Pooled["StandardError"] else 0
    VarianceFraction <- if (Pooled["TotalVariance"] > 0) VarianceCheck["Mcse"]/Pooled["TotalVariance"] else 0
    DiagnosticValues <- rbind(PointCheck, VarianceCheck)
    DiagnosticsPassed <- all(is.finite(DiagnosticValues)) && all(DiagnosticValues[, "Rhat"] <= RhatLimit) &&
      all(DiagnosticValues[, "BulkEss"] >= EssLimit) && all(DiagnosticValues[, "TailEss"] >= EssLimit)
    PrecisionPassed <- is.finite(Fraction) && is.finite(VarianceFraction) &&
      Fraction <= Settings$McseFractionLimit && VarianceFraction <= Settings$VarianceMcseFractionLimit
    Status <- if (!FitConverged) "InputFitFlagged" else if (!DiagnosticsPassed) "ImputationDiagnosticsFlagged" else if (!PrecisionPassed) "MonteCarloPrecisionFlagged" else "ChecksPassed"
    Supporting <- vapply(c("UnadjustedDifference", "ReferenceMean", "ActiveMean", "ReferenceZero", "ActiveZero"),
      function(Name) mean(unlist(lapply(Chains, function(Chain) Chain$Statistics[, Rule, Name]))), numeric(1))
    cbind(Rules[Rule, , drop = FALSE], as.data.frame(as.list(Pooled)), as.data.frame(as.list(Supporting)), data.frame(
      McseEstimate = unname(PointCheck["Mcse"]), McseVariance = unname(VarianceCheck["Mcse"]),
      McseFraction = unname(Fraction), VarianceMcseFraction = unname(VarianceFraction),
      MaximumRhat = max(DiagnosticValues[, "Rhat"]), MinimumBulkEss = min(DiagnosticValues[, "BulkEss"]),
      MinimumTailEss = min(DiagnosticValues[, "TailEss"]), FitConverged = FitConverged,
      DiagnosticsPassed = DiagnosticsPassed, PrecisionPassed = PrecisionPassed, Status = Status,
      DegenerateVariance = Pooled["TotalVariance"] == 0, CompleteFinalOutcome = CompleteOutcome))
  })
  Result <- do.call(rbind, Rows)
  rownames(Result) <- NULL
  Result
}

RunGammaRbmi <- function(Fit, ApplicationPath, Eligibility, Label, Rules = RbmiRules(),
                         Settings = RbmiSettings(), OutputRoot = file.path(ApplicationPath, "Results", "Rbmi"),
                         Purpose = "Application") {
  Assert(grepl("^[A-Za-z][A-Za-z0-9]*$", Label), "Use a simple PascalCase RBMI label.")
  Assert(identical(Fit$PositiveFamily, "Gamma"), "RBMI requires the fitted gamma model.")
  Layout <- RbmiLayout(Fit$Data, Eligibility)
  Analysis <- RbmiAnalysisDesign(Fit$Data)
  Sizes <- vapply(Fit$Chains, function(Chain) nrow(Chain$Draws), numeric(1))
  Assert(length(Sizes) >= 2 && length(unique(Sizes)) == 1 && all(Sizes >= max(4, Settings$ExampleCount)),
    "The saved chains have incompatible lengths.")
  Assert(Settings$Seed + 7919*length(Sizes) < .Machine$integer.max, "The imputation seed is too large.")
  SourceHashes <- c(Kernel = FileHash(file.path(ApplicationPath, "src", "GammaRbmi.cpp")),
    Methods = FileHash(file.path(ApplicationPath, "R", "GammaRbmi.R")))
  DrawKey <- digest::digest(lapply(Fit$Chains, function(Chain) Chain[c("Draws", "LogVZeros", "ZeroIndex")]), algo = "sha256")
  RunKey <- digest::digest(list(Fit$Data, DrawKey, Eligibility, Rules, Settings, SourceHashes, Purpose), algo = "sha256")
  OutputPath <- file.path(OutputRoot, Label)
  dir.create(OutputPath, recursive = TRUE, showWarnings = FALSE)
  HadSeed <- exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
  OriginalSeed <- if (HadSeed) get(".Random.seed", envir = .GlobalEnv) else NULL
  on.exit(if (HadSeed) assign(".Random.seed", OriginalSeed, envir = .GlobalEnv) else if (
    exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)) rm(".Random.seed", envir = .GlobalEnv), add = TRUE)
  LoadRbmiCpp(ApplicationPath)
  Chains <- lapply(seq_along(Fit$Chains), function(Index) {
    Checkpoint <- file.path(OutputPath, sprintf("Chain%02dImputations.rds", Index))
    if (file.exists(Checkpoint)) {
      Saved <- readRDS(Checkpoint)
      Assert(identical(Saved$RunKey, RunKey) && identical(Saved$Chain, Index),
        "Saved imputations differ from these inputs. Use a new RBMI label.")
      Assert(all(dim(Saved$Statistics) == c(Sizes[Index], nrow(Rules), 7)),
        "A saved imputation checkpoint has inconsistent dimensions.")
      return(Saved)
    }
    set.seed(Settings$Seed + 7919*Index)
    message(Label, ": imputing all ", Sizes[Index], " draws in chain ", Index, ".")
    Started <- proc.time()[[3]]
    Saved <- CompleteRbmiChain(Fit, Fit$Chains[[Index]], Layout, Rules, Analysis, Settings$ExampleCount)
    Saved$ElapsedSeconds <- proc.time()[[3]] - Started
    Saved$RunKey <- RunKey
    Saved$Chain <- Index
    Saved$Seed <- Settings$Seed + 7919*Index
    Saved$RngState <- get(".Random.seed", envir = .GlobalEnv)
    SaveCheckpoint(Saved, Checkpoint)
    Saved
  })
  Summary <- PoolRbmiChains(Chains, Rules, Analysis$DfComplete, Settings, !Layout$HasMissingFinal,
    isTRUE(Fit$Convergence$Converged), Fit$Settings$RhatLimit, Fit$Settings$EssLimit)
  Result <- list(Label = Label, Purpose = Purpose, RunKey = RunKey, DrawKey = DrawKey,
    SourceHashes = SourceHashes, Settings = Settings, Rules = Rules, Chains = Chains,
    Summary = Summary, Data = Fit$Data, Layout = Layout, Analysis = Analysis,
    InputConvergence = Fit$Convergence[c("Status", "Converged", "SummaryScope", "SummaryBlocks")],
    SessionInfo = capture.output(sessionInfo()))
  SaveTable(Summary, file.path(OutputPath, "PooledResults.csv"))
  SaveTable(Rules, file.path(OutputPath, "SensitivityRules.csv"))
  saveRDS(Result, file.path(OutputPath, "RbmiResults.rds"), compress = "gzip")
  writeLines(Result$SessionInfo, file.path(OutputPath, "SessionInfo.txt"))
  message(Label, ": ", sum(Sizes), " completions per rule; all draws retained.")
  invisible(Result)
}
