# Reports use every summarized draw and display convergence failures explicitly.
# Trace plots may show a subset for file size; numerical summaries are never thinned.
SummarizeProfiles <- function(Fit) {
  Values <- MarginalProfileValues(Fit$Chains, Fit$Data)
  Rows <- list()
  for (Group in 1 : 2) {
    for (Visit in 1 : 4) {
      for (Quantity in 1 : 3) {
        Draws <- Values[, Group, Visit, Quantity]
        Rows[[length(Rows) + 1]] <- data.frame(
          Group = dimnames(Values)[[2]][Group],
          Week = Fit$Data$Weeks[Visit], Quantity = dimnames(Values)[[4]][Quantity],
          Mean = mean(Draws), Median = median(Draws), Lower = unname(quantile(Draws, .025)),
          Upper = unname(quantile(Draws, .975))
        )
      }
    }
  }
  do.call(rbind, Rows)
}

WriteGammaReport <- function(Fit, OutputPath) {
  CheckPackages(c("ggplot2", "posterior"))
  dir.create(file.path(OutputPath, "Figures"), showWarnings = FALSE)
  dir.create(file.path(OutputPath, "Tables"), showWarnings = FALSE)
  TablePath <- file.path(OutputPath, "Tables")
  Predictive <- GeneratePredictiveChecks(Fit)
  Profiles <- SummarizeProfiles(Fit)
  Chains <- do.call(rbind, lapply(seq_along(Fit$Chains), function(Index) {
    Chain <- Fit$Chains[[Index]]
    data.frame(
      Chain = Index, Draws = nrow(Chain$Draws),
      ZeroAcceptance = Chain$Acceptance[1], PositiveAcceptance = Chain$Acceptance[2],
      CorrelationAcceptance = Chain$Acceptance[3], InvalidProposals = Chain$InvalidProposals
    )
  }))
  SaveTable(Fit$ParameterSummary, file.path(TablePath, "ParameterSummary.csv"))
  SaveTable(Chains, file.path(TablePath, "ChainSummary.csv"))
  SaveTable(Predictive$Summary, file.path(TablePath, "PredictiveChecks.csv"))
  SaveTable(Profiles, file.path(TablePath, "MarginalProfiles.csv"))
  ParameterDraws <- do.call(rbind, lapply(Fit$Chains, function(Chain) Chain$Draws))
  ShapeTable <- do.call(rbind, lapply(seq_along(Fit$Data$Weeks), function(Visit) {
    Shape <- 1/expm1(exp(2*ParameterDraws[, 12 + Visit]))
    Cv <- 1/sqrt(Shape)
    data.frame(Week = Fit$Data$Weeks[Visit], ShapeMedian = median(Shape),
      ShapeLower = unname(quantile(Shape, .025)), ShapeUpper = unname(quantile(Shape, .975)),
      CvMedian = median(Cv), CvLower = unname(quantile(Cv, .025)), CvUpper = unname(quantile(Cv, .975)))
  }))
  SaveTable(ShapeTable, file.path(TablePath, "ShapeByVisit.csv"))
  Theme <- ggplot2::theme_bw(base_size = 11) +
    ggplot2::theme(panel.grid.minor = ggplot2::element_blank(), legend.position = "bottom")
  SaveFigure <- function(Plot, Name, Width = 11, Height = 7) {
    for (Extension in c("png", "pdf")) {
      ggplot2::ggsave(file.path(OutputPath, "Figures", paste0(Name, ".", Extension)),
        Plot,
        width = Width, height = Height, dpi = 160, bg = "white"
      )
    }
  }
  VisitPlot <- function(Table, Title) {
    ggplot2::ggplot(Table, ggplot2::aes(Week, Median)) +
      ggplot2::geom_linerange(ggplot2::aes(ymin = Lower, ymax = Upper), colour = "#2166ac", linewidth = .7) +
      ggplot2::geom_line(colour = "#2166ac") +
      ggplot2::geom_point(ggplot2::aes(shape = "Predictive median"), colour = "#2166ac") +
      ggplot2::geom_point(ggplot2::aes(y = Observed, shape = "Observed"), size = 2) +
      ggplot2::scale_shape_manual(values = c("Observed" = 4, "Predictive median" = 16)) +
      ggplot2::facet_wrap(ggplot2::vars(Metric, Group), scales = "free_y", ncol = 3) +
      ggplot2::scale_x_continuous(breaks = Fit$Data$Weeks) +
      Theme +
      ggplot2::labs(
        x = "Nominal week", y = NULL, shape = NULL, title = Title,
        subtitle = "All summarized posterior draws; 95% ranges of replicated statistics"
      )
  }
  SaveFigure(VisitPlot(
    subset(Predictive$Summary, Metric == "Zero percent"),
    "Observed and replicated abstinence"
  ), "ZeroChecks", Height = 4.2)
  SaveFigure(VisitPlot(
    subset(Predictive$Summary, Pair == "" & Metric != "Zero percent"),
    "Observed and replicated alcohol amounts"
  ), "AmountChecks", Height = 12)
  Dependence <- subset(Predictive$Summary, Pair != "")
  Dependence$Pair <- factor(Dependence$Pair, levels = rev(unique(Dependence$Pair)))
  Plot <- ggplot2::ggplot(Dependence, ggplot2::aes(Median, Pair)) +
    ggplot2::geom_segment(ggplot2::aes(x = Lower, xend = Upper, yend = Pair), colour = "#2166ac") +
    ggplot2::geom_point(colour = "#2166ac") +
    ggplot2::geom_point(ggplot2::aes(x = Observed), shape = 4) +
    ggplot2::facet_wrap(~Metric, scales = "free", ncol = 1) +
    Theme +
    ggplot2::labs(x = NULL, y = NULL, title = "Longitudinal dependence checks")
  SaveFigure(Plot, "DependenceChecks", Height = 9)
  TraceRows <- unique(round(seq(1, nrow(Fit$Chains[[1]]$Draws), length.out = min(1200, nrow(Fit$Chains[[1]]$Draws)))))
  Traces <- do.call(rbind, lapply(seq_along(Fit$Chains), function(Chain) {
    do.call(rbind, lapply(seq_along(Fit$Data$ParameterNames), function(Parameter) {
      data.frame(
        Iteration = TraceRows, Chain = factor(Chain),
        Parameter = factor(Fit$Data$ParameterNames[Parameter], levels = Fit$Data$ParameterNames),
        Value = Fit$Chains[[Chain]]$Draws[TraceRows, Parameter]
      )
    }))
  }))
  Plot <- ggplot2::ggplot(Traces, ggplot2::aes(Iteration, Value, colour = Chain)) +
    ggplot2::geom_line(linewidth = .25, alpha = .7) +
    ggplot2::facet_wrap(~Parameter, scales = "free_y", ncol = 4) +
    Theme +
    ggplot2::labs(title = "Parameter traces", subtitle = "Display subsampled; diagnostics use all draws")
  SaveFigure(Plot, "ParameterTraces", Width = 13, Height = 10)
  Plot <- ggplot2::ggplot(Profiles, ggplot2::aes(Week, Median, colour = Group, group = Group)) +
    ggplot2::geom_linerange(ggplot2::aes(ymin = Lower, ymax = Upper),
      position = ggplot2::position_dodge(width = 1.2)
    ) +
    ggplot2::geom_line() +
    ggplot2::geom_point(position = ggplot2::position_dodge(width = 1.2)) +
    ggplot2::facet_wrap(~Quantity, scales = "free_y", ncol = 1) +
    Theme +
    ggplot2::labs(x = "Nominal week", y = NULL, title = "Standardized marginal profiles")
  SaveFigure(Plot, "MarginalProfiles", Height = 9)
  Image <- function(Name, Description) {
    paste0(
      "<figure><img src='Figures/", Name,
      ".png' alt='", Description, "'><figcaption><a href='Figures/", Name, ".pdf'>Vector PDF</a></figcaption></figure>"
    )
  }
  Status <- if (Fit$Convergence$Converged) {
    "All monitored convergence criteria passed."
  } else {
    paste("FLAGGED FIT:", Fit$Convergence$Status, ". Results are retained and summarized; inspect the diagnostic flags.")
  }
  Html <- paste0(
    "<!doctype html><html lang='en'><head><meta charset='utf-8'><title>Gamma copula: ",
    Fit$Label, "</title><style>body{font:16px/1.55 Arial,sans-serif;max-width:1150px;margin:40px auto;padding:0 24px;color:#233345}table{border-collapse:collapse;font-size:13px;width:100%}th,td{padding:7px;border-bottom:1px solid #ddd;text-align:left}.table-wrap{overflow:auto}img{max-width:100%}.note{background:#fff5dc;padding:14px}a{color:#155f9b}</style></head><body>",
    "<h1>EXALT gamma copula: ", Fit$Label, "</h1><p class='note'>", Status, "</p>",
    "<p>The logistic abstinence and gamma positive arithmetic-mean regressions are jointly fitted with longitudinal Gaussian-copula dependence. A signed adjacent-visit latent correlation generates an AR(1) structure over scheduled visit numbers. Elapsed week gaps do not enter this dependence model. Missing outcomes are integrated out of this likelihood. This report assesses the observed-data fit; the RBMI report is separate. Each visit has its own gamma shape, shared across treatment arms.</p>",
    "<p>", nrow(Fit$Data$Outcome), " participants; ", sum(!is.na(Fit$Data$Outcome)), " observed outcomes; ",
    sum(Fit$Data$Outcome == 0, na.rm = TRUE), " zeros. Treatment coding: Group 1 is placebo; Group 2 is exenatide.</p>",
    "<h2>Convergence stages</h2><p>Summary scope: ", Fit$Convergence$SummaryScope,
    ". First passing block: ", Fit$Convergence$FirstPassingBlock,
    ". R-hat threshold: ", Fit$Settings$RhatLimit, "; bulk and tail ESS thresholds: ", Fit$Settings$EssLimit,
    ". All model coordinates, reported parameter transformations and standardized treatment differences are monitored.</p>",
    HtmlTable(Fit$Convergence$History, Digits = 4), HtmlTable(Chains, Digits = 3),
    "<h2>Positive dispersion by visit</h2><p>Shapes are shared across treatments, with independent priors across visits. CV is the positive coefficient of variation.</p>", HtmlTable(ShapeTable, Digits = 4),
    "<h2>Parameters and treatment differences</h2>", HtmlTable(Fit$ParameterSummary, Digits = 4),
    "<p>The positive-mean ratio compares arithmetic means among positive outcomes at the same baseline value. It is not a causal effect in a fixed subgroup of people who would drink under either treatment.</p>",
    "<h2>Predictive checks</h2><p>", Predictive$DrawCount,
    " joint replicates use every summarized draw once. The original observation mask is applied to each replicate. These checks are descriptive; they do not establish the missingness mechanism.</p>",
    if (Predictive$NonfinitePredictions > 0 || Predictive$UndefinedStatistics > 0) {
      paste0(
        "<p class='note'>Nonfinite predictions: ", Predictive$NonfinitePredictions,
        "; statistics undefined in over 5% of replicates: ", Predictive$UndefinedStatistics, ". Inspect PredictiveChecks.csv.</p>"
      )
    } else {
      ""
    },
    Image("ZeroChecks", "Abstinence checks"), Image("AmountChecks", "Alcohol amount checks"),
    Image("DependenceChecks", "Longitudinal dependence checks"),
    "<h2>Marginal profiles</h2><p>Both arms use the same baseline distribution. Overall means include zeros. The population mean among positives uses positive-probability weighting. These are fitted observed-data model summaries, not RBMI estimates.</p>",
    Image("MarginalProfiles", "Marginal profiles"), HtmlTable(Profiles, Digits = 3),
    "<h2>Trace plots</h2>", Image("ParameterTraces", "Parameter traces"),
    "<p><a href='Tables/ParameterSummary.csv'>Parameter diagnostics</a> | <a href='Tables/PredictiveChecks.csv'>Predictive checks</a> | <a href='Tables/MarginalProfiles.csv'>Marginal profiles</a> | <a href='ConvergenceHistory.csv'>Convergence history</a> | <a href='SessionInfo.txt'>Session information</a></p>",
    "<p>", HtmlEscape(Fit$Settings$PriorDescription), "</p><p>Posterior predictive seed: ", Predictive$Seed,
    ". The augmented likelihood is not an integrated observed-data likelihood for LOO/WAIC.</p></body></html>"
  )
  writeLines(Html, file.path(OutputPath, "Report.html"), useBytes = TRUE)
  ApplicationPath <- dirname(dirname(dirname(OutputPath)))
  Result <- list(
    ReportKey = GammaReportKey(Fit, ApplicationPath),
    Predictive = Predictive, Profiles = Profiles, Chains = Chains,
    FitKey = Fit$SamplingKey, SummaryBlocks = Fit$Convergence$SummaryBlocks,
    ReportSourceHash = FileHash(file.path(dirname(dirname(dirname(OutputPath))), "R", "ModelReports.R"))
  )
  saveRDS(Result, file.path(OutputPath, "ReportResults.rds"))
  invisible(Result)
}


GammaReportKey <- function(Fit, ApplicationPath) {
  Sources <- c("Utilities.R", "McmcDiagnostics.R", "PredictiveChecks.R", "ModelReports.R")
  Hashes <- vapply(file.path(ApplicationPath, "R", Sources), FileHash, character(1))
  digest::digest(list(
    Fit$SamplingKey, Fit$Convergence$SummaryBlocks,
    Fit$Convergence$Status, Fit$Settings, Hashes
  ), algo = "sha256")
}
