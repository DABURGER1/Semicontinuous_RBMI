# Independent R posterior prediction. Every summarized draw generates one
# joint four-visit replicate. There is no posterior thinning or draw selection.
PredictiveLayout <- function(Data) {
  Rows <- list()
  AddRow <- function(Group, Metric, Week = NA_real_, Pair = "") {
    Rows[[length(Rows) + 1]] <<- data.frame(Group = Group, Metric = Metric, Week = Week, Pair = Pair)
  }
  for (Group in c("All participants", "Placebo", "Exenatide")) {
    for (Week in Data$Weeks) {
      for (Metric in c("Zero percent", "Positive median (g)", "Positive 90th percentile (g)", "Overall mean (g)", "Maximum (g)")) {
        AddRow(Group, Metric, Week)
      }
    }
  }
  for (Earlier in 1 : 3) {
    for (Later in seq.int(Earlier + 1, 4)) {
      Pair <- paste(Data$Weeks[Earlier], "to", Data$Weeks[Later], "weeks")
      AddRow("All participants", "Spearman: all available pairs", Pair = Pair)
      AddRow("All participants", "Spearman: both positive", Pair = Pair)
      if (Later == Earlier + 1) AddRow("All participants", "Next zero given previous zero (%)", Pair = Pair)
    }
  }
  do.call(rbind, Rows)
}

OutcomeStatistics <- function(Outcome, Data) {
  Values <- numeric(75)
  Position <- 0
  AddValues <- function(NewValues) {
    Values[Position + seq_along(NewValues)] <<- NewValues
    Position <<- Position + length(NewValues)
  }
  Correlation <- function(First, Second) {
    Present <- is.finite(First) & is.finite(Second)
    if (sum(Present) < 3 || length(unique(First[Present])) < 2 ||
      length(unique(Second[Present])) < 2) {
      return(NA_real_)
    }
    cor(First[Present], Second[Present], method = "spearman")
  }
  for (Group in 0 : 2) {
    Rows <- if (Group == 0) seq_len(nrow(Outcome)) else which(Data$GroupCode == Group)
    for (Visit in 1 : 4) {
      Observed <- Outcome[Rows, Visit]
      Observed <- Observed[!is.na(Observed)]
      Positive <- Observed[Observed > 0]
      AddValues(c(
        if (length(Observed)) 100*mean(Observed == 0) else NA_real_,
        SafeQuantile(Positive, .5), SafeQuantile(Positive, .9),
        if (length(Observed)) mean(Observed) else NA_real_,
        if (length(Observed)) max(Observed) else NA_real_
      ))
    }
  }
  for (Earlier in 1 : 3) {
    for (Later in seq.int(Earlier + 1, 4)) {
      First <- Outcome[, Earlier]
      Second <- Outcome[, Later]
      Both <- !is.na(First) & !is.na(Second)
      Positive <- Both & First > 0 & Second > 0
      AddValues(c(Correlation(First, Second), Correlation(First[Positive], Second[Positive])))
      if (Later == Earlier + 1) {
        PreviousZero <- Both & First == 0
        AddValues(if (any(PreviousZero)) 100*mean(Second[PreviousZero] == 0) else NA_real_)
      }
    }
  }
  Assert(Position == length(Values), "Predictive statistic layout is inconsistent.")
  Values
}

GeneratePredictiveChecks <- function(Fit, Seed = Fit$Settings$Seed + 71) {
  Data <- Fit$Data
  Draws <- do.call(rbind, lapply(Fit$Chains, function(Chain) Chain$Draws))
  PreviousSeed <- if (exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)) {
    get(".Random.seed", envir = .GlobalEnv)
  } else {
    NULL
  }
  on.exit(
    {
      if (is.null(PreviousSeed)) {
        if (exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)) rm(".Random.seed", envir = .GlobalEnv)
      } else {
        assign(".Random.seed", PreviousSeed, envir = .GlobalEnv)
      }
    },
    add = TRUE
  )
  set.seed(Seed)
  Layout <- PredictiveLayout(Data)
  ObservedStatistics <- OutcomeStatistics(Data$Outcome, Data)
  Replicates <- matrix(NA_real_, nrow(Draws), nrow(Layout))
  Distance <- abs(outer(seq_along(Data$Weeks), seq_along(Data$Weeks), "-"))
  ObservedMask <- !is.na(Data$Outcome)
  NonfinitePredictions <- 0
  for (Index in seq_len(nrow(Draws))) {
    Theta <- Draws[Index, ]
    ZeroPredictor <- outer(drop(Data$Design %*% Theta[5 : 6]), rep(1, 4)) +
      matrix(Theta[1 : 4], nrow(Data$Outcome), 4, byrow = TRUE)
    PositivePredictor <- outer(drop(Data$Design %*% Theta[11 : 12]), rep(1, 4)) +
      matrix(Theta[7 : 10], nrow(Data$Outcome), 4, byrow = TRUE)
    LogPositiveProbability <- plogis(ZeroPredictor, lower.tail = FALSE, log.p = TRUE)
    ZeroThreshold <- qnorm(LogPositiveProbability, lower.tail = FALSE, log.p = TRUE)
    Correlation <- tanh(Theta[17]/2)
    Assert(is.finite(Correlation) && Correlation > -1 && Correlation < 1, "A predictive correlation reached a numerical boundary.")
    Scores <- matrix(rnorm(length(Data$Outcome)), nrow(Data$Outcome), 4) %*% chol(Correlation^Distance)
    Simulated <- matrix(0, nrow(Data$Outcome), 4)
    Positive <- Scores > ZeroThreshold
    LogSurvival <- pnorm(Scores[Positive], lower.tail = FALSE, log.p = TRUE) - LogPositiveProbability[Positive]
    Assert(all(is.finite(LogSurvival)) && all(LogSurvival < 0), "A gamma predictive probability is invalid.")
    Shape <- matrix(rep(1/expm1(exp(2*Theta[13 : 16])), each = nrow(Data$Outcome)),
      nrow(Data$Outcome), 4)
    Simulated[Positive] <- Data$UnitScale*qgamma(LogSurvival,
      shape = Shape[Positive],
      scale = exp(PositivePredictor[Positive])/Shape[Positive], lower.tail = FALSE, log.p = TRUE
    )
    NonfinitePredictions <- NonfinitePredictions + sum(!is.finite(Simulated))
    Simulated[!ObservedMask] <- NA_real_
    Replicates[Index, ] <- OutcomeStatistics(Simulated, Data)
    if (Index %% 4000 == 0) message(Fit$Label, ": predictive checks for ", Index, " of ", nrow(Draws), " draws.")
  }
  Layout$Observed <- ObservedStatistics
  Layout$Lower <- apply(Replicates, 2, SafeQuantile, Probability = .025)
  Layout$Median <- apply(Replicates, 2, SafeQuantile, Probability = .5)
  Layout$Upper <- apply(Replicates, 2, SafeQuantile, Probability = .975)
  Layout$DefinedReplicates <- colSums(!is.na(Replicates))
  Layout$OutsideInterval <- with(Layout, Observed < Lower | Observed > Upper)
  list(
    Summary = Layout, DrawCount = nrow(Draws), Seed = Seed,
    NonfinitePredictions = NonfinitePredictions,
    UndefinedStatistics = sum(Layout$DefinedReplicates < .95*nrow(Draws))
  )
}
