# Stage 04. Create candidate panels and design matrices, without fitting a model.
# Observation masks do not identify the missingness mechanism or treatment discontinuation.
CreateModelInputs <- function(ApplicationPath) {
  ExaltLong <- readRDS(file.path(ApplicationPath, "Derived", "02ExaltLong.rds"))
  ExaltSubjects <- readRDS(file.path(ApplicationPath, "Derived", "02ExaltSubjects.rds"))
  ExaltSubjects <- ExaltSubjects[order(ExaltSubjects$Id), ]
  ExaltFollowup <- ExaltLong[ExaltLong$Visit > 0, ]
  AddMasks <- function(Outcome) {
    list(
      Outcome = Outcome, Observed = !is.na(Outcome),
      Zero = !is.na(Outcome) & Outcome == 0, Positive = !is.na(Outcome) & Outcome > 0,
      ObservedIndex = which(!is.na(Outcome), arr.ind = TRUE),
      MissingIndex = which(is.na(Outcome), arr.ind = TRUE)
    )
  }
  ExaltLogBaseline <- log1p(ExaltSubjects$BaselineAlcoholGrams30Days)
  ExaltSubjects$BaselineLog1pCentered <- ExaltLogBaseline - mean(ExaltLogBaseline)
  ExaltSubjects$Group2Indicator <- as.integer(ExaltSubjects$GroupCode == 2)
  ExaltDesign <- model.matrix(~ Group2Indicator + BaselineLog1pCentered, data = ExaltSubjects)
  Assert(nrow(ExaltDesign) == nrow(ExaltSubjects), "Design matrix dropped participants")
  Exalt <- list(
    Dataset = "EXALT", Id = ExaltSubjects$Id, Visit = 1 : 4, NominalWeek = c(4, 12, 20, 26),
    OutcomeUnits = "grams of alcohol per intended 30-day recall window", Subjects = ExaltSubjects,
    OutcomeViews = list(
      AsReported = AddMasks(PanelMatrix(ExaltFollowup, ExaltSubjects$Id, 1 : 4, "OutcomeGrams30Days")),
      FinalVisitTimingChecked = AddMasks(PanelMatrix(ExaltFollowup, ExaltSubjects$Id, 1 : 4, "OutcomeTimingChecked"))
    ),
    RecordedDays = matrix(NA_real_, nrow(ExaltSubjects), 4, dimnames = list(ExaltSubjects$Id, paste0("Visit", 1 : 4))),
    IntendedRecallDays = 30,
    CandidateXSubject = ExaltDesign, BaselineLog1pCenter = mean(ExaltLogBaseline),
    RbmiTriggerVisit = rep(NA_integer_, nrow(ExaltSubjects)),
    TreatmentStopWeek = rep(NA_real_, nrow(ExaltSubjects)),
    TreatmentCodeConfirmed = TRUE,
    Notes = c(
      "All 127 participants in the alcohol outcome file are retained.",
      "Treatment coding is corroborated: 1=placebo, 2=exenatide. The published Figure 1 caption reverses the group counts.",
      "The actual observed-day denominators are unavailable; intended recall length is not an observed denominator.",
      "The timing-checked view excludes ID 46's unresolved final outcome and retains that source value in the as-reported view.",
      "Candidate X uses group code and centred log1p baseline; BMI/gender remain available as candidate covariates.",
      "Final assessment week is not used as medication-stop week.",
      "The final timing screen is applied in PrepareGammaData; eligibility and the operational trigger are defined in RunApplicationRbmi."
    )
  )
  saveRDS(Exalt, file.path(ApplicationPath, "Derived", "04ExaltModelInputs.rds"))
  ExportPanel <- function(Bundle, View, Stem) {
    Outcome <- Bundle$OutcomeViews[[View]]$Outcome
    Data <- data.frame(Id = Bundle$Id, Outcome, check.names = FALSE)
    SaveTable(Data, file.path(ApplicationPath, "Derived", paste0(Stem, ".csv")))
  }
  ExportPanel(Exalt, "AsReported", "04ExaltWideAsReported")
  ExportPanel(Exalt, "FinalVisitTimingChecked", "04ExaltWideTimingChecked")
  Summary <- do.call(rbind, lapply(list(Exalt), function(Bundle) {
    do.call(rbind, lapply(names(Bundle$OutcomeViews), function(Name) {
      Outcome <- Bundle$OutcomeViews[[Name]]$Outcome
      data.frame(
        Dataset = Bundle$Dataset, View = Name, Participants = nrow(Outcome), FollowupVisits = ncol(Outcome),
        Observed = sum(!is.na(Outcome)), Zeros = sum(Outcome == 0, na.rm = TRUE), Positive = sum(Outcome > 0, na.rm = TRUE),
        Missing = sum(is.na(Outcome)), SubjectsWithNoObservedFollowup = sum(rowSums(!is.na(Outcome)) == 0)
      )
    }))
  }))
  SaveTable(Summary, file.path(ApplicationPath, "Results", "Tables", "04ModelInputSummary.csv"))
  # Fail on accidental data loss or an incorrectly conflated timing/stop variable.
  Assert(nrow(Exalt$OutcomeViews$AsReported$Outcome) == 127, "EXALT panel lost participants")
  Assert(all(is.na(Exalt$TreatmentStopWeek)), "Unknown treatment-stop dates were filled")
  Assert(all(is.na(Exalt$RbmiTriggerVisit)), "Unapproved RBMI triggers were assigned")
  invisible(NULL)
}
