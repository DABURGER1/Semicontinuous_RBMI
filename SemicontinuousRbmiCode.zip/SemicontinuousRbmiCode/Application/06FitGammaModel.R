# Fit the selected scheduled-visit application with separate shapes per visit.
# The fit label identifies the data preparation and shape specification.
FitApplicationModels <- function(ApplicationPath, Settings = GammaSettings()) {
  Fit <- FitGammaModel(ApplicationPath, View = "TimingScreened",
    Label = ApplicationGammaLabel(), Settings = Settings)
  invisible(setNames(list(Fit), ApplicationGammaLabel()))
}
