# Stage 03. Descriptive investigation only; no treatment-effect inference.
ExploreData <- function(ApplicationPath) {
  ExaltLong <- readRDS(file.path(ApplicationPath, "Derived", "02ExaltLong.rds"))
  Tables <- file.path(ApplicationPath, "Results", "Tables")
  Figures <- file.path(ApplicationPath, "Results", "Figures")
  ExaltByArm <- SummarizeOutcome(ExaltLong, "OutcomeGrams30Days", c("NominalWeek", "Arm"))
  ExaltOverall <- SummarizeOutcome(ExaltLong, "OutcomeGrams30Days", "NominalWeek")
  ExaltTimingChecked <- SummarizeOutcome(ExaltLong, "OutcomeTimingChecked", c("NominalWeek", "Arm"))
  SaveTable(ExaltByArm, file.path(Tables, "03ExaltByVisitAndGroupCode.csv"))
  SaveTable(ExaltOverall, file.path(Tables, "03ExaltOverallByVisit.csv"))
  SaveTable(ExaltTimingChecked, file.path(Tables, "03ExaltTimingCheckedByArm.csv"))
  ExaltPatterns <- ObservationPatterns(ExaltLong[ExaltLong$Visit > 0, ], "Id", "Visit", "OutcomeGrams30Days", "Arm")
  PatternTable <- function(Plot, Study) {
    A <- as.data.frame(table(Plot$Pattern1Missing))
    names(A) <- c("Pattern1Missing", "Count")
    A$Dataset <- Study
    A[order(-A$Count), ]
  }
  Patterns <- PatternTable(ExaltPatterns, "EXALT")
  SaveTable(Patterns, file.path(Tables, "03MissingnessPatterns.csv"))
  SaveTable(
    cbind(Dataset = "EXALT", ExaltPatterns),
    file.path(Tables, "03SubjectObservationPatterns.csv")
  )

  CorrelationTable <- function(Data, Value, Study) {
    Matrix <- PanelMatrix(Data, sort(unique(Data$Id)), sort(unique(Data$Visit)), Value)
    Pairs <- combn(ncol(Matrix), 2)
    do.call(rbind, lapply(seq_len(ncol(Pairs)), function(Index) {
      VisitIndex <- Pairs[1, Index]
      LaterIndex <- Pairs[2, Index]
      ObservedPairs <- !is.na(Matrix[, VisitIndex]) & !is.na(Matrix[, LaterIndex])
      Values <- Matrix[ObservedPairs, VisitIndex]
      Outcome <- Matrix[ObservedPairs, LaterIndex]
      SafeCorrelation <- function(A, Bundle, Method) if (length(A) > 2 && sd(A) > 0 && sd(Bundle) > 0) cor(A, Bundle, method = Method) else NA_real_
      BothPositive <- Values > 0 & Outcome > 0
      data.frame(
        Dataset = Study, EarlierVisit = VisitIndex, LaterVisit = LaterIndex,
        NObservedPairs = length(Values), SpearmanOutcome = SafeCorrelation(Values, Outcome, "spearman"),
        ZeroIndicatorCorrelation = SafeCorrelation(as.numeric(Values == 0), as.numeric(Outcome == 0), "pearson"),
        NBothPositive = sum(BothPositive),
        SpearmanBothPositive = SafeCorrelation(Values[BothPositive], Outcome[BothPositive], "spearman")
      )
    }))
  }
  Correlations <- rbind(
    CorrelationTable(ExaltLong[ExaltLong$Visit > 0, ], "OutcomeGrams30Days", "EXALT")
  )
  SaveTable(Correlations, file.path(Tables, "03PairwiseDescriptiveDependence.csv"))
  Transitions <- function(Data, Value, Study) {
    Matrix <- PanelMatrix(Data, sort(unique(Data$Id)), 1 : 4, Value)
    State <- function(Values) ifelse(is.na(Values), "Missing", ifelse(Values == 0, "Zero", "Positive"))
    do.call(rbind, lapply(1 : 3, function(VisitIndex) {
      Table <- as.data.frame(table(
        FromState = factor(State(Matrix[, VisitIndex]), levels = c("Zero", "Positive", "Missing")),
        ToState = factor(State(Matrix[, VisitIndex + 1]), levels = c("Zero", "Positive", "Missing"))
      ))
      names(Table)[3] <- "Count"
      Table$ConditionalPercent <- 100*Table$Count/ave(Table$Count, Table$FromState, FUN = sum)
      Table$Dataset <- Study
      Table$EarlierVisit <- VisitIndex
      Table$LaterVisit <- VisitIndex + 1
      Table
    }))
  }
  TransitionsTable <- rbind(
    Transitions(ExaltLong[ExaltLong$Visit > 0, ], "OutcomeGrams30Days", "EXALT")
  )
  SaveTable(TransitionsTable, file.path(Tables, "03ZeroPositiveMissingTransitions.csv"))
  TailTable <- function(Data, Value, Study) {
    Out <- Data[, c("Id", "Visit", "Arm", Value)]
    names(Out)[4] <- "Outcome"
    Out <- Out[!is.na(Out[["Outcome"]]), ]
    Out <- head(Out[order(-Out[["Outcome"]]), ], 15)
    cbind(Dataset = Study, Out)
  }
  SaveTable(
    rbind(
      TailTable(ExaltLong[ExaltLong$Visit > 0, ], "OutcomeGrams30Days", "EXALT_grams_per_30_days")
    ),
    file.path(Tables, "03LargestObservedValues.csv")
  )

  Theme <- ggplot2::theme_minimal(base_size = 12) +
    ggplot2::theme(
      panel.grid.minor = ggplot2::element_blank(),
      plot.title = ggplot2::element_text(face = "bold", color = "#15364a"),
      legend.position = "bottom", strip.text = ggplot2::element_text(face = "bold")
    )
  SavePlot <- function(Plot, Name, Height = 6.7) {
    ggplot2::ggsave(file.path(Figures, paste0(Name, ".png")), Plot + Theme,
      width = 11, height = Height, dpi = 170, bg = "white"
    )
    ggplot2::ggsave(file.path(Figures, paste0(Name, ".pdf")), Plot + Theme,
      width = 11, height = Height, device = "pdf"
    )
  }
  Profiles <- function(Subset, Time, Title, Unit, Subtitle, Stem) {
    Columns <- c("ZeroPercentObserved", "MeanPositive", "MeanAllObserved", "MissingPercent")
    Labels <- c(
      "Zero outcomes (% of observed)", paste0("Mean positive outcome (", Unit, ")"),
      paste0("Mean overall outcome (", Unit, ")"), "Missing outcomes (% of scheduled)"
    )
    Data <- do.call(rbind, lapply(seq_along(Columns), function(Index) {
      data.frame(Time = Subset[[Time]], Arm = Subset$Arm, Metric = Labels[Index], Value = Subset[[Columns[Index]]])
    }))
    Data$Metric <- factor(Data$Metric, levels = Labels)
    Plot <- ggplot2::ggplot(Data, ggplot2::aes(Time, Value, color = Arm, group = Arm)) +
      ggplot2::geom_line(linewidth = .65) +
      ggplot2::geom_point(size = 1.8) +
      ggplot2::facet_wrap(~Metric, ncol = 2, scales = "free_y") +
      ggplot2::scale_x_continuous(breaks = sort(unique(Data$Time))) +
      ggplot2::scale_color_viridis_d(end = .85) +
      ggplot2::labs(
        title = Title, subtitle = Subtitle,
        x = if (Time == "Visit") "Month" else "Nominal week", y = NULL, color = "Randomized group"
      )
    SavePlot(Plot, Stem)
  }
  Profiles(
    ExaltByArm, "NominalWeek", "EXALT: reported alcohol outcomes", "grams/30 days",
    "Group 1 is placebo; Group 2 is exenatide. These are descriptive observed-data summaries.", "03ExaltProfiles"
  )
  DistPlot <- function(Data, Value, Title, Xlab, Stem) {
    Data <- Data[!is.na(Data[[Value]]) & Data[[Value]] > 0 & Data$Visit > 0, ]
    Data$Amount <- Data[[Value]]
    Plot <- ggplot2::ggplot(Data, ggplot2::aes(Amount)) +
      ggplot2::geom_histogram(bins = 28, fill = "#247a8a", color = "white", linewidth = .2) +
      ggplot2::scale_x_log10() +
      ggplot2::facet_wrap(~NominalWeek, ncol = 2, labeller = ggplot2::label_both) +
      ggplot2::labs(title = Title, subtitle = "Positive observations only; logarithmic horizontal axis. Zeros are summarized separately.", x = Xlab, y = "Observations")
    SavePlot(Plot, Stem)
  }
  DistPlot(
    ExaltLong, "OutcomeGrams30Days", "EXALT: positive consumption distribution",
    "Total alcohol (grams per intended 30-day window)", "03ExaltPositiveDistribution"
  )
  Plot <- ggplot2::ggplot(Patterns, ggplot2::aes(Count, reorder(Pattern1Missing, Count))) +
    ggplot2::geom_col(fill = "#247a8a", width = .65) +
    ggplot2::geom_text(ggplot2::aes(label = Count), hjust = -.15, size = 3.5) +
    ggplot2::facet_wrap(~Dataset, scales = "free", ncol = 2) +
    ggplot2::scale_x_continuous(expand = ggplot2::expansion(mult = c(0, .18))) +
    ggplot2::labs(
      title = "Availability of the four postbaseline alcohol outcomes",
      subtitle = "1 = missing; 0 = observed. These are not treatment-stop patterns.",
      x = "Participants", y = "Missingness pattern"
    )
  SavePlot(Plot, "03MissingnessPatterns", Height = 5)
  Plot <- ggplot2::ggplot(TransitionsTable, ggplot2::aes(ToState, FromState, fill = ConditionalPercent)) +
    ggplot2::geom_tile(color = "white") +
    ggplot2::geom_text(ggplot2::aes(label = Count), size = 3.8) +
    ggplot2::facet_grid(Dataset ~ EarlierVisit, labeller = ggplot2::label_both) +
    ggplot2::scale_fill_gradient(low = "#f1f7fa", high = "#4f99ae", na.value = "grey95") +
    ggplot2::labs(
      title = "Transitions between adjacent postbaseline visits",
      subtitle = "Cell labels are counts; shading is conditional on the earlier state. Missingness is shown explicitly.",
      x = "State at next visit", y = "State at earlier visit", fill = "Row %"
    )
  SavePlot(Plot, "03Transitions")

  Issues <- read.csv(file.path(Tables, "02DataIssues.csv"))
  Cols <- c("NScheduled", "NObserved", "NMissing", "NZero", "ZeroPercentObserved", "MeanAllObserved", "MeanPositive")
  Checks <- data.frame(
    Check = c(
      "EXALT participant/visit key",
      "EXALT shared-file group-code agreement", "EXALT zero quantities versus 30 abstinent days"
    ),
    Result = "Passed during import/derivation"
  )
  SaveTable(Checks, file.path(Tables, "03DerivationChecks.csv"))
  FigureHtml <- function(Stem) paste0("<img src='Figures/", Stem, ".png' alt='", gsub("_", " ", Stem), "'>")
  Report <- c(
    "<!doctype html><html lang='en'><head><meta charset='utf-8'><title>Preliminary alcohol-data investigation</title>",
    "<style>body{font:16px/1.55 system-ui,sans-serif;color:#243643;max-width:1200px;margin:40px auto;padding:0 25px}h1,h2{color:#15364a}h1{font-size:30px}h2{margin-top:40px}p,li{max-width:1000px}table{border-collapse:collapse;font-size:13px;width:100%}th,td{padding:9px;border-bottom:1px solid #dce5e9;text-align:left;vertical-align:top}th{background:#edf4f7}img{width:100%;margin:16px 0}a{color:#166979}.table-wrap{overflow:auto}.note{background:#fff5dc;padding:16px;border-left:4px solid #d49b29}code{background:#eef2f4;padding:2px 4px}</style></head><body>",
    "<h1>Semicontinuous Copula RBMI: preliminary application investigation</h1>",
    paste0("<p>Generated ", format(Sys.Date()), ". Descriptive investigation; no imputation or model fitting.</p>"),
    "<p>The proposed outcomes measure alcohol quantity. Abstinent-day and heavy-drinking-day counts are retained as auxiliary information and consistency checks. These summaries describe the EXALT source files before the final timing screen.</p>",
    "<h2>EXALT</h2><p>127 participants; total alcohol intake in grams over the preceding 30 days at nominal weeks 0, 4, 12, 20 and 26. The source files do not give the number of actually recorded days within each recall period.</p>",
    HtmlTable(ExaltOverall[, c("NominalWeek", Cols)]),
    "<div class='note'>Treatment coding is corroborated: code 1 is placebo (65 participants) and code 2 is exenatide (62 participants). The main Results, CONSORT diagram and baseline summaries agree with the repository. The Figure 1 caption reverses the counts. Original codes are preserved.</div>",
    FigureHtml("03ExaltProfiles"), FigureHtml("03ExaltPositiveDistribution"),
    "<p>ID 46 is present in the outcome files but absent from the dropout workbook; ID 56 has the reverse mismatch. They have not been merged or relabelled. Of the 57 observed final alcohol outcomes, 56 have metadata confirming week 26 and one has unknown timing. The timing-checked outcome excludes only that unresolved final observation. Last assessment is not assumed to be the drug-stop date.</p>",
    "<h2>Missingness and dependence</h2>",
    FigureHtml("03MissingnessPatterns"), FigureHtml("03Transitions"),
    "<p>Pairwise correlations below use available outcome pairs. These are descriptive correlations, not Gaussian-copula parameter estimates. Positive-only correlations condition on positive observations at both visits and need not reflect dependence in the full population.</p>",
    HtmlTable(Correlations),
    "<h2>Issues retained for analysis planning</h2>", HtmlTable(Issues),
    "<p>These are exploratory source-data summaries. The selected EXALT analysis uses scheduled-visit timing screening, a final missing-tail trigger and a hypothetical survival estimand. Verified treatment-stop and death dates remain unavailable. See <a href='07GammaOverview.html'>the current model report</a> and <a href='Rbmi/10RbmiOverview.html'>the RBMI results</a> for the implemented analysis; the original data views above are retained for source comparison.</p>",
    "<h2>Reproducibility</h2><p>Run <code>Rscript --vanilla Application/00RunAnalysis.R --stage=Prepare</code> from the project root. Sources are preserved in Raw; imported copies in Imported; derived tables and modelling bundles in Derived. Tables are CSV, datasets are CSV/RDS, and figures are PNG/PDF. All calculations are deterministic.</p>",
    "<p><a href='Tables/02DataIssues.csv'>Data issues</a> | <a href='Tables/02ExaltIdAndTimingReconciliation.csv'>EXALT ID/timing reconciliation</a> | <a href='../Derived/02VariableDictionary.csv'>Variable dictionary</a> | <a href='Tables/01SourceFileManifest.csv'>Source hashes</a> | <a href='PreparationSessionInfo.txt'>R session information</a></p>",
    "<h2>Sources</h2><p><a href='https://doi.org/10.17632/hck4tvrhbb.1'>EXALT data, version 1</a>; <a href='https://doi.org/10.1172/jci.insight.159863'>EXALT trial publication</a>.</p>",
    "</body></html>"
  )
  writeLines(Report, file.path(ApplicationPath, "Results", "03PreliminaryReport.html"), useBytes = TRUE)
  invisible(NULL)
}
