# Stage 09. EXALT analysis under the prespecified hypothetical survival strategy.
# The final-tail trigger is an observation-pattern rule, not a medication-stop date.
# Missing values represent hypothetical outcomes had participants remained alive.
RbmiEligibilityTable <- function(Fit) {
  Data <- Fit$Data
  Positions <- expand.grid(Subject = seq_len(nrow(Data$Outcome)), Visit = 1 : 4)
  Observed <- !is.na(Data$Outcome)
  Trigger <- apply(Observed, 1, function(Values) 1 + max(c(0, which(Values))))
  Index <- as.matrix(Positions)
  data.frame(
    Id = as.character(Data$Id[Positions$Subject]), Visit = Positions$Visit,
    Week = Data$Weeks[Positions$Visit], Treatment = Data$Design[Positions$Subject, 1],
    ObservedValue = Data$Outcome[Index], Observed = Observed[Index],
    FinalTailTrigger = Trigger[Positions$Subject],
    MissingType = ifelse(Observed[Index], "Observed", ifelse(Positions$Visit >= Trigger[Positions$Subject], "FinalTail", "Intermittent")),
    OutcomeDefined = ifelse(Observed[Index], TRUE, NA), DefinitionNote = "",
    DataKey = digest::digest(Data[c("Id", "Outcome", "Design", "Weeks", "UnitScale")], algo = "sha256"))
}

ReadRbmiEligibility <- function(Path, Fit) {
  Expected <- RbmiEligibilityTable(Fit)
  Input <- read.csv(Path, colClasses = "character", check.names = FALSE, na.strings = "")
  Assert(all(c("Id", "Visit", "OutcomeDefined", "DataKey") %in% names(Input)), "Eligibility file columns are incomplete.")
  Key <- paste(Input$Id, Input$Visit, sep = ":")
  ExpectedKey <- paste(Expected$Id, Expected$Visit, sep = ":")
  Assert(nrow(Input) == nrow(Expected) && !anyDuplicated(Key) && setequal(Key, ExpectedKey),
    "Eligibility identifiers or visits do not match this fit.")
  Input <- Input[match(ExpectedKey, Key), ]
  Assert(!anyNA(Input$DataKey) && all(Input$DataKey == Expected$DataKey),
    "The eligibility file belongs to a different data view.")
  Values <- toupper(trimws(Input$OutcomeDefined))
  Assert(all(is.na(Values) | Values %in% c("TRUE", "FALSE")), "OutcomeDefined must contain TRUE, FALSE or blank.")
  Eligibility <- matrix(as.logical(Values), nrow(Fit$Data$Outcome), 4)
  Assert(all(!is.na(Eligibility[Expected$Observed]) & Eligibility[Expected$Observed]),
    "Every retained outcome must remain defined.")
  Eligibility
}

# This explicit EXALT strategy resolves all missing positions together. Existing
# FALSE entries are preserved by stopping, since they specify a different target.
SetRbmiHypotheticalSurvival <- function(Path, Fit) {
  Eligibility <- ReadRbmiEligibility(Path, Fit)
  Assert(all(is.na(Eligibility) | Eligibility),
    "An outcome is marked undefined. Reconcile it with the hypothetical survival strategy.")
  Table <- read.csv(Path, colClasses = "character", check.names = FALSE, na.strings = "")
  Original <- Table
  Table$OutcomeDefined <- TRUE
  Table$OutcomeStrategy <- "HypotheticalSurvival"
  if (!"DefinitionNote" %in% names(Table)) Table$DefinitionNote <- NA_character_
  Empty <- is.na(Table$DefinitionNote) | !nzchar(Table$DefinitionNote)
  Table$DefinitionNote[Empty & Table$Observed == "TRUE"] <- "Retained observed outcome."
  Table$DefinitionNote[Empty & Table$Observed == "FALSE"] <-
    "Hypothetical alcohol outcome had the participant remained alive; use the specified continuation or reference rule."
  if (!identical(Table, Original)) SaveTable(Table, Path)
  invisible(ReadRbmiEligibility(Path, Fit))
}

RunApplicationRbmi <- function(ApplicationPath, Settings = RbmiSettings(), Rules = RbmiRules(),
                               HypotheticalSurvival = TRUE) {
  Assert(is.logical(HypotheticalSurvival) && length(HypotheticalSurvival) == 1 &&
    !is.na(HypotheticalSurvival), "Specify TRUE or FALSE for hypothetical survival.")
  OutputRoot <- file.path(ApplicationPath, "Results", "Rbmi")
  dir.create(OutputRoot, recursive = TRUE, showWarnings = FALSE)
  Rows <- lapply("TimingScreened", function(View) {
    Label <- ApplicationGammaLabel()
    Fit <- readRDS(file.path(ApplicationPath, "Results", "Gamma", Label, "Fit.rds"))
    Table <- RbmiEligibilityTable(Fit)
    Path <- file.path(ApplicationPath, "Derived", paste0("09RbmiEligibility", View, ".csv"))
    if (!file.exists(Path)) SaveTable(Table, Path)
    Eligibility <- if (HypotheticalSurvival) SetRbmiHypotheticalSurvival(Path, Fit) else ReadRbmiEligibility(Path, Fit)
    Status <- if (anyNA(Eligibility)) "OutcomeDefinitionsUnresolved" else if (!all(Eligibility[, 4])) "FinalOutcomeUndefined" else "Ready"
    Detail <- if (Status == "OutcomeDefinitionsUnresolved") {
      "Resolve death/assessment timing and the outcome definition before application imputation."
    } else if (Status == "FinalOutcomeUndefined") {
      "The final-visit estimand and analysis population require a decision; no participants were silently excluded."
    } else ""
    if (Status == "Ready") {
      Purpose <- if (HypotheticalSurvival) "EXALT under hypothetical survival" else "EXALT application"
      Attempt <- tryCatch(RunGammaRbmi(Fit, ApplicationPath, Eligibility, Label, Rules, Settings, Purpose = Purpose),
        error = function(Condition) Condition)
      if (inherits(Attempt, "error")) {
        Status <- "ImputationFailed"
        Detail <- conditionMessage(Attempt)
      } else {
        Status <- if (all(Attempt$Summary$Status == "ChecksPassed")) "Completed" else "CompletedWithFlags"
        Detail <- paste(sum(vapply(Attempt$Chains, function(Chain) dim(Chain$Statistics)[1], numeric(1))), "completed datasets per rule.")
        SaveTable(read.csv(Path, check.names = FALSE), file.path(OutputRoot, Label, "OutcomeDefinitions.csv"))
        writeLines(c(paste("Outcome strategy:", Purpose),
          "Trigger: first visit of the final missing sequence; intermittent gaps use continuation.",
          "All retained observed values are preserved; treatment-stop dates are not inferred.",
          paste("Application source SHA256:", FileHash(file.path(ApplicationPath, "09RunRbmi.R")))),
          file.path(OutputRoot, Label, "ApplicationSpecification.txt"))
      }
    }
    data.frame(View = View, FitLabel = Label, Participants = nrow(Fit$Data$Outcome), Observed = sum(Table$Observed),
      Missing = sum(!Table$Observed), FinalTailMissing = sum(Table$MissingType == "FinalTail"),
      IntermittentMissing = sum(Table$MissingType == "Intermittent"), UnresolvedPositions = sum(is.na(Eligibility)),
      NoObservedFollowup = sum(rowSums(!is.na(Fit$Data$Outcome)) == 0),
      OutcomeStrategy = if (HypotheticalSurvival) "HypotheticalSurvival" else "ExplicitOutcomeDefinitions",
      Status = Status, Detail = Detail,
      EligibilityFile = paste0("../../Derived/", basename(Path)))
  })
  Summary <- do.call(rbind, Rows)
  SaveTable(Summary, file.path(OutputRoot, "09ApplicationReadiness.csv"))
  print(Summary[, c("View", "Missing", "FinalTailMissing", "IntermittentMissing", "UnresolvedPositions", "Status")], row.names = FALSE)
  invisible(Summary)
}
