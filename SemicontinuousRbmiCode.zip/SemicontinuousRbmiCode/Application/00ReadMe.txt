EXALT APPLICATION

Run from the extracted package root in R:
  source("Application/00RunAnalysis.R")

Required input files and download instructions are in ../DataSources.txt.
The main entry point runs all stages. Sourcing scripts 01-11 alone defines
functions without running the corresponding stage.

RUN ORDER
01ImportData.R: import the six EXALT files and record input hashes.
02PrepareData.R: derive participant and visit tables; record data issues.
03ExploreData.R: describe the source outcomes and observation patterns.
04CreateModelInputs.R: assemble preliminary panels and design matrices.
05ValidateGammaSampler.R: numerical sampler checks with synthetic data.
06FitGammaModel.R: fit the selected preparation with separate visit shapes.
07SummarizeGammaModel.R: summarize retained draws and predictive checks.
08ValidateRbmi.R: validate conditional completion and analysis.
09RunRbmi.R: specify eligibility and run nine borrowing rules.
10SummarizeRbmi.R: summarize pooled results.
11CreatePaperOutputs.R: export application tables and numerical summaries.

STAGES
From a terminal:
  Rscript --vanilla Application/00RunAnalysis.R --stage=Prepare
  Rscript --vanilla Application/00RunAnalysis.R --stage=Validate
  Rscript --vanilla Application/00RunAnalysis.R --stage=Fit
  Rscript --vanilla Application/00RunAnalysis.R --stage=Report
  Rscript --vanilla Application/00RunAnalysis.R --stage=ValidateRbmi
  Rscript --vanilla Application/00RunAnalysis.R --stage=Rbmi
  Rscript --vanilla Application/00RunAnalysis.R --stage=RbmiReport
  Rscript --vanilla Application/00RunAnalysis.R --stage=Paper

Validate and ValidateRbmi use synthetic inputs and can be run without EXALT.
RbmiExample is a separate optional synthetic fit; it is not part of All or
the paper. Other stages require the preceding outputs.

MODEL AND CONTROLS
The active fit is TimingScreenedVisitShape. There are 127 participants and
four follow-up visits at weeks 4, 12, 20, and 26. Logistic zero probabilities
and gamma arithmetic means each use visit intercepts, treatment, and
standardized log1p baseline consumption. Shapes vary by visit and are shared
across treatment arms. The latent Gaussian copula uses AR(1) dependence over
visit indices, with correlation in (-1, 1).

All normal priors have mean zero and SD 5. The correlation prior is uniform
on (-1, 1). Amounts are scaled by 1000 internally and reported in grams.
Defaults use four chains, 8000 adaptive iterations, and blocks of 4000.
R-hat must be at most 1.05 and bulk and tail ESS at least 400 for all
monitored quantities. All draws from the first passing block onward are
retained. Flags are reported when the specified block limits are reached.
See ModelAndSampler.txt and RbmiMethods.txt for details.

The final missing tail defines the operational borrowing trigger. Imputation
uses a hypothetical survival strategy; treatment-stop and death dates are
not inferred from missing outcomes. The final mean contrast is analyzed
using treatment, centered baseline, and their interaction, with HC3 plus
empirical standardization variance and Rubin pooling.

OUTPUTS
Imported/: original imported objects.
Derived/: participant tables, panels, and the variable dictionary.
Results/: fit checkpoints, validation, HTML reports, figures, and tables.
Results/Paper/: publication tables and numerical macros.

The main entry point reuses compatible checkpoints. Changes to source code,
inputs, or sampling settings may invalidate saved fits. Do not overwrite or
mix incompatible checkpoints. Use a separate extraction for another analysis.

The early descriptive report concerns the original columns and a preliminary
final-visit timing check. The fitted model applies the full TimingScreened
preparation in PrepareGammaData; the model and RBMI reports describe that
selected analysis.
