# Fixed validation fixtures also exercise alternative priors; these are not
# the application fitting defaults in GammaSettings.
# Stage 05. Independent numerical and sampling-policy validation.
# Uses synthetic inputs and records the exact sampler hash.
ValidateGammaSampler <- function(ApplicationPath) {
  Required <- c("Rcpp", "RcppArmadillo", "digest")
  Absent <- Required[!vapply(Required, requireNamespace, logical(1), quietly = TRUE)]
  if (length(Absent)) stop("Required packages: ", paste(Absent, collapse = ", "))
  Cache <- file.path(ApplicationPath, "Results", "ValidationCache")
  Output <- file.path(ApplicationPath, "Results", "Validation")
  dir.create(Cache, recursive = TRUE, showWarnings = FALSE)
  dir.create(Output, recursive = TRUE, showWarnings = FALSE)
  SamplerPath <- file.path(ApplicationPath, "src", "GammaCopula.cpp")
  SamplerHash <- digest::digest(readBin(SamplerPath, "raw", n = file.info(SamplerPath)$size), algo = "sha256", serialize = FALSE)
  LoadGammaCpp(ApplicationPath)
  Started <- proc.time()[[3]]
  Checks <- list()
  Record <- function(Name, Observed, Expected = 0, Tolerance = 1e-8, Note = "") {
    Error <- max(abs(Observed - Expected))
    Ok <- length(Error) == 1 && is.finite(Error) && Error <= Tolerance
    Checks[[length(Checks) + 1]] <<- data.frame(
      Check = Name, Passed = Ok, MaxAbsoluteError = Error, Tolerance = Tolerance, Note = Note
    )
    message(if (Ok) "PASS " else "FAIL ", Name, "; error=", format(Error, digits = 5))
    invisible(Ok)
  }
  CheckCondition <- function(Name, Condition, Note = "") Record(Name, as.integer(!isTRUE(Condition)), 0, 0, Note)
  Logadd <- function(A, B) {
    Top <- pmax(A, B)
    Answer <- Top + log1p(exp(-abs(A - B)))
    Answer[is.infinite(Top) & Top < 0] <- -Inf
    Answer
  }
  ReferenceLikelihood <- function(Theta, OutcomeMatrix, DesignMatrix, Weeks, LogV, PriorMean, PriorSd, RhoA = 2, RhoB = 2) {
    ParticipantCount <- nrow(OutcomeMatrix)
    Visit <- ncol(OutcomeMatrix)
    Scores <- matrix(0, ParticipantCount, Visit)
    Marginal <- Copula <- numeric(ParticipantCount)
    Rho <- tanh(Theta[17]/2)
    R <- Rho^abs(outer(seq_along(Weeks), seq_along(Weeks), "-"))
    Shapes <- 1/expm1(exp(2*Theta[13 : 16]))
    for (Subject in seq_len(ParticipantCount)) {
      Observed <- which(!is.na(OutcomeMatrix[Subject, ]))
      for (Index in Observed) {
        Shape <- Shapes[Index]
        Eta0 <- Theta[Index] + sum(Theta[5 : 6]*DesignMatrix[Subject, ])
        Etap <- Theta[6 + Index] + sum(Theta[11 : 12]*DesignMatrix[Subject, ])
        Lp <- plogis(Eta0, log.p = TRUE)
        Lq <- plogis(Eta0, lower.tail = FALSE, log.p = TRUE)
        if (OutcomeMatrix[Subject, Index] == 0) {
          Scores[Subject, Index] <- qnorm(Lp + LogV[Subject, Index], log.p = TRUE)
          Marginal[Subject] <- Marginal[Subject] + Lp
        } else {
          Lf <- Logadd(Lp, Lq + pgamma(OutcomeMatrix[Subject, Index], shape = Shape, scale = exp(Etap)/Shape, log.p = TRUE))
          Ls <- Lq + pgamma(OutcomeMatrix[Subject, Index], shape = Shape, scale = exp(Etap)/Shape, lower.tail = FALSE, log.p = TRUE)
          Scores[Subject, Index] <- if (Lf < log(.5)) {
            qnorm(Lf, log.p = TRUE)
          } else {
            qnorm(Ls, lower.tail = FALSE, log.p = TRUE)
          }
          Marginal[Subject] <- Marginal[Subject] + Lq + dgamma(OutcomeMatrix[Subject, Index], shape = Shape, scale = exp(Etap)/Shape, log = TRUE)
        }
      }
      if (length(Observed) > 1) {
        U <- chol(R[Observed, Observed, drop = FALSE])
        Whitened <- forwardsolve(t(U), Scores[Subject, Observed])
        Copula[Subject] <- -sum(log(diag(U))) - .5*(sum(Whitened^2) - sum(Scores[Subject, Observed]^2))
      }
    }
    Prior <- sum(dnorm(Theta[1 : 16], PriorMean, PriorSd, log = TRUE)) +
      RhoA*plogis(Theta[17], log.p = TRUE) + RhoB*plogis(Theta[17], lower.tail = FALSE, log.p = TRUE) - lbeta(RhoA, RhoB)
    list(
      LogAugmentedLikelihood = sum(Marginal + Copula), LogPrior = Prior,
      LogTarget = sum(Marginal + Copula) + Prior, Scores = Scores, LogBySubject = Marginal + Copula
    )
  }
  Evaluate <- function(Theta, OutcomeMatrix, DesignMatrix, Weeks, LogV, PriorMean = rep(0, 16), PriorSd = rep(2, 16), RhoA = 2, RhoB = 2) {
    EvaluateGammaCpp(Theta, OutcomeMatrix, DesignMatrix, Weeks, LogV, PriorMean, PriorSd, RhoA, RhoB)
  }
  Theta <- c(rep(qlogis(.2), 4), .3, -.2, rep(log(1.5), 4), -.1, .25, log(c(.7, .9, 1.1, .6)), qlogis((1 + .7)/2))
  Weeks <- c(4, 12, 20, 26)
  PriorMean <- rep(0, 16)
  PriorSd <- rep(2, 16)
  set.seed(2026102206)
  OutcomeMatrix <- matrix(NA_real_, 16, 4)
  for (Subject in seq_len(16)) {
    for (Visit in seq_len(4)) {
      if (bitwAnd(Subject - 1, bitwShiftL(1, Visit - 1)) > 0) {
        OutcomeMatrix[Subject, Visit] <- if ((Subject + Visit) %% 3 == 0) 0 else exp(rnorm(1, 0, .8))
      }
    }
  }
  DesignMatrix <- cbind(rep(0 : 1, 8), seq(-2, 2, length.out = 16))
  LogV <- matrix(log(.5), 16, 4)
  LogV[OutcomeMatrix == 0 & !is.na(OutcomeMatrix)] <- log(runif(sum(OutcomeMatrix == 0, na.rm = TRUE)))
  OrdinaryError <- ScoreError <- SubjectError <- 0
  for (Index in seq_len(25)) {
    ThetaValue <- Theta
    ThetaValue[1 : 4] <- runif(4, -3, -.4)
    ThetaValue[5 : 6] <- rnorm(2, 0, .4)
    ThetaValue[7 : 10] <- runif(4, -.5, .8)
    ThetaValue[11 : 12] <- rnorm(2, 0, .4)
    ThetaValue[13 : 16] <- log(runif(4, .4, 1.6))
    ThetaValue[17] <- qlogis((1 + runif(1, -.9, .97))/2)
    CppValue <- Evaluate(ThetaValue, OutcomeMatrix, DesignMatrix, Weeks, LogV, PriorMean, PriorSd)
    RValue <- ReferenceLikelihood(ThetaValue, OutcomeMatrix, DesignMatrix, Weeks, LogV, PriorMean, PriorSd)
    if (!isTRUE(CppValue$Valid)) stop("Invalid compiled likelihood in ordinary synthetic case ", Index)
    OrdinaryError <- max(OrdinaryError, abs(CppValue$LogTarget - RValue$LogTarget))
    ScoreError <- max(ScoreError, max(abs(CppValue$Scores - RValue$Scores)))
    SubjectError <- max(SubjectError, max(abs(as.numeric(CppValue$LogBySubject) - RValue$LogBySubject)))
  }
  Record("Compiled target versus independent R, all 16 missingness patterns", OrdinaryError, 0, 2e-8)
  Record("Gaussian scores versus independent R, ordinary cases", ScoreError, 0, 2e-10)
  Record("Subject likelihood contributions versus independent R", SubjectError, 0, 2e-8)

  # Empty observations must add no likelihood or information about parameters.
  Base <- Evaluate(Theta, OutcomeMatrix, DesignMatrix, Weeks, LogV)
  Enlarged <- Evaluate(Theta, rbind(OutcomeMatrix, rep(NA_real_, 4)), rbind(DesignMatrix, c(1, 100)), Weeks, rbind(LogV, rep(log(.5), 4)))
  Record("Additional participant with no observed follow-up", Enlarged$LogTarget, Base$LogTarget, 1e-10)
  CheckCondition("All-missing participant has likelihood contribution zero", Base$LogBySubject[1] == 0)

  # Exact independence: the scaled-logit coordinate is zero when rho is zero.
  ThetaValue <- Theta
  ThetaValue[17] <- 0
  A <- Evaluate(ThetaValue, OutcomeMatrix, DesignMatrix, Weeks, LogV)
  B <- Evaluate(ThetaValue, OutcomeMatrix, DesignMatrix, Weeks, matrix(log(.03), 16, 4))
  IndependentLl <- 0
  for (Subject in seq_len(nrow(OutcomeMatrix))) {
    for (Visit in which(!is.na(OutcomeMatrix[Subject, ]))) {
      Pi0 <- plogis(ThetaValue[Visit] + sum(ThetaValue[5 : 6]*DesignMatrix[Subject, ]))
      Mp <- ThetaValue[6 + Visit] + sum(ThetaValue[11 : 12]*DesignMatrix[Subject, ])
      Sig <- exp(ThetaValue[12 + Visit])
      IndependentLl <- IndependentLl + if (OutcomeMatrix[Subject, Visit] == 0) {
        log(Pi0)
      } else {
        log1p(-Pi0) + dgamma(OutcomeMatrix[Subject, Visit], shape = 1/expm1(Sig^2), scale = exp(Mp)*expm1(Sig^2), log = TRUE)
      }
    }
  }
  Record("Independent-copula limit equals ordinary two-part likelihood", A$LogAugmentedLikelihood, IndependentLl, 1e-8)
  Record("Independent-copula limit is invariant to zero auxiliaries", A$LogAugmentedLikelihood, B$LogAugmentedLikelihood, 1e-8)

  # A shape coordinate belongs to its own visit; zero mass does not depend on it.
  LocalTheta <- Theta
  LocalTheta[17] <- -35
  LocalOutcome <- diag(c(.8, 1.2, 1.6, 2))
  LocalOutcome[!diag(4)] <- NA_real_
  LocalOutcome <- rbind(LocalOutcome, c(NA, 0, NA, NA))
  LocalDesign <- matrix(0, 5, 2)
  LocalAuxiliary <- matrix(log(.5), 5, 4)
  Before <- Evaluate(LocalTheta, LocalOutcome, LocalDesign, Weeks, LocalAuxiliary)
  LocalTheta[14] <- LocalTheta[14] + .3
  After <- Evaluate(LocalTheta, LocalOutcome, LocalDesign, Weeks, LocalAuxiliary)
  Record("A visit-two shape change preserves other visits and zero masses",
    as.numeric(After$LogBySubject - Before$LogBySubject)[c(1, 3, 4, 5)], 0, 1e-9)
  CheckCondition("The visit-two positive density responds to its own shape",
    abs(After$LogBySubject[2] - Before$LogBySubject[2]) > 1e-5)

  # Extreme positive scores must use whichever CDF tail is numerically representable.
  # Values below/above ordinary quantile precision test the CDF transform rather than clipping.
  Extremes <- list(
    list(Eta0 = -800, Score = -40, Sigma = 1, LogV = -2),
    list(Eta0 = -100, Score = -20, Sigma = 1, LogV = -1000),
    list(Eta0 = 800, Score = 40, Sigma = 1, LogV = -2),
    list(Eta0 = 8, Score = 35, Sigma = .5, LogV = -1000),
    list(Eta0 = -8, Score = -35, Sigma = .5, LogV = -1000)
  )
  ExtremeError <- 0
  for (Index in seq_along(Extremes)) {
    Ex <- Extremes[[Index]]
    ThetaValue <- Theta
    ThetaValue[1 : 4] <- Ex$Eta0
    ThetaValue[5 : 6] <- 0
    ThetaValue[7 : 10] <- 0
    ThetaValue[11 : 12] <- 0
    ThetaValue[13 : 16] <- log(Ex$Sigma)
    ThetaValue[17] <- qlogis((1 + .4)/2)
    Outcome <- rbind(c(exp(Ex$Score*Ex$Sigma - Ex$Sigma^2/2), NA, NA, NA), c(0, NA, NA, NA))
    Design <- matrix(0, 2, 2)
    LogAuxiliary <- matrix(Ex$LogV, 2, 4)
    Cv <- Evaluate(ThetaValue, Outcome, Design, Weeks, LogAuxiliary)
    Rv <- ReferenceLikelihood(ThetaValue, Outcome, Design, Weeks, LogAuxiliary, PriorMean, PriorSd)
    CheckCondition(paste0("Extreme-tail case ", Index, " has a finite compiled target"), Cv$Valid)
    if (Cv$Valid) ExtremeError <- max(ExtremeError, abs(Cv$LogTarget - Rv$LogTarget)/(1 + abs(Rv$LogTarget)), max(abs(Cv$Scores - Rv$Scores)/(1 + abs(Rv$Scores))))
  }
  Record("Extreme-tail targets and scores versus independent R (relative errors)", ExtremeError, 0, 1e-7)

  # Mixed zero-positive mass/density has a closed-form conditional Gaussian expression.
  BivariateErrors <- numeric(3)
  Configurations <- list(c(.17, .28, .72, .6), c(.6, .1, -.3, 2), c(.05, .35, .9, .2))
  for (Index in seq_along(Configurations)) {
    Cfg <- Configurations[[Index]]
    P1 <- Cfg[1]
    P2 <- Cfg[2]
    Rho <- Cfg[3]
    Yp <- Cfg[4]
    ThetaValue <- Theta
    ThetaValue[1 : 4] <- qlogis(c(P1, P2, .2, .2))
    ThetaValue[5 : 6] <- 0
    ThetaValue[7 : 10] <- log(1.3)
    ThetaValue[11 : 12] <- 0
    ThetaValue[13 : 16] <- log(c(1.1, .7, 1.4, .9))
    ThetaValue[17] <- qlogis((1 + Rho)/2)
    Outcome <- matrix(c(0, Yp, NA, NA), 1, 4)
    Design <- matrix(0, 1, 2)
    DensityV <- function(V) {
      vapply(V, function(LogAuxiliary) {
        exp(Evaluate(
          ThetaValue, Outcome, Design, c(0, 4, 8, 12),
          matrix(log(LogAuxiliary), 1, 4)
        )$LogAugmentedLikelihood)
      }, numeric(1))
    }
    Aug <- integrate(DensityV, 0, 1, abs.tol = 1e-12, rel.tol = 1e-9, subdivisions = 500)$value
    Shape <- 1/expm1(exp(2*ThetaValue[14]))
    Sc <- exp(ThetaValue[8])/Shape
    Z2 <- qnorm(P2 + (1 - P2)*pgamma(Yp, shape = Shape, scale = Sc))
    Exact <- (1 - P2)*dgamma(Yp, shape = Shape, scale = Sc)*pnorm((qnorm(P1) - Rho*Z2)/sqrt(1 - Rho^2))
    BivariateErrors[Index] <- abs(Aug/Exact - 1)
  }
  Record("Integrated compiled zero-positive density versus analytic likelihood", max(BivariateErrors), 0, 2e-7)

  # Both-zero probability checked on uniform and Gaussian integration scales.
  P1 <- .17
  P2 <- .28
  Rho <- .72
  ZzV <- integrate(function(V) P1*pnorm((qnorm(P2) - Rho*qnorm(P1*V))/sqrt(1 - Rho^2)), 0, 1,
    abs.tol = 1e-12, rel.tol = 1e-10
  )$value
  ZzZ <- integrate(function(Scores) dnorm(Scores)*pnorm((qnorm(P2) - Rho*Scores)/sqrt(1 - Rho^2)), -Inf, qnorm(P1),
    abs.tol = 1e-12, rel.tol = 1e-10
  )$value
  Record("Both-zero probability: uniform-coordinate versus Gaussian integration", ZzV, ZzZ, 1e-10)

  # The scaled-beta density on rho includes 1/2; its coordinate Jacobian includes 2.
  Outcome <- matrix(NA_real_, 1, 4)
  Design <- matrix(0, 1, 2)
  LogAuxiliary <- matrix(log(.5), 1, 4)
  JacError <- 0
  for (Eta in c(-10, -3, 0, 3, 10)) {
    ThetaValue <- Theta
    ThetaValue[17] <- Eta
    Lp <- Evaluate(ThetaValue, Outcome, Design, Weeks, LogAuxiliary, PriorMean, PriorSd, 2.5, 3.5)$LogPrior
    Q <- plogis(Eta)
    Expected <- sum(dnorm(ThetaValue[1 : 16], PriorMean, PriorSd, log = TRUE)) +
      dbeta(Q, 2.5, 3.5, log = TRUE) - log(2) + log(2*Q*(1 - Q))
    JacError <- max(JacError, abs(Lp - Expected))
  }
  Record("Compiled transformed Beta prior includes logistic Jacobian", JacError, 0, 1e-10)
  TransformedDensity <- function(Eta) {
    vapply(Eta, function(E) {
      ThetaValue <- Theta
      ThetaValue[17] <- E
      exp(Evaluate(ThetaValue, Outcome, Design, Weeks, LogAuxiliary, PriorMean, PriorSd, 2.5, 3.5)$LogPrior -
        sum(dnorm(ThetaValue[1 : 16], PriorMean, PriorSd, log = TRUE)))
    }, numeric(1))
  }
  PriorIntegral <- integrate(TransformedDensity, -25, 25, abs.tol = 1e-10, rel.tol = 1e-10)$value
  Record("Transformed correlation prior integrates to one", PriorIntegral, 1, 2e-9)

  # A one-visit synthetic example isolates an exact logistic posterior.
  # Every subject has only visit 1 observed, so all copula terms are identically one.
  # The zero-intercept posterior is proportional to Binomial(15/50)*N(0,2^2).
  # This tests the complete adaptive-warmup/fixed-kernel sampler, not just its density.
  message("Checking a sampled posterior against one-dimensional numerical integration...")
  Nzero <- 15
  Npositive <- 35
  ParticipantCount <- Nzero + Npositive
  Outcome <- matrix(NA_real_, ParticipantCount, 4)
  Outcome[, 1] <- c(rep(0, Nzero), qgamma(ppoints(Npositive), shape = 1/expm1(.8^2), scale = expm1(.8^2)))
  Design <- matrix(0, ParticipantCount, 2)
  Pm2 <- rep(0, 16)
  Pm2[13 : 16] <- log(.8)
  Ps2 <- rep(.03, 16)
  Ps2[1] <- 2
  ThetaValue <- c(Pm2, 0)
  ThetaValue[1] <- qlogis(Nzero/ParticipantCount)
  ZeroCovariance <- diag(.0003, 6)
  ZeroCovariance[1, 1] <- .08
  PositiveCovariance <- diag(.0003, 10)
  CorrelationCovariance <- matrix(.5)
  set.seed(190622)
  LogisticChain <- RunGammaChainCpp(Outcome, Design, c(0, 4, 8, 12), ThetaValue, Pm2, Ps2, list(ZeroCovariance, PositiveCovariance, CorrelationCovariance),
    WarmupDraws = 3000, SampleDraws = 20000, AdaptEvery = 50, ZeroSweeps = 1, RhoA = 2, RhoB = 2
  )
  Logdensity <- function(A) dbinom(Nzero, ParticipantCount, plogis(A), log = TRUE) + dnorm(A, 0, 2, log = TRUE)
  Mode <- optimize(function(A) -Logdensity(A), c(-10, 10))$minimum
  Scale <- Logdensity(Mode)
  Kernel <- function(A) exp(Logdensity(A) - Scale)
  Normalizer <- integrate(Kernel, -12, 12, abs.tol = 1e-11)$value
  ExactMean <- integrate(function(A) A*Kernel(A), -12, 12, abs.tol = 1e-11)$value/Normalizer
  ExactSecond <- integrate(function(A) A*A*Kernel(A), -12, 12, abs.tol = 1e-11)$value/Normalizer
  ExactSd <- sqrt(ExactSecond - ExactMean^2)
  Sampled <- LogisticChain$Draws[, 1]
  Batches <- colMeans(matrix(Sampled, nrow = 200))
  Mcse <- sd(Batches)/sqrt(length(Batches))
  Record(
    "Sampled logistic posterior mean versus numerical integration", mean(Sampled), ExactMean,
    max(.01, 5*Mcse), paste("Batch-means MCSE:", signif(Mcse, 5))
  )
  Record("Sampled logistic posterior SD versus numerical integration", sd(Sampled), ExactSd, .025)
  Aux <- exp(LogisticChain$LogVZeros[, 1])
  Record(
    "Exact zero Gibbs auxiliaries have Uniform(0,1) mean for one observed visit", mean(Aux), .5,
    6/sqrt(12*length(Aux))
  )
  RhoDraws <- tanh(LogisticChain$Draws[, 17]/2)
  RhoBatches <- colMeans(matrix(RhoDraws, nrow = 200))
  RhoMcse <- sd(RhoBatches)/sqrt(length(RhoBatches))
  Record(
    "Unidentified correlation posterior retains its scaled Beta(2,2) prior mean", mean(RhoDraws), 0,
    max(.01, 5*RhoMcse)
  )
  CheckCondition("Sampled targets and zero auxiliary draws are finite", all(is.finite(LogisticChain$LogPosterior)) &&
    all(is.finite(LogisticChain$LogVZeros)) && all(LogisticChain$LogVZeros < 0))
  CheckCondition("All sampler blocks moved in the independent-posterior check", all(LogisticChain$Acceptance > .05) & all(LogisticChain$Acceptance < .8))
  # Saved latent columns use subject-major zero indexing. Reconstruct selected joint draws.
  ReconstructionError <- 0
  for (Iter in c(1, 3000, 10000, 20000)) {
    Lv <- matrix(0, ParticipantCount, 4)
    Lv[LogisticChain$ZeroIndex] <- LogisticChain$LogVZeros[Iter, ]
    Reevaluated <- Evaluate(LogisticChain$Draws[Iter, ], Outcome, Design, c(0, 4, 8, 12), Lv, Pm2, Ps2)
    ReconstructionError <- max(ReconstructionError, abs(Reevaluated$LogTarget - LogisticChain$LogPosterior[Iter]))
  }
  Record("Saved parameter and zero-auxiliary draws reconstruct their joint targets", ReconstructionError, 0, 1e-8)

  # Both families have exactly the same mean and CV for the same (eta,d).
  Grid <- expand.grid(D = c(.1, .4, .8, 1.2, 2), Mean = c(.1, 1, 5))
  GammaVar <- Grid$Mean^2/(1/expm1(Grid$D^2))
  LognormalVar <- Grid$Mean^2*expm1(Grid$D^2)
  Record("Gamma and lognormal parameters match positive means and variances", GammaVar, LognormalVar, 1e-10)
  # Changing the observation unit changes only the continuous density Jacobian.
  ThetaValue <- Theta
  A <- Evaluate(ThetaValue, OutcomeMatrix, DesignMatrix, Weeks, LogV)
  ThetaValue[7 : 10] <- ThetaValue[7 : 10] + log(1000)
  B <- Evaluate(ThetaValue, OutcomeMatrix*1000, DesignMatrix, Weeks, LogV)
  Record(
    "Unit-change density Jacobian", B$LogAugmentedLikelihood - A$LogAugmentedLikelihood,
    -sum(OutcomeMatrix > 0, na.rm = TRUE)*log(1000), 1e-8
  )
  Record("Unit-change Gaussian scores invariant", B$Scores, A$Scores, 1e-10)

  # Exact 2D posterior for one positive-margin intercept and its visit-specific dispersion.
  # A single observed visit makes the zero likelihood independent of these two
  # coordinates. All remaining positive coefficients are either zero-design or
  # unobserved. Numerical integration therefore gives their exact marginal target.
  Npositive <- 40
  Nzero <- 10
  PositiveY <- qgamma(ppoints(Npositive), shape = 1.7, scale = 1.2/1.7)
  Outcome <- matrix(NA_real_, Npositive + Nzero, 4)
  Outcome[, 1] <- c(rep(0, Nzero), PositiveY)
  Design <- matrix(0, nrow(Outcome), 2)
  Pm3 <- rep(0, 16)
  Ps3 <- rep(1, 16)
  Ps3[1 : 4] <- 2
  Ps3[7 : 10] <- 1.5
  Ps3[13 : 16] <- .6
  Logkernel <- function(LogMean, LogDispersion) {
    Shape <- 1/expm1(exp(2*LogDispersion))
    sum(dgamma(PositiveY, shape = Shape, scale = exp(LogMean)/Shape, log = TRUE)) +
      dnorm(LogMean, 0, 1.5, log = TRUE) + dnorm(LogDispersion, 0, .6, log = TRUE)
  }
  Opt <- optim(c(log(1.2), log(sqrt(log1p(1/1.7)))), function(V) -Logkernel(V[1], V[2]))
  Offset <- -Opt$value
  Moment <- function(MuPower = 0, LdPower = 0) {
    integrate(
      function(LogDispersion) {
        vapply(LogDispersion, function(L) {
          integrate(
            function(LogMean) {
              vapply(LogMean, function(M) {
                M^MuPower*L^LdPower*exp(Logkernel(M, L) - Offset)
              }, numeric(1))
            },
            -6, 6,
            rel.tol = 2e-8, abs.tol = 1e-10, subdivisions = 300
          )$value
        }, numeric(1))
      },
      -3, 1.5,
      rel.tol = 2e-7, abs.tol = 1e-10, subdivisions = 300
    )$value
  }
  Norm <- Moment()
  ExactMu <- Moment(1)/Norm
  ExactLd <- Moment(0, 1)/Norm
  ExactMuSd <- sqrt(Moment(2)/Norm - ExactMu^2)
  ThetaValue <- c(Pm3, 0)
  ThetaValue[1] <- qlogis(Nzero/nrow(Outcome))
  ThetaValue[7] <- Opt$par[1]
  ThetaValue[13] <- Opt$par[2]
  PositiveCovariance <- diag(.12, 10)
  PositiveCovariance[c(1, 7), c(1, 7)] <- diag(c(.04, .02))
  set.seed(221008)
  GammaChain <- RunGammaChainCpp(Outcome, Design, c(0, 4, 8, 12), ThetaValue, Pm3, Ps3,
    list(diag(.12, 6), PositiveCovariance, matrix(.5)),
    WarmupDraws = 6000, SampleDraws = 40000
  )
  McseFor <- function(V) sd(colMeans(matrix(V, nrow = 400)))/sqrt(length(V)/400)
  Record(
    "Sampled gamma log-mean posterior versus exact 2D integration", mean(GammaChain$Draws[, 7]), ExactMu,
    max(.012, 5*McseFor(GammaChain$Draws[, 7]))
  )
  Record(
    "Sampled gamma log-dispersion posterior versus exact 2D integration", mean(GammaChain$Draws[, 13]), ExactLd,
    max(.012, 5*McseFor(GammaChain$Draws[, 13]))
  )
  Record("Sampled gamma log-mean posterior SD versus exact integration", sd(GammaChain$Draws[, 7]), ExactMuSd, .025)


  # Exact continuation: no random draws are consumed merely by restarting a
  # block, and both proposal factors and zero auxiliaries must be restored.
  message("Checking exact chain continuation and checkpoint restoration...")
  ContinuationOutcome <- OutcomeMatrix
  ContinuationDesign <- DesignMatrix
  ContinuationTheta <- Theta
  Covariances <- list(diag(.02, 6), diag(.02, 10), matrix(.05))
  set.seed(2026102209)
  Whole <- RunGammaChainCpp(ContinuationOutcome, ContinuationDesign, Weeks,
    ContinuationTheta, PriorMean, PriorSd, Covariances,
    WarmupDraws = 700, SampleDraws = 1000
  )
  WholeSeed <- .Random.seed
  set.seed(2026102209)
  First <- RunGammaChainCpp(ContinuationOutcome, ContinuationDesign, Weeks,
    ContinuationTheta, PriorMean, PriorSd, Covariances,
    WarmupDraws = 700, SampleDraws = 400
  )
  Saved <- list(State = First$ChainState, Seed = .Random.seed)
  CheckpointPath <- tempfile(fileext = ".rds")
  on.exit(unlink(CheckpointPath), add = TRUE)
  saveRDS(Saved, CheckpointPath)
  invisible(runif(100))
  Saved <- readRDS(CheckpointPath)
  assign(".Random.seed", Saved$Seed, envir = .GlobalEnv)
  Second <- RunGammaChainCpp(ContinuationOutcome, ContinuationDesign, Weeks,
    Saved$State$Theta, PriorMean, PriorSd, Covariances,
    WarmupDraws = 0, SampleDraws = 600, Continuation = Saved$State
  )
  Record(
    "Continued parameter draws equal one uninterrupted chain",
    rbind(First$Draws, Second$Draws), Whole$Draws, 0
  )
  Record(
    "Continued zero auxiliaries equal one uninterrupted chain",
    rbind(First$LogVZeros, Second$LogVZeros), Whole$LogVZeros, 0
  )
  Record(
    "Continued joint targets equal one uninterrupted chain",
    c(First$LogPosterior, Second$LogPosterior), Whole$LogPosterior, 0
  )
  CheckCondition("Checkpoint restoration preserves the exact RNG state", identical(.Random.seed, WholeSeed))
  CheckCondition("Continuation rejects new adaptive warmup", inherits(try(
    RunGammaChainCpp(ContinuationOutcome, ContinuationDesign, Weeks,
      Saved$State$Theta, PriorMean, PriorSd, Covariances,
      WarmupDraws = 1,
      SampleDraws = 20, Continuation = Saved$State
    ),
    silent = TRUE
  ), "try-error"))

  # Controlled diagnostics exercise failure paths independently of
  # stochastic convergence in the synthetic examples.
  FakeBlock <- function(Block) {
    lapply(1 : 4, function(Chain) {
      list(
        Draws = matrix(Block, 4, 17),
        LogVZeros = matrix(-1, 4, 1), LogAugmentedLikelihood = rep(0, 4),
        LogPosterior = rep(0, 4), Acceptance = rep(.25, 3), ElapsedSeconds = 0,
        InvalidProposals = 0, Block = Block, Chain = Chain
      )
    })
  }
  FakeCheck <- function(RhatPassed, EssPassed) {
    list(
      Summary = data.frame(
        Rhat = if (RhatPassed) 1.01 else 1.2,
        BulkEss = if (EssPassed) 500 else 100, TailEss = if (EssPassed) 500 else 100
      ),
      RhatPassed = RhatPassed, EssPassed = EssPassed, Converged = RhatPassed && EssPassed
    )
  }
  Delayed <- RunMcmcStages(FakeBlock, function(Chains) {
    FakeCheck(min(Chains[[1]]$Draws) >= 3, nrow(Chains[[1]]$Draws) >= 12)
  }, MaxWarmupBlocks = 5, MaxSamplingBlocks = 5)
  CheckCondition(
    "Warmup screen discards only blocks before the first R-hat pass",
    identical(Delayed$WarmupBlocks, 1 : 2) && Delayed$FirstPassingBlock == 3
  )
  CheckCondition(
    "Retained sample includes the first passing block and every continuation draw",
    all(Delayed$SummaryBlocks == 3 : 5) && nrow(Delayed$Chains[[1]]$Draws) == 12 &&
      all(Delayed$Chains[[1]]$Draws[, 1] == rep(3 : 5, each = 4)) && Delayed$Converged
  )
  NoPass <- RunMcmcStages(FakeBlock, function(Chains) FakeCheck(FALSE, FALSE), 3, 3)
  CheckCondition(
    "No R-hat pass returns the latest block with a failure flag",
    NoPass$Status == "WarmupLimitReached" && !NoPass$Converged &&
      !length(NoPass$RetainedBlocks) && NoPass$SummaryBlocks == 3 &&
      all(NoPass$Chains[[1]]$Draws == 3)
  )
  LowEss <- RunMcmcStages(FakeBlock, function(Chains) FakeCheck(TRUE, FALSE), 3, 3)
  CheckCondition(
    "Sampling limit retains all post-screen draws with a failure flag",
    LowEss$Status == "SamplingLimitReached" && !LowEss$Converged &&
      all(LowEss$RetainedBlocks == 1 : 3) && nrow(LowEss$Chains[[1]]$Draws) == 12
  )
  Immediate <- RunMcmcStages(FakeBlock, function(Chains) FakeCheck(TRUE, TRUE), 5, 5)
  CheckCondition(
    "Already converged first block needs no additional sampling",
    Immediate$Converged && length(Immediate$SummaryBlocks) == 1
  )

  Results <- do.call(rbind, Checks)
  write.csv(Results, file.path(Output, "05GammaValidationChecks.csv"), row.names = FALSE)
  Details <- list(
    Checks = Results, SamplerHash = SamplerHash, ElapsedSeconds = proc.time()[[3]] - Started,
    GammaPosterior = list(ExactMu = ExactMu, SampledMu = mean(GammaChain$Draws[, 7]), ExactLd = ExactLd, SampledLd = mean(GammaChain$Draws[, 13])),
    IsolatedPosterior = list(
      ExactMean = ExactMean, SampledMean = mean(Sampled), Mcse = Mcse,
      ExactSd = ExactSd, SampledSd = sd(Sampled), Acceptance = LogisticChain$Acceptance,
      RhoMean = mean(RhoDraws), RhoMcse = RhoMcse
    ), SessionInfo = capture.output(sessionInfo())
  )
  saveRDS(Details, file.path(Output, "05GammaValidation.rds"))
  writeLines(c(
    "Independent numerical validation of the gamma semicontinuous sampler", paste("C++ SHA-256:", SamplerHash),
    paste("Checks passed:", sum(Results$Passed), "of", nrow(Results)),
    paste("Elapsed seconds:", round(Details$ElapsedSeconds, 2)),
    "Synthetic inputs only; no application data were modified or imputed.",
    "The short exact-posterior check validates one identifiable logistic coordinate and a prior-only correlation coordinate.",
    "Gamma log-mean and log-dispersion posteriors are also checked against two-dimensional numerical integration.",
    "It is not a simulation study establishing performance for longitudinal missing-data applications.",
    "All likelihood checks concern the mixed augmented target; its value is not an integrated observed-data likelihood for LOO/WAIC.",
    "", Details$SessionInfo
  ), file.path(Output, "05GammaValidationSummary.txt"))
  if (any(!Results$Passed)) stop("Sampler validation failed: ", paste(Results$Check[!Results$Passed], collapse = "; "))
  message("All ", nrow(Results), " validation checks passed. Results: ", Output)
}
