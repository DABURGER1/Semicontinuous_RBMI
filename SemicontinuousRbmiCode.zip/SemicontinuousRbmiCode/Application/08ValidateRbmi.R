# Stage 08. Independent checks of completion, analysis, pooling and provenance.
# Synthetic data only. The fitted EXALT outcomes and chains are never altered.
RbmiExampleData <- function(Subjects = 128, Seed = 39261) {
  set.seed(Seed)
  Weeks <- c(4, 12, 20, 26)
  Treatment <- rep(c(0, 1), length.out = Subjects)
  Baseline <- as.numeric(scale(rnorm(Subjects)))
  Design <- cbind(Treatment = Treatment, Baseline = Baseline)
  Shape <- c(.8, 1.2, 1.8, 2.4)
  Theta <- c(rep(qlogis(.25), 4), log(1.7), -.25, log(c(1.4, 1.3, 1.2, 1.1)), log(.7), .3,
    log(sqrt(log1p(1/Shape))), qlogis((1 + .72)/2))
  names(Theta) <- GammaParameterNames(Weeks)
  Correlation <- .72^abs(outer(seq_along(Weeks), seq_along(Weeks), `-`))
  Scores <- matrix(rnorm(Subjects*4), Subjects, 4)%*%chol(Correlation)
  Full <- matrix(0, Subjects, 4)
  for (Visit in 1 : 4) {
    Pi <- plogis(Theta[Visit] + Theta[5]*Treatment + Theta[6]*Baseline)
    Mean <- exp(Theta[6 + Visit] + Theta[11]*Treatment + Theta[12]*Baseline)
    U <- pnorm(Scores[, Visit])
    Positive <- U > Pi
    Full[Positive, Visit] <- qgamma((U[Positive] - Pi[Positive])/(1 - Pi[Positive]),
      shape = Shape[Visit], scale = Mean[Positive]/Shape[Visit])
  }
  Pattern <- rep(0 : 15, length.out = Subjects)
  Mask <- sapply(0 : 3, function(Visit) bitwAnd(Pattern, bitwShiftL(1, Visit)) > 0)
  Outcome <- Full
  Outcome[Mask] <- NA_real_
  Data <- list(Outcome = Outcome, Design = Design, Weeks = Weeks, UnitScale = 1,
    Id = paste0("Synthetic", seq_len(Subjects)), GroupCode = Treatment + 1,
    ParameterNames = names(Theta), PositiveFamily = "Gamma", ShapeStructure = "VisitSpecific", View = "Synthetic",
    TreatmentLabels = c("Reference", "Active"), Notes = "Synthetic validation data, not EXALT.")
  ZeroIndex <- which(!is.na(Outcome) & Outcome == 0, arr.ind = TRUE)
  LogV <- vapply(seq_len(nrow(ZeroIndex)), function(Index) {
    Subject <- ZeroIndex[Index, 1]
    Visit <- ZeroIndex[Index, 2]
    pnorm(Scores[Subject, Visit], log.p = TRUE) -
      plogis(Theta[Visit] + Theta[5]*Treatment[Subject] + Theta[6]*Baseline[Subject], log.p = TRUE)
  }, numeric(1))
  list(Data = Data, Full = Full, Theta = Theta, Scores = Scores, ZeroIndex = ZeroIndex, LogV = LogV)
}

# Independent R implementation at one parameter/auxiliary draw. Ordinary
# probabilities are sufficient for the moderate inputs used in this comparison.
ReferenceRbmiCompletion <- function(Data, Theta, LogV, ZeroIndex, Layout, Rules) {
  Shape <- 1/expm1(exp(2*Theta[13 : 16]))
  Correlation <- tanh(Theta[17]/2)^abs(outer(seq_along(Data$Weeks), seq_along(Data$Weeks), `-`))
  Completed <- array(NA_real_, c(nrow(Data$Outcome), 4, nrow(Rules)))
  for (Rule in seq_len(nrow(Rules))) Completed[, , Rule] <- Data$Outcome
  ZeroMap <- matrix(NA_real_, nrow(Data$Outcome), 4)
  ZeroMap[ZeroIndex] <- LogV
  for (Subject in seq_len(nrow(Data$Outcome))) {
    Observed <- which(Layout$Observed[Subject, ])
    Missing <- which(Layout$Missing[Subject, ])
    EtaZero <- Theta[1 : 4] + Theta[5]*Data$Design[Subject, 1] + Theta[6]*Data$Design[Subject, 2]
    EtaPositive <- Theta[7 : 10] + Theta[11]*Data$Design[Subject, 1] + Theta[12]*Data$Design[Subject, 2]
    Pi <- plogis(EtaZero)
    Scores <- vapply(Observed, function(Visit) {
      Value <- Data$Outcome[Subject, Visit]
      if (Value == 0) qnorm(Pi[Visit]*exp(ZeroMap[Subject, Visit])) else {
        qnorm(Pi[Visit] + (1 - Pi[Visit])*pgamma(Value/Data$UnitScale, shape = Shape[Visit], scale = exp(EtaPositive[Visit])/Shape[Visit]))
      }
    }, numeric(1))
    if (!length(Missing)) next
    Variance <- Correlation[Missing, Missing, drop = FALSE]
    Mean <- rep(0, length(Missing))
    if (length(Observed)) {
      Regression <- Correlation[Missing, Observed, drop = FALSE]%*%solve(Correlation[Observed, Observed, drop = FALSE])
      Mean <- as.vector(Regression%*%Scores)
      Variance <- Variance - Regression%*%Correlation[Observed, Missing, drop = FALSE]
    }
    Z <- Mean + as.vector(t(chol(Variance))%*%rnorm(length(Missing)))
    for (Rule in seq_len(nrow(Rules))) {
      for (Index in seq_along(Missing)) {
        Visit <- Missing[Index]
        PiRule <- plogis(EtaZero[Visit] - Rules$ZeroWeight[Rule]*Layout$Borrow[Subject, Visit]*Theta[5]*Data$Design[Subject, 1])
        MeanRule <- exp(EtaPositive[Visit] - Rules$PositiveWeight[Rule]*Layout$Borrow[Subject, Visit]*Theta[11]*Data$Design[Subject, 1])
        U <- pnorm(Z[Index])
        Completed[Subject, Visit, Rule] <- if (U <= PiRule) 0 else {
          Data$UnitScale*qgamma((U - PiRule)/(1 - PiRule), shape = Shape[Visit], scale = MeanRule/Shape[Visit])
        }
      }
    }
  }
  Completed
}

ValidateRbmi <- function(ApplicationPath) {
  CheckPackages(c("Rcpp", "RcppArmadillo", "posterior", "digest"))
  LoadRbmiCpp(ApplicationPath)
  Checks <- list()
  Check <- function(Name, Expression) {
    Error <- ""
    Passed <- tryCatch(isTRUE(force(Expression)), error = function(Condition) {
      Error <<- conditionMessage(Condition)
      FALSE
    })
    Checks[[length(Checks) + 1]] <<- data.frame(Check = Name, Passed = Passed, Detail = Error)
  }
  Near <- function(First, Second, Tolerance = 1e-9) {
    all(is.finite(First)) && all(is.finite(Second)) && max(abs(First - Second)) <= Tolerance*max(1, max(abs(Second)))
  }
  Fails <- function(Expression) tryCatch({force(Expression); FALSE}, error = function(Condition) TRUE)
  Example <- RbmiExampleData(64)
  Data <- Example$Data
  Chain <- list(Draws = matrix(Example$Theta, 1, 17, dimnames = list(NULL, Data$ParameterNames)),
    LogVZeros = matrix(Example$LogV, 1), ZeroIndex = Example$ZeroIndex)
  Fit <- list(Data = Data, Chains = list(Chain), PositiveFamily = "Gamma")
  Rules <- RbmiRules()
  Eligibility <- matrix(TRUE, nrow(Data$Outcome), 4)
  Layout <- RbmiLayout(Data, Eligibility)
  Analysis <- RbmiAnalysisDesign(Data)
  set.seed(825)
  Native <- CompleteRbmiChain(Fit, Chain, Layout, Rules, Analysis, 1)
  set.seed(825)
  Reference <- ReferenceRbmiCompletion(Data, Example$Theta, Example$LogV, Example$ZeroIndex, Layout, Rules)
  Check("Independent R and C++ completion across all 16 observation patterns", Near(Native$Examples[, , , 1], Reference))
  for (Rho in c(-.8, 0, .8)) {
    SignedTheta <- Example$Theta
    SignedTheta[17] <- qlogis((1 + Rho)/2)
    SignedChain <- Chain
    SignedChain$Draws[1, 17] <- SignedTheta[17]
    set.seed(826)
    SignedNative <- CompleteRbmiChain(Fit, SignedChain, Layout, Rules, Analysis, 1)
    set.seed(826)
    SignedReference <- ReferenceRbmiCompletion(Data, SignedTheta, Example$LogV, Example$ZeroIndex, Layout, Rules)
    Check(paste("Signed correlation completion:", Rho), Near(SignedNative$Examples[, , , 1], SignedReference))
  }
  for (Rule in seq_len(nrow(Rules))) {
    Completed <- Native$Examples[, , Rule, 1]
    Check(paste("Retained values preserved:", Rules$Rule[Rule]), identical(as.numeric(Completed[Layout$Observed]), as.numeric(Data$Outcome[Layout$Observed])))
    Frame <- data.frame(Y = Completed[, 4], A = Data$Design[, 1], B = Data$Design[, 2] - mean(Data$Design[, 2]))
    LinearFit <- lm(Y ~ A*B, data = Frame)
    W <- model.matrix(LinearFit)
    Inverse <- solve(crossprod(W))
    Meat <- crossprod(W, W*(resid(LinearFit)/(1 - hatvalues(LinearFit)))^2)
    Covariance <- Inverse%*%Meat%*%Inverse
    StandardizationVariance <- unname(coef(LinearFit)[4]^2*var(Frame$B)/nrow(Frame))
    Check(paste("Independent lm and population variance analysis:", Rules$Rule[Rule]),
      Near(Native$Statistics[1, Rule, "Estimate"], coef(LinearFit)[2]) &&
        Near(Native$CoefficientVariance[1, Rule], Covariance[2, 2]) &&
        Near(Native$StandardizationVariance[1, Rule], StandardizationVariance) &&
        Near(Native$Statistics[1, Rule, "WithinVariance"], Covariance[2, 2] + StandardizationVariance))
  }
  Check("Variance components are finite, nonnegative and sum to the reported variance",
    all(is.finite(Native$CoefficientVariance)) && all(Native$CoefficientVariance >= 0) &&
      all(is.finite(Native$StandardizationVariance)) && all(Native$StandardizationVariance >= 0) &&
      Near(Native$Statistics[, , "WithinVariance"], Native$CoefficientVariance + Native$StandardizationVariance))
  Continuation <- which(Rules$Rule == "Continuation")
  PositiveOnly <- which(Rules$Rule == "PositiveReference")
  ZeroOnly <- which(Rules$Rule == "AbstinenceReference")
  J2r <- which(Rules$Rule == "JumpToReference")
  Check("Positive borrowing leaves zero indicators unchanged",
    identical(Native$Examples[, , Continuation, 1] == 0, Native$Examples[, , PositiveOnly, 1] == 0))
  Check("Beneficial coefficient signs give paired amount ordering",
    all(Native$Examples[, , J2r, 1] >= Native$Examples[, , Continuation, 1]) &&
      all(Native$Examples[, , ZeroOnly, 1] >= Native$Examples[, , Continuation, 1]))
  Check("Reference-arm completions do not change across rules", all(vapply(seq_len(nrow(Rules)), function(Rule) {
    identical(Native$Examples[Data$Design[, 1] == 0, , Rule, 1], Native$Examples[Data$Design[, 1] == 0, , Continuation, 1])
  }, logical(1))))
  Intermittent <- Layout$Missing & !Layout$Borrow
  Check("Intermittent completions do not borrow", all(vapply(seq_len(nrow(Rules)), function(Rule) {
    identical(Native$Examples[, , Rule, 1][Intermittent], Native$Examples[, , Continuation, 1][Intermittent])
  }, logical(1))))
  Check("No-follow-up trigger is visit one", all(Layout$Trigger[rowSums(Layout$Observed) == 0] == 1))
  Check("Observed-final trigger is after the last visit", all(Layout$Trigger[Layout$Observed[, 4]] == 5))
  set.seed(825)
  Reversed <- CompleteRbmiChain(Fit, Chain, Layout, Rules[nrow(Rules) : 1, ], Analysis, 1)
  Check("Rule ordering does not change completions", Near(Reversed$Examples[, , nrow(Rules) : 1, 1], Native$Examples[, , , 1]))
  IndependentChain <- Chain
  # Zero on the scaled-logit coordinate gives exact independence (rho = 0).
  IndependentChain$Draws[1, 17] <- 0
  IndependentTheta <- Example$Theta
  IndependentTheta[17] <- 0
  set.seed(57)
  Independent <- CompleteRbmiChain(Fit, IndependentChain, Layout, Rules, Analysis, 1)
  set.seed(57)
  IndependentReference <- ReferenceRbmiCompletion(Data, IndependentTheta, Example$LogV,
    Example$ZeroIndex, Layout, Rules)
  Check("Independent copula matches ordinary marginal completion", Near(Independent$Examples[, , , 1], IndependentReference))
  ScaledFit <- Fit
  ScaledFit$Data$Outcome <- Data$Outcome*1000
  ScaledFit$Data$UnitScale <- 1000
  set.seed(825)
  Scaled <- CompleteRbmiChain(ScaledFit, Chain, Layout, Rules, Analysis, 1)
  Check("Changing units scales amounts and variances correctly", Near(Scaled$Examples[, , , 1], Reference*1000) &&
    Near(Scaled$Statistics[, , "WithinVariance"], Native$Statistics[, , "WithinVariance"]*1000^2))
  Undefined <- Eligibility
  Position <- which(Layout$Missing[, 1])[1]
  Undefined[Position, 1] <- FALSE
  Reduced <- RbmiLayout(Data, Undefined)
  set.seed(825)
  ReducedResult <- CompleteRbmiChain(Fit, Chain, Reduced, Rules, Analysis, 1)
  Check("Undefined nonfinal outcomes are left missing", all(is.na(ReducedResult$Examples[Position, 1, , 1])))
  Unknown <- Eligibility
  Unknown[Position, 1] <- NA
  Check("Unresolved outcome definitions prevent imputation", Fails(RbmiLayout(Data, Unknown)))
  Undefined[Position, 4] <- FALSE
  Check("Undefined final outcomes cannot be silently excluded", Fails(RbmiLayout(Data, Undefined)))
  InvalidChain <- Chain
  InvalidChain$LogVZeros[1, 1] <- 0
  Check("Invalid zero auxiliary draws are rejected", Fails(CompleteRbmiChain(Fit, InvalidChain, Layout, Rules, Analysis, 1)))
  Check("Weights outside the allowed range are rejected", Fails(RbmiRules(c(0, 2))))
  CompleteFit <- Fit
  CompleteFit$Data$Outcome <- Example$Full
  CompleteZero <- which(Example$Full == 0, arr.ind = TRUE)
  CompleteChain <- Chain
  CompleteChain$ZeroIndex <- CompleteZero
  CompleteChain$LogVZeros <- matrix(log(.5), 1, nrow(CompleteZero))
  FullLayout <- RbmiLayout(CompleteFit$Data, Eligibility)
  FullResult <- CompleteRbmiChain(CompleteFit, CompleteChain, FullLayout, Rules, Analysis, 1)
  Check("Fully observed data are returned unchanged", all(vapply(seq_len(nrow(Rules)), function(Rule) {
    identical(as.numeric(FullResult$Examples[, , Rule, 1]), as.numeric(Example$Full))
  }, logical(1))))
  # A noiseless heterogeneous treatment effect still has population uncertainty
  # because the empirical baseline mean varies between samples.
  DeterministicFit <- Fit
  DeterministicFit$Data$Outcome <- matrix(as.vector(Analysis$Design%*%c(20, 5, 2, 3)), nrow(Data$Outcome), 4)
  DeterministicChain <- Chain
  DeterministicChain$ZeroIndex <- matrix(integer(), 0, 2)
  DeterministicChain$LogVZeros <- matrix(numeric(), 1, 0)
  DeterministicLayout <- RbmiLayout(DeterministicFit$Data, Eligibility)
  Deterministic <- CompleteRbmiChain(DeterministicFit, DeterministicChain, DeterministicLayout,
    Rules[Continuation, ], Analysis, 1)
  ExpectedPopulationVariance <- 3^2*var(Data$Design[, 2])/nrow(Data$Outcome)
  Check("Heterogeneous noiseless outcomes retain population standardization variance",
    Deterministic$CoefficientVariance[1, 1] < 1e-20 && ExpectedPopulationVariance > 0 &&
      Near(Deterministic$Statistics[1, 1, "WithinVariance"], ExpectedPopulationVariance))
  CommonSlopeFit <- DeterministicFit
  CommonSlopeFit$Data$Outcome <- matrix(as.vector(Analysis$Design%*%c(20, 5, 2, 0)), nrow(Data$Outcome), 4)
  CommonSlope <- CompleteRbmiChain(CommonSlopeFit, DeterministicChain, DeterministicLayout,
    Rules[Continuation, ], Analysis, 1)
  Check("A zero treatment by baseline interaction has zero standardization contribution",
    CommonSlope$StandardizationVariance[1, 1] < 1e-20)
  AffineFit <- DeterministicFit
  AffineFit$Data$Design[, 2] <- 7 + 3*Data$Design[, 2]
  AffineAnalysis <- RbmiAnalysisDesign(AffineFit$Data)
  Affine <- CompleteRbmiChain(AffineFit, DeterministicChain, DeterministicLayout,
    Rules[Continuation, ], AffineAnalysis, 1)
  Check("Affine baseline rescaling preserves the estimate and population variance",
    Near(Affine$Statistics, Deterministic$Statistics) &&
      Near(Affine$StandardizationVariance, Deterministic$StandardizationVariance))
  MalformedAnalysis <- Analysis
  MalformedAnalysis$Design[, 3] <- MalformedAnalysis$Design[, 3] + 1
  Check("A noncentered analysis design is rejected", Fails(CompleteRbmiChain(DeterministicFit,
    DeterministicChain, DeterministicLayout, Rules[Continuation, ], MalformedAnalysis, 0)))
  MalformedAnalysis <- Analysis
  MalformedAnalysis$Design[, 4] <- MalformedAnalysis$Design[, 3]
  Check("An incorrect treatment interaction is rejected", Fails(CompleteRbmiChain(DeterministicFit,
    DeterministicChain, DeterministicLayout, Rules[Continuation, ], MalformedAnalysis, 0)))
  Pooled <- RubinPool(1 : 4, rep(1, 4), 60)
  Check("Rubin mean and between/total variance match hand calculations", Near(Pooled[c("Estimate", "BetweenVariance", "TotalVariance")], c(2.5, 5/3, 37/12)))
  CompletePool <- RubinPool(rep(3, 10), rep(2, 10), 60, CompleteOutcome = TRUE)
  Check("Complete final outcomes use the complete-data variance and df", CompletePool["Df"] == 60 && CompletePool["TotalVariance"] == 2)
  Check("Zero between-imputation variance has finite limiting df", is.finite(RubinPool(rep(3, 10), rep(2, 10), 60)["Df"]))
  Check("Degenerate all-zero analysis is explicitly finite", RubinPool(rep(0, 10), rep(0, 10), 60)["StandardError"] == 0)
  Check("Invalid within-imputation variances are rejected", Fails(RubinPool(1 : 4, c(1, 1, -1, 1), 60)))
  Check("Constant summaries have zero Monte Carlo error", RbmiMonteCarlo(matrix(3, 50, 4))["Mcse"] == 0)
  # The conditional zero probability and positive CDF are checked by repeated
  # missing-value draws at fixed observed latent coordinates, independently of R/C++ agreement.
  Repetitions <- 6000
  RepeatedChain <- Chain
  RepeatedChain$Draws <- Chain$Draws[rep(1, Repetitions), , drop = FALSE]
  RepeatedChain$LogVZeros <- Chain$LogVZeros[rep(1, Repetitions), , drop = FALSE]
  set.seed(357)
  Repeated <- CompleteRbmiChain(Fit, RepeatedChain, Layout, Rules[c(Continuation, J2r), ], Analysis, Repetitions)
  Subject <- which(Layout$Missing[, 4] & rowSums(Layout$Observed) > 0 & Data$Design[, 1] == 1)[1]
  Observed <- which(Layout$Observed[Subject, ])
  Theta <- Example$Theta
  Correlation <- tanh(Theta[17]/2)^abs(outer(seq_along(Data$Weeks), seq_along(Data$Weeks), `-`))
  Regression <- Correlation[4, Observed, drop = FALSE]%*%solve(Correlation[Observed, Observed, drop = FALSE])
  H <- as.numeric(Regression%*%Example$Scores[Subject, Observed])
  S <- sqrt(1 - as.numeric(Regression%*%Correlation[Observed, 4, drop = FALSE]))
  for (Rule in 1 : 2) {
    Weight <- Rule - 1
    Pi <- plogis(Theta[4] + (1 - Weight)*Theta[5] + Theta[6]*Data$Design[Subject, 2])
    Mean <- exp(Theta[10] + (1 - Weight)*Theta[11] + Theta[12]*Data$Design[Subject, 2])
    Shape <- 1/expm1(exp(2*Theta[16]))
    for (Cut in c(0, 1.5)) {
      Probability <- pnorm((qnorm(Pi + (1 - Pi)*pgamma(Cut, shape = Shape, scale = Mean/Shape)) - H)/S)
      Empirical <- mean(Repeated$Examples[Subject, 4, Rule, ] <= Cut)
      Check(paste("Conditional CDF under rule", Rule, "at", Cut), abs(Empirical - Probability) <= 5*sqrt(Probability*(1 - Probability)/Repetitions) + .001)
    }
  }
  # Pool every row, including a distinctive final estimate, and retain flagged fits.
  SmallChains <- lapply(1 : 2, function(Index) {
    Statistics <- array(0, c(100, 1, 7), dimnames = list(NULL, "Continuation", dimnames(Native$Statistics)[[3]]))
    Statistics[, 1, "Estimate"] <- seq_len(100)/100 + Index/10
    Statistics[, 1, "WithinVariance"] <- 2
    list(Statistics = Statistics)
  })
  SmallChains[[2]]$Statistics[100, 1, "Estimate"] <- 20
  SmallSummary <- PoolRbmiChains(SmallChains, Rules[Continuation, ], 60, RbmiSettings(), FitConverged = FALSE)
  Expected <- mean(unlist(lapply(SmallChains, function(Item) Item$Statistics[, 1, "Estimate"])))
  Check("Pooling uses every row in every chain", SmallSummary$Imputations == 200 && Near(SmallSummary$Estimate, Expected))
  Check("Flagged input fits remain in the results", SmallSummary$Status == "InputFitFlagged" && nrow(SmallSummary) == 1)
  AllMissingFit <- Fit
  AllMissingFit$Data$Outcome[,] <- NA_real_
  EmptyChain <- Chain
  EmptyChain$ZeroIndex <- matrix(integer(), 0, 2)
  EmptyChain$LogVZeros <- matrix(numeric(), 1, 0)
  set.seed(47)
  AllMissing <- CompleteRbmiChain(AllMissingFit, EmptyChain, RbmiLayout(AllMissingFit$Data, Eligibility), Rules, Analysis, 1)
  Check("Entirely missing panels and zero-column auxiliaries are supported", all(is.finite(AllMissing$Examples)))
  PositiveFit <- Fit
  PositiveFit$Data$Outcome[!is.na(Data$Outcome) & Data$Outcome == 0] <- .4
  set.seed(47)
  NoZeros <- CompleteRbmiChain(PositiveFit, EmptyChain, Layout, Rules, Analysis, 1)
  Check("Panels without observed zeros need no auxiliary values", all(is.finite(NoZeros$Examples)))
  TailFit <- PositiveFit
  TailFit$Data$Outcome[1, 1] <- 100000
  set.seed(47)
  Tail <- CompleteRbmiChain(TailFit, EmptyChain, Layout, Rules, Analysis, 1)
  Check("Extreme retained positive values use stable tail probabilities", all(is.finite(Tail$Statistics)))
  # Check on-disk provenance and the RNG contract using a small synthetic fit.
  CacheFit <- Fit
  CacheFit$Data$Outcome[, 4] <- Example$Full[, 4]
  CacheZeros <- which(!is.na(CacheFit$Data$Outcome) & CacheFit$Data$Outcome == 0, arr.ind = TRUE)
  CacheFit$Chains <- lapply(1 : 2, function(Index) {
    Value <- Chain
    Value$Draws <- Chain$Draws[rep(1, 12), , drop = FALSE]
    Value$ZeroIndex <- CacheZeros
    Value$LogVZeros <- matrix(log(.5), 12, nrow(CacheZeros))
    Value
  })
  CacheFit$Settings <- GammaSettings()
  CacheFit$Convergence <- list(Converged = FALSE, Status = "SyntheticFixedDrawCheck", SummaryScope = "AllRetainedDraws", SummaryBlocks = 1)
  Scratch <- tempfile("RbmiValidation", tmpdir = tempdir())
  set.seed(319)
  SeedBefore <- .Random.seed
  FirstRun <- RunGammaRbmi(CacheFit, ApplicationPath, Eligibility, "CacheCheck", Rules[Continuation, ],
    RbmiSettings(ExampleCount = 0), OutputRoot = Scratch, Purpose = "Synthetic validation check")
  Check("Imputation restores the caller random-number state", identical(SeedBefore, .Random.seed))
  Paths <- list.files(file.path(Scratch, "CacheCheck"), pattern = "^Chain", full.names = TRUE)
  Hashes <- vapply(Paths, FileHash, character(1))
  SecondRun <- RunGammaRbmi(CacheFit, ApplicationPath, Eligibility, "CacheCheck", Rules[Continuation, ],
    RbmiSettings(ExampleCount = 0), OutputRoot = Scratch, Purpose = "Synthetic validation check")
  Check("Saved imputation checkpoints are reused without change", identical(Hashes, vapply(Paths, FileHash, character(1))) &&
    identical(FirstRun$Chains, SecondRun$Chains) && identical(FirstRun$Summary, SecondRun$Summary))
  Check("Incompatible imputation inputs cannot overwrite checkpoints", Fails(RunGammaRbmi(CacheFit,
    ApplicationPath, Eligibility, "CacheCheck", Rules[Continuation, ], RbmiSettings(Seed = 82, ExampleCount = 0),
    OutputRoot = Scratch, Purpose = "Synthetic validation check")))
  Template <- RbmiEligibilityTable(CacheFit)
  TemplatePath <- file.path(Scratch, "Eligibility.csv")
  SaveTable(Template, TemplatePath)
  ReadBack <- ReadRbmiEligibility(TemplatePath, CacheFit)
  Check("Readiness preserves unresolved missing outcome definitions", all(is.na(ReadBack[is.na(CacheFit$Data$Outcome)])) && all(ReadBack[!is.na(CacheFit$Data$Outcome)]))
  Template$DataKey <- "different"
  SaveTable(Template, TemplatePath)
  Check("Eligibility from another data view is rejected", Fails(ReadRbmiEligibility(TemplatePath, CacheFit)))
  Result <- do.call(rbind, Checks)
  OutputPath <- file.path(ApplicationPath, "Results", "Validation")
  dir.create(OutputPath, recursive = TRUE, showWarnings = FALSE)
  SaveTable(Result, file.path(OutputPath, "08RbmiValidationChecks.csv"))
  writeLines(c("Independent RBMI validation: synthetic inputs only.",
    paste("Checks passed:", sum(Result$Passed), "of", nrow(Result)),
    paste("Kernel SHA-256:", FileHash(file.path(ApplicationPath, "src", "GammaRbmi.cpp"))),
    "These checks do not establish repeated-sampling coverage or resolve EXALT eligibility.",
    capture.output(sessionInfo())), file.path(OutputPath, "08RbmiValidationSummary.txt"))
  print(Result, row.names = FALSE)
  Assert(all(Result$Passed), "RBMI validation has failed checks.")
  invisible(Result)
}

# A reproducible end-to-end example fitted with the visit-specific-shape gamma kernel.
# Its sampling stages, diagnostics and immutable checkpoints follow the same
# policy as the application. This is one example, not a coverage experiment.
RunRbmiExample <- function(ApplicationPath, Settings = GammaSettings(), Label = "SyntheticExampleVisitShape") {
  Example <- RbmiExampleData()
  Data <- Example$Data
  OutputPath <- file.path(ApplicationPath, "Results", "Validation", "RbmiExampleVisitShapeFit")
  dir.create(OutputPath, recursive = TRUE, showWarnings = FALSE)
  KernelSettings <- Settings[setdiff(names(Settings), c("MaxWarmupBlocks", "MaxSamplingBlocks", "RhatLimit", "EssLimit"))]
  SamplingKey <- digest::digest(list(Data, KernelSettings,
    FileHash(file.path(ApplicationPath, "src", "GammaCopula.cpp")),
    FileHash(file.path(ApplicationPath, "R", "GammaModel.R"))), algo = "sha256")
  LoadGammaCpp(ApplicationPath)
  Initial <- GammaInitialValues(Data)
  Previous <- vector("list", Settings$Chains)
  NextBlock <- function(Block) {
    lapply(seq_len(Settings$Chains), function(Chain) {
      Path <- file.path(OutputPath, sprintf("Chain%02dBlock%03d.rds", Chain, Block))
      ParentKey <- if (Block == 1) NA_character_ else digest::digest(
        list(Previous[[Chain]]$ChainState, Previous[[Chain]]$RngState), algo = "sha256")
      if (file.exists(Path)) {
        Chunk <- readRDS(Path)
        Assert(identical(Chunk$SamplingKey, SamplingKey) && identical(Chunk$ParentKey, ParentKey) &&
          Chunk$Block == Block && Chunk$Chain == Chain, "Synthetic example checkpoints have different inputs.")
      } else {
        if (Block == 1) {
          set.seed(Settings$Seed + 1009*Chain)
          Theta <- Initial$Theta
          Theta[1 : 16] <- Theta[1 : 16] + rnorm(16, sd = .25)
          Theta[17] <- qlogis((1 + seq(-.6, .8, length.out = Settings$Chains)[Chain])/2)
          Warmup <- Settings$AdaptiveWarmup
          Continuation <- NULL
        } else {
          assign(".Random.seed", Previous[[Chain]]$RngState, envir = .GlobalEnv)
          Theta <- Previous[[Chain]]$ChainState$Theta
          Warmup <- 0
          Continuation <- Previous[[Chain]]$ChainState
        }
        message("Synthetic example: chain ", Chain, ", block ", Block, ".")
        Started <- proc.time()[[3]]
        Chunk <- RunGammaChainCpp(Data$Outcome/Data$UnitScale, Data$Design, Data$Weeks,
          Theta, Settings$PriorMean, Settings$PriorSd, Initial$Covariances, Warmup,
          Settings$BlockDraws, Settings$AdaptEvery, Settings$ZeroSweeps, Settings$RhoA, Settings$RhoB, Continuation)
        Chunk$ElapsedSeconds <- proc.time()[[3]] - Started
        colnames(Chunk$Draws) <- Data$ParameterNames
        Chunk$Chain <- Chain
        Chunk$Block <- Block
        Chunk$SamplingKey <- SamplingKey
        Chunk$ParentKey <- ParentKey
        Chunk$RngState <- get(".Random.seed", envir = .GlobalEnv)
        SaveCheckpoint(Chunk, Path)
      }
      Previous[[Chain]] <<- Chunk
      Chunk
    })
  }
  Sampling <- RunMcmcStages(NextBlock, function(Chains) {
    CheckMcmc(Chains, Data$ParameterNames, Settings$RhatLimit, Settings$EssLimit, Data = Data)
  }, Settings$MaxWarmupBlocks, Settings$MaxSamplingBlocks)
  Fit <- list(Data = Data, Settings = Settings, Chains = Sampling$Chains,
    PositiveFamily = "Gamma", SamplingKey = SamplingKey, ParameterSummary = Sampling$Check$Summary,
    Convergence = Sampling[setdiff(names(Sampling), "Chains")], Label = "SyntheticExampleVisitShape")
  saveRDS(Fit, file.path(OutputPath, "Fit.rds"))
  saveRDS(Example, file.path(OutputPath, "GeneratingData.rds"))
  SaveTable(Sampling$History, file.path(OutputPath, "ConvergenceHistory.csv"))
  SaveTable(Fit$ParameterSummary, file.path(OutputPath, "ParameterSummary.csv"))
  RunGammaRbmi(Fit, ApplicationPath, matrix(TRUE, nrow(Data$Outcome), 4), Label,
    Purpose = "Synthetic validation example")
}
