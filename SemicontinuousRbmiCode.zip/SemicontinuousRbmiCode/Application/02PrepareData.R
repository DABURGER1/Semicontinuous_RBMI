# Stage 02. Preserve partial observations and unresolved metadata explicitly.
# No outcome imputation, winsorisation, ID correction or treatment-stop inference.
PrepareData <- function(ApplicationPath) {
  ExaltSources <- readRDS(file.path(ApplicationPath, "Imported", "01ExaltSources.rds"))
  AlcoholSource <- ExaltSources$Alcohol
  AbstinenceSource <- ExaltSources$AbstinentDays
  HeavyDrinkingSource <- ExaltSources$HeavyDays
  DropoutSource <- ExaltSources$Dropout
  DropoutIndex <- match(AlcoholSource[["projekt_id"]], DropoutSource[["projekt_id"]])
  BmiIndex <- match(AlcoholSource[["projekt_id"]], ExaltSources$Bmi[["projekt_id"]])
  GenderIndex <- match(AlcoholSource[["projekt_id"]], ExaltSources$Gender[["projekt_id"]])
  AbstinenceIndex <- match(AlcoholSource[["projekt_id"]], AbstinenceSource[["projekt_id"]])
  HeavyDrinkingIndex <- match(AlcoholSource[["projekt_id"]], HeavyDrinkingSource[["projekt_id"]])
  ExaltSubjects <- data.frame(
    Id = AlcoholSource[["projekt_id"]], GroupCode = AlcoholSource[["random_group"]],
    Arm = paste("Group", AlcoholSource[["random_group"]]),
    ArmLabelRepository = ifelse(AlcoholSource[["random_group"]] == 1, "Placebo", "Exenatide"),
    TreatmentCodeConfirmed = TRUE,
    GenderCodeSource = ExaltSources$Gender[["gender"]][GenderIndex],
    GenderLabelSource = ifelse(is.na(ExaltSources$Gender[["gender"]][GenderIndex]), NA_character_, ifelse(ExaltSources$Gender[["gender"]][GenderIndex] == 1, "Female", "Male")),
    BaselineBmi = ExaltSources$Bmi[["baseline_bmi"]][BmiIndex],
    BaselineAlcoholGrams30Days = AlcoholSource[["baseline_total_alcohol"]],
    BaselineAbstinentDays = AbstinenceSource[["baseline_0_dage"]][AbstinenceIndex],
    BaselineHeavyDays = HeavyDrinkingSource[["baseline_heavydays"]][HeavyDrinkingIndex],
    DropoutMetadataMatched = !is.na(DropoutIndex),
    LastRegularAssessmentWeek = DropoutSource[["last regular assesment"]][DropoutIndex],
    FinalAssessmentWeekMetadata = DropoutSource[["Last assessment performed (week)"]][DropoutIndex],
    DropoutMarkerSource = DropoutSource[["Drop-out"]][DropoutIndex],
    CompletionMarkerSource = DropoutSource[["finalized"]][DropoutIndex],
    OverlapNoteSource = DropoutSource[[7]][DropoutIndex], TreatmentStopWeek = NA_real_
  )
  AlcoholColumns <- c("baseline_total_alcohol", "week4_total_alcohol", "week12_total_alcohol", "week20_total_alcohol", "week26_total_alcohol")
  AbstinenceColumns <- c("baseline_0_dage", "week4_zero_days", "week12_zero_days", "week20_zero_days", "followup_zero_days")
  HeavyDrinkingColumns <- c("baseline_heavydays", "week4_heavydays", "week12_heavydays", "week20_heavydays", "followup_heavydays")
  Weeks <- c(0, 4, 12, 20, 26)
  ExaltLong <- do.call(rbind, lapply(seq_along(Weeks), function(VisitIndex) {
    Outcome <- AlcoholSource[[AlcoholColumns[VisitIndex]]]
    data.frame(
      Id = AlcoholSource[["projekt_id"]], Visit = VisitIndex - 1, NominalWeek = Weeks[VisitIndex],
      IntendedRecallDays = 30, RecordedDays = NA_real_,
      OutcomeGrams30Days = Outcome, GramsPerDayAssuming30 = Outcome/30,
      AbstinentDaysReported = AbstinenceSource[[AbstinenceColumns[VisitIndex]]][AbstinenceIndex], HeavyDaysReported = HeavyDrinkingSource[[HeavyDrinkingColumns[VisitIndex]]][HeavyDrinkingIndex],
      IsZeroObserved = ifelse(is.na(Outcome), NA, Outcome == 0),
      OutcomeColumnSource = AlcoholColumns[VisitIndex]
    )
  }))
  ExaltLong <- merge(ExaltLong, ExaltSubjects, by = "Id", all.x = TRUE, sort = FALSE)
  ExaltLong <- ExaltLong[order(ExaltLong$Id, ExaltLong$Visit), ]
  rownames(ExaltLong) <- NULL
  ExaltLong$TimingStatus <- ifelse(ExaltLong$Visit < 4, "scheduled_column", ifelse(
    is.na(ExaltLong$FinalAssessmentWeekMetadata), "final_week_unknown", ifelse(
      ExaltLong$FinalAssessmentWeekMetadata == 26, "final_week_26_confirmed", "final_assessment_earlier_than_26"
    )
  ))
  ExaltLong$OutcomeTimingChecked <- ExaltLong$OutcomeGrams30Days
  ExaltLong$OutcomeTimingChecked[ExaltLong$Visit == 4 & ExaltLong$TimingStatus != "final_week_26_confirmed"] <- NA_real_
  # Total/30 is a convenience variable, not a correction for an unknown denominator.
  Assert(nrow(ExaltLong) == 5*nrow(ExaltSubjects), "EXALT join changed the panel size")
  Assert(all(ExaltLong$OutcomeGrams30Days >= 0, na.rm = TRUE), "Negative EXALT consumption")
  Assert(all(ExaltLong$AbstinentDaysReported %in% c(0 : 30, NA)), "Invalid EXALT abstinent-day count")
  Assert(all(ExaltLong$HeavyDaysReported %in% c(0 : 30, NA)), "Invalid EXALT heavy-day count")
  Paired <- !is.na(ExaltLong$OutcomeGrams30Days) & !is.na(ExaltLong$AbstinentDaysReported)
  Assert(all((ExaltLong$OutcomeGrams30Days[Paired] == 0) == (ExaltLong$AbstinentDaysReported[Paired] == 30)), "EXALT zero consumption and abstinence disagree")
  Patterns <- ObservationPatterns(ExaltLong[ExaltLong$Visit > 0, ], "Id", "Visit", "OutcomeGrams30Days", "Arm")
  Patterns$Id <- as.numeric(Patterns$Id)
  ExaltSubjects <- merge(ExaltSubjects, Patterns[, setdiff(names(Patterns), "Arm")], by = "Id", all.x = TRUE)
  SaveDataset(ExaltSubjects, ApplicationPath, "02ExaltSubjects")
  SaveDataset(ExaltLong, ApplicationPath, "02ExaltLong")

  Ids <- sort(union(AlcoholSource[["projekt_id"]], DropoutSource[["projekt_id"]]))
  AlcoholIndex <- match(Ids, AlcoholSource[["projekt_id"]])
  DropoutIndex <- match(Ids, DropoutSource[["projekt_id"]])
  Reconciliation <- data.frame(
    Id = Ids, InOutcomeFile = !is.na(AlcoholIndex), InDropoutFile = !is.na(DropoutIndex),
    GroupCode = AlcoholSource[["random_group"]][AlcoholIndex], FinalAlcoholG = AlcoholSource[["week26_total_alcohol"]][AlcoholIndex],
    LastRegularAssessmentWeek = DropoutSource[["last regular assesment"]][DropoutIndex],
    FinalAssessmentWeek = DropoutSource[["Last assessment performed (week)"]][DropoutIndex],
    DropoutMarker = DropoutSource[["Drop-out"]][DropoutIndex], CompletionMarker = DropoutSource[["finalized"]][DropoutIndex],
    Note = DropoutSource[[7]][DropoutIndex]
  )
  SaveTable(Reconciliation, file.path(ApplicationPath, "Results", "Tables", "02ExaltIdAndTimingReconciliation.csv"))
  Issues <- data.frame(
    Dataset = rep("EXALT", 6),
    Issue = c(
      "outcome_ID_without_dropout_metadata", "dropout_ID_without_outcomes",
      "observed_final_outcome_timing_unknown", "dropout_flags_incomplete",
      "treatment_code_documentation_conflict", "recorded_day_denominator_unavailable"
    ),
    Count = c(
      sum(!Reconciliation$InDropoutFile), sum(!Reconciliation$InOutcomeFile),
      sum(ExaltLong$Visit == 4 & !is.na(ExaltLong$OutcomeGrams30Days) & ExaltLong$TimingStatus == "final_week_unknown"),
      sum(is.na(DropoutSource[["Drop-out"]]) & is.na(DropoutSource[["finalized"]])), nrow(ExaltSubjects), nrow(ExaltLong)
    ),
    Meaning = c(
      "ID 46 is retained; no correction to ID 56 is inferred.",
      "ID 56 remains in the reconciliation table; no artificial outcome record is created.",
      "The reported final outcome is retained, and excluded only from the timing-checked view.",
      "Blank flags are unknown; they are not evidence of completion or absence of dropout.",
      "Repository says 1=placebo, 2=exenatide (65/62); publication Figure 1 caption reports 65 exenatide/62 placebo. The main Results, actual CONSORT diagram and baseline summaries corroborate the repository coding.",
      "The intended recall window is 30 days; the number of actually recorded days is not supplied in these aggregate outcome files."
    )
  )
  SaveTable(Issues, file.path(ApplicationPath, "Results", "Tables", "02DataIssues.csv"))
  Dictionary <- data.frame(
    Dataset = rep("EXALT", 12),
    Variable = c(
      "OutcomeGrams30Days", "GramsPerDayAssuming30", "OutcomeTimingChecked", "GroupCode", "ArmLabelRepository", "TreatmentCodeConfirmed", "RecordedDays", "FinalAssessmentWeekMetadata",
      "TreatmentStopWeek", "Pattern1Missing", "NTrailingMissing", "NIntermittentMissing"
    ),
    Definition = c(
      "Reported total grams of alcohol in the preceding 30-day window.",
      "Reported total divided by 30; does not establish that all 30 days were observed.",
      "Reported outcome at nominal visit, with final outcomes retained only when metadata confirms week 26. Other visits use their source column labels.",
      "Original random_group code; retained without relabelling or swapping arms.",
      "Repository interpretation, 1=Placebo and 2=Exenatide; conflicts with published Figure 1 arm totals.",
      "TRUE after reconciliation against the main Results, CONSORT diagram and baseline summaries.",
      "Unknown in these EXALT aggregate files; deliberately NA, not set to 30.",
      "Week of the final assessment in Drop_outs.xlsx; not an inferred drug-stop time.",
      "Unknown in the analysed extract; deliberately NA for all participants.",
      "Four postbaseline visits in order; 1 denotes missing source alcohol outcome, 0 observed.",
      "Number of scheduled missing alcohol outcomes after the last observed outcome; not proof of treatment discontinuation.",
      "Number of scheduled missing alcohol outcomes before a later observed outcome."
    )
  )
  SaveTable(Dictionary, file.path(ApplicationPath, "Derived", "02VariableDictionary.csv"))
  invisible(NULL)
}
