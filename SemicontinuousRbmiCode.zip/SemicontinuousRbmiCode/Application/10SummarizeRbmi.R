# Stage 10. Report imputation results, diagnostics and analysis assumptions.
WriteRbmiReport <- function(Result, OutputPath) {
  Summary <- Result$Summary
  dir.create(file.path(OutputPath, "Figures"), showWarnings = FALSE)
  Plot <- ggplot2::ggplot(Summary, ggplot2::aes(PositiveWeight, Estimate, colour = factor(ZeroWeight), group = ZeroWeight)) +
    ggplot2::geom_hline(yintercept = 0, linetype = "dashed", colour = "grey50") +
    ggplot2::geom_linerange(ggplot2::aes(ymin = Lower, ymax = Upper), position = ggplot2::position_dodge(width = .06)) +
    ggplot2::geom_line(position = ggplot2::position_dodge(width = .06)) + ggplot2::geom_point(position = ggplot2::position_dodge(width = .06)) +
    ggplot2::scale_x_continuous(breaks = sort(unique(Summary$PositiveWeight))) +
    ggplot2::theme_bw(base_size = 12) + ggplot2::theme(legend.position = "bottom") +
    ggplot2::labs(x = "Positive-amount borrowing weight", y = "Adjusted active-minus-reference mean difference",
      colour = "Abstinence borrowing", title = paste0(Result$Label, ": component-specific RBMI"),
      subtitle = "Ordinary Rubin intervals; all retained posterior draws")
  for (Extension in c("png", "pdf")) ggplot2::ggsave(file.path(OutputPath, "Figures", paste0("SensitivityEstimates.", Extension)),
    Plot, width = 9, height = 6, dpi = 160, bg = "white")
  PointColumns <- c("Rule", "ZeroWeight", "PositiveWeight", "Estimate", "StandardError", "Lower", "Upper", "Df", "Imputations", "Status")
  DiagnosticColumns <- c("Rule", "McseEstimate", "McseFraction", "McseVariance", "VarianceMcseFraction",
    "MaximumRhat", "MinimumBulkEss", "MinimumTailEss", "FitConverged", "DiagnosticsPassed", "PrecisionPassed")
  Html <- paste0(
    "<!doctype html><html><head><meta charset='utf-8'><title>Component-specific RBMI</title>",
    "<style>body{font:16px/1.55 Arial,sans-serif;max-width:1150px;margin:40px auto;padding:0 24px;color:#233345}table{border-collapse:collapse;font-size:13px;width:100%}th,td{padding:7px;border-bottom:1px solid #ddd;text-align:left}.table-wrap{overflow:auto}img{max-width:100%}a{color:#155f9b}</style></head><body>",
    "<h1>", HtmlEscape(Result$Purpose), "</h1><p>Run: ", HtmlEscape(Result$Label),
    ". The final-visit analysis uses treatment, centered baseline and their interaction, with HC3 variances augmented for empirical standardization and ordinary Rubin pooling. The added variance accounts for estimating the baseline distribution for a population mean contrast. Intervals use the Barnard-Rubin degrees-of-freedom adjustment.</p>",
    "<p>Borrowing is applied to eligible missing outcomes in the final missing tail. Intermittent gaps use assigned-treatment continuation. Retained observations are preserved. Missing latent draws are shared across rules, and observed-zero auxiliaries stay paired with their parameter draws.</p>",
    if (grepl("Synthetic", Result$Purpose, fixed = TRUE)) "<p><strong>This is a synthetic workflow demonstration, not an EXALT treatment result or a coverage simulation.</strong></p>" else "",
    if (grepl("hypothetical survival", Result$Purpose, fixed = TRUE))
      "<p>The analysis targets alcohol consumption had participants remained alive. Any post-death completions follow the specified borrowing law for hypothetical outcomes. Death identifiers and dates are unavailable, so post-death positions cannot be counted separately. This is not an assessment of mortality or overall clinical benefit.</p>" else "",
    "<p>Input fit status: ", HtmlEscape(Result$InputConvergence$Status), "; summary scope: ",
    HtmlEscape(Result$InputConvergence$SummaryScope), ".</p>",
    "<h2>Mean contrasts and Rubin intervals</h2>", HtmlTable(Summary[, PointColumns], 4),
    "<img src='Figures/SensitivityEstimates.png' alt='Mean contrasts across component borrowing weights'>",
    "<h2>Monte Carlo precision and convergence</h2>", HtmlTable(Summary[, DiagnosticColumns], 5),
    "<p>The precision targets are Monte Carlo standard errors below ", 100*Result$Settings$McseFractionLimit,
    "% of the pooled standard error for the estimate and below ", 100*Result$Settings$VarianceMcseFractionLimit,
    "% of the total variance for its estimate. The variance MCSE uses a delta-method influence series. These measure numerical precision, not frequentist coverage. Flagged results remain visible.</p>",
    "<p>All posterior rows were used. Chain files retain every completed-data estimate and variance. Saved example datasets are only inspection aids; they are not the subset used for pooling.</p>",
    "<h2>Supporting descriptive summaries</h2>", HtmlTable(Summary[, c("Rule", "UnadjustedDifference", "ReferenceMean", "ActiveMean", "ReferenceZero", "ActiveZero")], 4),
    "<p>Supporting quantities are averages over completed datasets; no separate inferential intervals are reported for them.</p>",
    "<p><a href='PooledResults.csv'>All numerical results</a> | <a href='SensitivityRules.csv'>Sensitivity rules</a> | ",
    "<a href='RbmiResults.rds'>Complete saved analysis object</a> | <a href='Figures/SensitivityEstimates.pdf'>Vector figure</a></p>",
    "<p>Reference borrowing may make Rubin intervals conservative; calibration for this model remains to be assessed in a repeated-sampling study.</p></body></html>")
  writeLines(Html, file.path(OutputPath, "Report.html"), useBytes = TRUE)
  invisible(OutputPath)
}

SummarizeRbmi <- function(ApplicationPath) {
  Root <- file.path(ApplicationPath, "Results", "Rbmi")
  dir.create(Root, recursive = TRUE, showWarnings = FALSE)
  Files <- list.files(Root, pattern = "^RbmiResults[.]rds$", full.names = TRUE, recursive = TRUE)
  Labels <- c(ApplicationGammaLabel(), "SyntheticExampleVisitShape")
  Files <- Files[basename(dirname(Files)) %in% Labels]
  Files <- Files[order(match(basename(dirname(Files)), Labels))]
  ApplicationLinks <- ValidationLinks <- character()
  for (Path in Files) {
    Result <- readRDS(Path)
    WriteRbmiReport(Result, dirname(Path))
    Link <- paste0("<li><a href='", basename(dirname(Path)), "/Report.html'>",
      HtmlEscape(Result$Label), " (", HtmlEscape(Result$Purpose), ")</a></li>")
    if (grepl("Synthetic", Result$Purpose, fixed = TRUE)) ValidationLinks <- c(ValidationLinks, Link) else ApplicationLinks <- c(ApplicationLinks, Link)
  }
  ReadinessPath <- file.path(Root, "09ApplicationReadiness.csv")
  Readiness <- if (file.exists(ReadinessPath)) read.csv(ReadinessPath) else NULL
  Html <- paste0("<!doctype html><html><head><meta charset='utf-8'><title>RBMI workflow</title>",
    "<style>body{font:16px/1.55 Arial,sans-serif;max-width:1100px;margin:40px auto;padding:0 24px;color:#233345}table{border-collapse:collapse;font-size:13px;width:100%}th,td{padding:7px;border-bottom:1px solid #ddd;text-align:left}.table-wrap{overflow:auto}a{color:#155f9b}</style></head><body>",
    "<h1>Semicontinuous copula RBMI</h1><p>The imputation and ordinary Rubin-pooling workflow is implemented. Results below distinguish synthetic validation from any completed application analyses.</p>",
    "<h2>EXALT analysis status</h2>", if (is.null(Readiness)) "<p>The application readiness stage has not run.</p>" else HtmlTable(Readiness),
    "<p>EXALT uses an explicitly specified hypothetical survival strategy. Only the timing-screened application is active, using separate gamma shapes by visit shared across treatments. The operational final-tail trigger does not establish when treatment stopped. Synthetic results are software validation only.</p>",
    "<h2>EXALT results</h2><ul>", paste(ApplicationLinks, collapse = ""), "</ul>",
    "<h2>Software validation</h2><ul>", paste(ValidationLinks, collapse = ""), "</ul>",
    "<p><a href='../Validation/08RbmiValidationSummary.txt'>Independent numerical validation</a> | ",
    "<a href='../Validation/08RbmiValidationChecks.csv'>Individual checks</a> | ",
    "<a href='09ApplicationReadiness.csv'>Application readiness table</a></p></body></html>")
  writeLines(Html, file.path(Root, "10RbmiOverview.html"), useBytes = TRUE)
  invisible(Files)
}
