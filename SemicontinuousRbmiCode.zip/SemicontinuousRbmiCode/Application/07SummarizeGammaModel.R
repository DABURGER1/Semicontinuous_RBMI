# Summarize the selected visit-specific-shape fit, retaining any diagnostic flags.
SummarizeApplicationModels <- function(ApplicationPath) {
  Labels <- ApplicationGammaLabel()
  Rows <- list()
  Fits <- lapply(Labels, function(Label) readRDS(file.path(ApplicationPath, "Results", "Gamma", Label, "Fit.rds")))
  for (Index in seq_along(Fits)) {
    Fit <- Fits[[Index]]
    OutputPath <- file.path(ApplicationPath, "Results", "Gamma", Fit$Label)
    ReportFile <- file.path(OutputPath, "ReportResults.rds")
    ExpectedKey <- GammaReportKey(Fit, ApplicationPath)
    Existing <- if (file.exists(ReportFile)) readRDS(ReportFile) else NULL
    RequiredFiles <- c(
      "Report.html", "Tables/ParameterSummary.csv", "Tables/PredictiveChecks.csv",
      "Tables/MarginalProfiles.csv", "Figures/ZeroChecks.png", "Figures/AmountChecks.png",
      "Figures/DependenceChecks.png", "Figures/ParameterTraces.png", "Figures/MarginalProfiles.png"
    )
    if (is.null(Existing) || !identical(Existing$ReportKey, ExpectedKey) ||
      !all(file.exists(file.path(OutputPath, RequiredFiles)))) {
      WriteGammaReport(Fit, OutputPath)
    }
    Summary <- Fit$ParameterSummary
    Select <- function(Name) Summary[match(Name, Summary$Parameter), ]
    Abstinence <- Select("AbstinenceOddsRatio")
    Positive <- Select("PositiveMeanRatio")
    Shapes <- vapply(Fit$Data$Weeks, function(Week) Select(paste0("GammaShapeWeek", Week))$Median, numeric(1))
    Correlation <- Select("AdjacentCorrelation")
    Rows[[Index]] <- data.frame(
      View = Fit$Label, Status = Fit$Convergence$Status,
      Converged = Fit$Convergence$Converged, SummaryScope = Fit$Convergence$SummaryScope,
      DrawsPerChain = nrow(Fit$Chains[[1]]$Draws), Observed = sum(!is.na(Fit$Data$Outcome)),
      MaxRhat = max(Summary$Rhat), MinBulkEss = min(Summary$BulkEss), MinTailEss = min(Summary$TailEss),
      AbstinenceOddsRatio = Abstinence$Median, AbstinenceLower = Abstinence$Lower, AbstinenceUpper = Abstinence$Upper,
      PositiveMeanRatio = Positive$Median, PositiveLower = Positive$Lower, PositiveUpper = Positive$Upper,
      GammaShapeWeek4 = Shapes[1], GammaShapeWeek12 = Shapes[2],
      GammaShapeWeek20 = Shapes[3], GammaShapeWeek26 = Shapes[4], AdjacentCorrelation = Correlation$Median
    )
  }
  Summary <- do.call(rbind, Rows)
  SaveTable(Summary, file.path(ApplicationPath, "Results", "Tables", "07GammaOverview.csv"))
  Links <- paste(vapply(Labels, function(Label) {
    paste0(
      "<li><a href='Gamma/", Label,
      "/Report.html'>", Label, ": full model report</a></li>"
    )
  }, character(1)), collapse = "\n")
  Html <- paste0(
    "<!doctype html><html><head><meta charset='utf-8'><title>Gamma copula overview</title>",
    "<style>body{font:16px/1.55 Arial,sans-serif;max-width:1150px;margin:40px auto;padding:0 24px;color:#233345}table{border-collapse:collapse;font-size:13px;width:100%}th,td{padding:7px;border-bottom:1px solid #ddd;text-align:left}.table-wrap{overflow:auto}a{color:#155f9b}</style></head><body>",
    "<h1>EXALT gamma copula: rebuilt workflow</h1><p>The regression targets remain abstinence probability and the arithmetic mean among positive outcomes. A Gaussian copula links the four visits. Gamma shapes vary independently by visit and are shared across treatment arms. Overall means including zeros are derived from the two components.</p>",
    "<p>Chains continue from saved parameter, latent-variable, proposal and random-number states. The first stage assesses each block using R-hat at most 1.05. Earlier blocks become warmup. The first passing block and all later draws are retained; cumulative R-hat and bulk/tail ESS of at least 400 determine whether more blocks are needed. The default limits are five screening blocks and five retained blocks. Flagged fits remain in this overview.</p>",
    HtmlTable(Summary, Digits = 4),
    "<p>Every summarized draw enters the numerical summaries and posterior predictive checks. Trace plots alone may be subsampled for display. The separate RBMI report provides imputation results.</p><ul>", Links,
    "<li><a href='Tables/07GammaOverview.csv'>Numerical overview</a></li>",
    "<li><a href='Validation/05GammaValidationSummary.txt'>Sampler and continuation validation</a></li>",
    "<li><a href='03PreliminaryReport.html'>Data investigation</a></li>",
    "<li><a href='ExaltMetadataReview.txt'>Source and timing audit</a></li></ul>",
    "<p>This overview describes the current saved application fit. The linked model and RBMI reports provide the current numerical results; manuscript synchronization is a separate step.</p></body></html>"
  )
  writeLines(Html, file.path(ApplicationPath, "Results", "07GammaOverview.html"), useBytes = TRUE)
  print(Summary, row.names = FALSE)
  invisible(Summary)
}
