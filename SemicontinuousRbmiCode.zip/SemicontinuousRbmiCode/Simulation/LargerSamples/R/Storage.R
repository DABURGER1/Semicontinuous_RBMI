# Historical paths resolve through a verified index after physical consolidation.
# The stored manifests and checkpoint hashes remain unchanged.
ResolveStudyFile <- local({
  CachedFile <- NULL
  CachedIndex <- NULL
  function(File) {
    if (file.exists(File)) return(File)
    Path <- getOption("SemicontinuousSimulationPath")
    if (is.null(Path)) return(File)
    IndexFile <- file.path(SimulationResultsPath(Path), "Provenance", "StorageIndex.rds")
    if (!file.exists(IndexFile)) return(File)
    if (!identical(CachedFile, IndexFile)) {
      CachedIndex <<- readRDS(IndexFile)
      CachedFile <<- IndexFile
    }
    Key <- chartr("\\", "/", File)
    Resolved <- unname(CachedIndex$Paths[Key])
    if (length(Resolved) != 1 || is.na(Resolved)) return(File)
    Assert(file.exists(Resolved), "A consolidated study file is missing.")
    Resolved
  }
})
