# Explicit analysis branches preserve immutable posterior checkpoints and their provenance.
SimulationResultsPath <- function(Path) {
  Root <- file.path(Path, "Results")
  Pointer <- file.path(Root, "CurrentAnalysis.json")
  if (!file.exists(Pointer)) return(Root)
  Target <- jsonlite::fromJSON(Pointer)$ResultsDirectory
  Assert(is.character(Target) && length(Target) == 1 && nzchar(Target), "Invalid active analysis directory.")
  if (!grepl("^([A-Za-z]:[/\\\\]|/)", Target)) Target <- file.path(Root, Target)
  normalizePath(Target, winslash = "/", mustWork = TRUE)
}

VerifyVarianceMigration <- function(Manifest) {
  Migration <- Manifest$VarianceMigration
  if (is.null(Migration)) return(invisible(NULL))
  ParentFile <- ResolveStudyFile(file.path(Migration$ParentResults, "StudyManifest.rds"))
  Assert(identical(FileHash(ParentFile), Migration$ParentManifestHash), "The parent study manifest changed.")
  Parent <- readRDS(ParentFile)
  Assert(identical(Parent$Key, Migration$ParentStudyKey) &&
    identical(Parent$Jobs, Manifest$Jobs) && identical(Parent$Settings, Manifest$Settings) &&
    identical(Parent$PlanHash, Manifest$PlanHash) && identical(Parent$TruthHash, Manifest$TruthHash) &&
    identical(Parent$CalibrationHash, Manifest$CalibrationHash), "The migration changed the frozen study design.")
  Assert(identical(unname(Parent$SourceHashes["GammaCopula.cpp"]),
    unname(Manifest$SourceHashes["GammaCopula.cpp"])), "The posterior sampling kernel changed.")
  invisible(Parent)
}

ReadTrialMigration <- function(Output, Data, Settings, Streams, SamplingKey) {
  File <- file.path(Output, "VarianceMigration.rds")
  if (!file.exists(File)) return(NULL)
  Migration <- readRDS(File)
  Manifest <- readRDS(file.path(dirname(dirname(Output)), "StudyManifest.rds"))
  Assert(identical(Migration$StudyKey, Manifest$Key) &&
    identical(Migration$ParentStudyKey, Manifest$VarianceMigration$ParentStudyKey),
    "The migrated trial belongs to another analysis branch.")
  Assert(identical(Migration$SamplingKey, SamplingKey) &&
    identical(Migration$InputHash, digest::digest(list(Data, Settings, Streams), algo = "sha256")),
    "The migrated trial inputs or current source code changed.")
  Assert(identical(FileHash(ResolveStudyFile(file.path(Migration$ParentOutput, "FitSummary.rds"))), Migration$ParentFitHash),
    "The original posterior fit summary changed.")
  Migration
}

LoadVarianceReplayKernel <- function(Path, Manifest) {
  Kernel <- Manifest$VarianceMigration$ReplayKernel
  if (is.null(Kernel)) return(invisible(NULL))
  File <- file.path(Path, Kernel$File)
  Assert(identical(FileHash(File), Kernel$Hash), "The validated replay kernel changed.")
  Rcpp::sourceCpp(File, cacheDir = file.path(Path, "Results", "ReplayCompilerCache"),
    env = .GlobalEnv, showOutput = FALSE)
  Assert(exists("CompleteSimulationReplayCpp", envir = .GlobalEnv), "The replay kernel export is missing.")
  invisible(NULL)
}

LoadMigratedChunk <- function(Migration, Output, Chain, Block, ParentKey) {
  Name <- sprintf("Chain%02dBlock%03d.rds", Chain, Block)
  Position <- match(Name, Migration$Chunks$File)
  Assert(!is.na(Position), "The migration does not contain this posterior checkpoint.")
  Source <- ResolveStudyFile(file.path(Migration$ParentOutput, Name))
  OverlayFile <- ResolveStudyFile(file.path(Output, sub("\\.rds$", "Variance.rds", Name)))
  Assert(identical(FileHash(Source), Migration$Chunks$SourceHash[Position]) &&
    identical(FileHash(OverlayFile), Migration$Chunks$OverlayHash[Position]),
    "A posterior checkpoint or variance overlay changed.")
  Chunk <- readRDS(Source)
  Overlay <- readRDS(OverlayFile)
  Assert(identical(Chunk$SamplingKey, Migration$ParentSamplingKey) &&
    identical(Chunk$ParentKey, ParentKey) && Chunk$Chain == Chain && Chunk$Block == Block &&
    identical(Overlay$StudyKey, Migration$StudyKey) &&
    identical(Overlay$SourceHash, Migration$Chunks$SourceHash[Position]) &&
    identical(dim(Overlay$StandardizationVariance), dim(Chunk$Statistics)[1 : 2]) &&
    all(is.finite(Overlay$StandardizationVariance) & Overlay$StandardizationVariance >= 0),
    "The variance overlay does not match its original posterior checkpoint.")
  Chunk$Statistics[, , "WithinVariance"] <-
    Chunk$Statistics[, , "WithinVariance"] + Overlay$StandardizationVariance
  # The key continues to identify the original posterior checkpoint. Only new
  # sampling blocks receive the current key, checked separately in Migration.
  Chunk$VarianceMigration <- list(StudyKey = Migration$StudyKey, SourceHash = Overlay$SourceHash)
  Chunk
}

RunMigratedMcmcStages <- function(NextBlock, Diagnose, Migration, MaxSamplingBlocks) {
  Original <- readRDS(ResolveStudyFile(file.path(Migration$ParentOutput, "FitSummary.rds")))
  SummaryBlocks <- Original$RetainedBlocks
  Assert(length(SummaryBlocks) > 0 && identical(SummaryBlocks, Original$SummaryBlocks) &&
    identical(Original$SummaryScope, "AllRetainedDraws"), "The parent fit has no established retained sampling stage.")
  LastBlock <- max(c(Original$WarmupBlocks, SummaryBlocks))
  Blocks <- lapply(seq_len(LastBlock), NextBlock)
  History <- Original$History
  repeat {
    Chains <- CombineChainBlocks(Blocks[SummaryBlocks])
    Check <- Diagnose(Chains)
    Table <- Check$Summary
    History <- rbind(History, data.frame(Stage = if (LastBlock == max(Original$SummaryBlocks))
      "VarianceReplay" else "RetainedSample", Block = LastBlock,
      FirstSummaryBlock = min(SummaryBlocks), LastSummaryBlock = max(SummaryBlocks),
      MaxRhat = max(Table$Rhat), MinBulkEss = min(Table$BulkEss), MinTailEss = min(Table$TailEss),
      RhatPassed = Check$RhatPassed, EssPassed = Check$EssPassed, Converged = Check$Converged))
    if (Check$Converged || length(SummaryBlocks) >= MaxSamplingBlocks) break
    message(basename(Migration$ParentOutput), ": corrected diagnostics require continuation of the existing retained chains.")
    LastBlock <- LastBlock + 1
    Blocks[[LastBlock]] <- NextBlock(LastBlock)
    SummaryBlocks <- c(SummaryBlocks, LastBlock)
  }
  list(Chains = Chains, Check = Check, History = History,
    FirstPassingBlock = min(Original$RetainedBlocks), WarmupBlocks = Original$WarmupBlocks,
    RetainedBlocks = SummaryBlocks, SummaryBlocks = SummaryBlocks, SummaryScope = "AllRetainedDraws",
    Converged = Check$Converged, Status = if (Check$Converged) "Converged" else "SamplingLimitReached")
}

PrepareVarianceMigration <- function(Path, ParentResults, ResultsPath) {
  Plan <- ReadSimulationPlan(Path)
  ParentFile <- file.path(ParentResults, "StudyManifest.rds")
  Parent <- readRDS(ParentFile)
  Assert(!identical(normalizePath(ParentResults, winslash = "/"),
    normalizePath(ResultsPath, winslash = "/", mustWork = FALSE)), "The corrected analysis needs a separate directory.")
  dir.create(ResultsPath, recursive = TRUE, showWarnings = FALSE)
  Calibration <- readRDS(file.path(ParentResults, "Calibration.rds"))
  Truth <- readRDS(file.path(ParentResults, "Truth.rds"))
  Manifest <- MakeStudyManifest(Path, Plan, Parent$Settings, Calibration, Truth)
  Manifest$VarianceMigration <- list(Method = "HC3PlusEmpiricalStandardization",
    ParentResults = normalizePath(ParentResults, winslash = "/"), ParentStudyKey = Parent$Key,
    ParentManifestHash = FileHash(ParentFile), PosteriorKernelUnchanged = TRUE,
    RetentionPolicy = "Preserve all original retained draws; append to existing chains if diagnostics require it",
    ReplayPolicy = "Original imputation RNG states; all seven legacy statistics and final RNG state checked per chunk")
  ReplayFile <- file.path("replay", "GammaRbmiReplay.cpp")
  if (file.exists(file.path(Path, ReplayFile))) Manifest$VarianceMigration$ReplayKernel <-
    list(File = ReplayFile, Hash = FileHash(file.path(Path, ReplayFile)),
      Scope = "Replay only; unchanged random stream and all legacy statistics verified against every original checkpoint")
  Manifest$Key <- digest::digest(list(Manifest$Key, Manifest$VarianceMigration), algo = "sha256")
  VerifyVarianceMigration(Manifest)
  ManifestFile <- file.path(ResultsPath, "StudyManifest.rds")
  if (file.exists(ManifestFile)) {
    Assert(identical(readRDS(ManifestFile)$Key, Manifest$Key), "The existing variance migration has different sources or inputs.")
    Manifest <- readRDS(ManifestFile)
  } else SaveCheckpoint(Manifest, ManifestFile)
  for (Name in c("Calibration.rds", "Calibration.csv", "Truth.rds", "PopulationTruth.csv")) {
    Target <- file.path(ResultsPath, Name)
    if (!file.exists(Target)) Assert(file.copy(file.path(ParentResults, Name), Target), "Could not copy a frozen study input.")
    Assert(identical(FileHash(Target), FileHash(file.path(ParentResults, Name))), "A copied study input changed.")
  }
  for (Name in c("Validation.rds", "Validation.csv", "ExecutionChecks.rds", "ExecutionChecks.csv")) {
    Current <- file.path(Path, "Results", Name)
    if (file.exists(Current) && !file.exists(file.path(ResultsPath, Name)))
      Assert(file.copy(Current, file.path(ResultsPath, Name)), "Could not copy the current validation results.")
  }
  dir.create(file.path(Path, "Results"), recursive = TRUE, showWarnings = FALSE)
  Pointer <- list(ResultsDirectory = normalizePath(ResultsPath, winslash = "/"), StudyKey = Manifest$Key)
  jsonlite::write_json(Pointer, file.path(Path, "Results", "CurrentAnalysis.json"), pretty = TRUE, auto_unbox = TRUE)
  Manifest
}

ReplayVarianceTrial <- function(Index) {
  Path <- StudyPath
  Plan <- StudyPlan
  Manifest <- StudyManifest
  VerifyStudy(Path, Plan, Manifest)
  Job <- Manifest$Jobs[[Index]]
  ParentOutput <- file.path(Manifest$VarianceMigration$ParentResults, "Formal", Job$Label)
  Output <- file.path(SimulationResultsPath(Path), "Formal", Job$Label)
  dir.create(Output, recursive = TRUE, showWarnings = FALSE)
  Marker <- file.path(Output, "Complete.rds")
  if (file.exists(Marker)) {
    Result <- readRDS(Marker)
    Assert(identical(Result$StudyKey, Manifest$Key), "The completed replay belongs to another analysis.")
    return(Result[c("Label", "Status", "ReplaySeconds")])
  }
  Started <- proc.time()[[3]]
  ParentMarker <- readRDS(ResolveStudyFile(file.path(ParentOutput, "Complete.rds")))
  ParentFit <- readRDS(ResolveStudyFile(file.path(ParentOutput, "FitSummary.rds")))
  Trial <- readRDS(ResolveStudyFile(file.path(ParentOutput, "Trial.rds")))
  Assert(identical(ParentMarker$StudyKey, Manifest$VarianceMigration$ParentStudyKey), "The original trial belongs to another study.")
  Assert(identical(ParentFit$Settings, Manifest$Settings), "The original sampler settings changed.")
  Scenario <- Plan$CoreScenarios[[match(Job$Scenario,
    vapply(Plan$CoreScenarios, function(Value) Value$Id, character(1)))]]
  Generated <- GenerateTrial(Scenario, Job$Replicate, Plan, StudyCalibration, Job$Streams$Generation)
  Assert(identical(Generated, Trial), "The original trial differs from its assigned generation stream.")
  TrialFile <- file.path(Output, "Trial.rds")
  if (!file.exists(TrialFile)) SaveCheckpoint(Trial, TrialFile)
  Assert(identical(Trial, readRDS(TrialFile)), "The copied trial changed.")
  Rules <- RbmiRules(Plan$BorrowingWeights)
  Analysis <- RbmiAnalysisDesign(Trial$Data)
  Data <- Trial$Data
  Sources <- c(file.path(Path, "R", c("SharedSupport.R", "SimulationModel.R", "Sampler.R")),
    list.files(file.path(Path, "src"), full.names = TRUE))
  Hashes <- setNames(vapply(Sources, FileHash, character(1)), basename(Sources))
  SamplingKey <- digest::digest(list(Data, Manifest$Settings, Job$Streams, Hashes), algo = "sha256")
  Chunks <- list()
  for (Chain in seq_len(Manifest$Settings$Chains)) {
    ImputationState <- Job$Streams$Imputation[[Chain]]
    ParentKey <- NA_character_
    for (Block in seq_len(max(c(ParentFit$WarmupBlocks, ParentFit$SummaryBlocks)))) {
      Name <- sprintf("Chain%02dBlock%03d.rds", Chain, Block)
      Source <- ResolveStudyFile(file.path(ParentOutput, Name))
      SourceHash <- FileHash(Source)
      Chunk <- readRDS(Source)
      Assert(identical(Chunk$SamplingKey, ParentFit$SamplingKey) &&
        identical(Chunk$ParentKey, ParentKey) && Chunk$Chain == Chain && Chunk$Block == Block,
        "The original posterior chain lineage changed.")
      File <- file.path(Output, sub("\\.rds$", "Variance.rds", Name))
      if (file.exists(File)) {
        Overlay <- readRDS(File)
        Assert(identical(Overlay$StudyKey, Manifest$Key) && identical(Overlay$SourceHash, SourceHash) &&
          identical(Overlay$ImputationStartState, ImputationState) &&
          identical(Overlay$ImputationEndState, Chunk$ImputationRngState), "An existing variance overlay has incompatible provenance.")
      } else {
        assign(".Random.seed", ImputationState, .GlobalEnv)
        ReplayKernel <- if (is.null(Manifest$VarianceMigration$ReplayKernel)) CompleteSimulationCpp else CompleteSimulationReplayCpp
        Updated <- ReplayKernel(Data$Outcome, Data$Design, Data$Times, Data$UnitScale,
          Chunk$Draws, Chunk$LogVZeros, Chunk$ZeroIndex,
          matrix(1, nrow(Data$Outcome), ncol(Data$Outcome)), 1*is.na(Data$Outcome),
          as.matrix(Rules[, c("ZeroWeight", "PositiveWeight")]), Analysis$Design,
          Analysis$Projection, Analysis$Leverage, 0)
        EndState <- get(".Random.seed", .GlobalEnv)
        Legacy <- Updated$Statistics
        Legacy[, , 2] <- Updated$CoefficientVariance
        Difference <- max(abs(Legacy - Chunk$Statistics))
        Assert(is.finite(Difference) && Difference <= 1e-11 && identical(EndState, Chunk$ImputationRngState),
          "Imputation replay changed the legacy statistics or random stream.")
        Assert(all(is.finite(Updated$StandardizationVariance) & Updated$StandardizationVariance >= 0) &&
          max(abs(Updated$Statistics[, , 2] - Chunk$Statistics[, , 2] - Updated$StandardizationVariance)) <= 1e-11,
          "The new variance is not the verified HC3 variance plus standardization uncertainty.")
        Overlay <- list(StudyKey = Manifest$Key, ParentStudyKey = Manifest$VarianceMigration$ParentStudyKey,
          SourceHash = SourceHash, Chain = Chain, Block = Block, Draws = nrow(Chunk$Draws),
          ImputationStartState = ImputationState, ImputationEndState = EndState,
          MaximumLegacyDifference = Difference, StandardizationVariance = Updated$StandardizationVariance)
        SaveCheckpoint(Overlay, File)
      }
      Chunks[[length(Chunks) + 1]] <- data.frame(File = Name, SourceHash = SourceHash,
        OverlayHash = FileHash(File), MaximumLegacyDifference = Overlay$MaximumLegacyDifference,
        Draws = Overlay$Draws, MaximumAddedVariance = max(Overlay$StandardizationVariance))
      ImputationState <- Chunk$ImputationRngState
      ParentKey <- digest::digest(list(Chunk$ChainState, Chunk$RngState, Chunk$ImputationRngState))
    }
  }
  Migration <- list(StudyKey = Manifest$Key, ParentStudyKey = Manifest$VarianceMigration$ParentStudyKey,
    ParentOutput = ParentOutput, ParentFitHash = FileHash(ResolveStudyFile(file.path(ParentOutput, "FitSummary.rds"))),
    ParentSamplingKey = ParentFit$SamplingKey, SamplingKey = SamplingKey,
    InputHash = digest::digest(list(Data, Manifest$Settings, Job$Streams), algo = "sha256"),
    Chunks = do.call(rbind, Chunks), OriginalRetainedBlocks = ParentFit$RetainedBlocks,
    OriginalWarmupBlocks = ParentFit$WarmupBlocks, OriginalDrawsPerChain = ParentFit$DrawsPerChain)
  MigrationFile <- file.path(Output, "VarianceMigration.rds")
  if (!file.exists(MigrationFile)) SaveCheckpoint(Migration, MigrationFile)
  Assert(identical(Migration, readRDS(MigrationFile)), "The trial migration provenance changed.")
  Benchmark <- CompleteDataBenchmark(Trial, Plan)
  PreviousBenchmark <- read.csv(ResolveStudyFile(file.path(ParentOutput, "CompleteDataBenchmark.csv")))
  Assert(max(abs(Benchmark$Estimate - PreviousBenchmark$Estimate)) <= 1e-11 &&
    all(Benchmark$TotalVariance >= PreviousBenchmark$TotalVariance - 1e-11), "The complete-data benchmark changed unexpectedly.")
  SaveTable(Benchmark, file.path(Output, "CompleteDataBenchmark.csv"))
  Fit <- FitSimulationTrial(Data, Path, Job$Label, Plan, Manifest$Settings, Job$Streams)
  OriginalDrawsPreserved <- identical(Fit$WarmupBlocks, ParentFit$WarmupBlocks) &&
    all(ParentFit$RetainedBlocks %in% Fit$RetainedBlocks) && Fit$DrawsPerChain >= ParentFit$DrawsPerChain
  Assert(OriginalDrawsPreserved, "The replay discarded original retained posterior draws.")
  SameDraws <- Fit$DrawsPerChain == ParentFit$DrawsPerChain
  StableFields <- c("Estimate", "BetweenVariance", "UnadjustedDifference", "ReferenceMean", "ActiveMean", "ReferenceZero", "ActiveZero")
  Difference <- if (SameDraws) max(abs(as.matrix(Fit$Pooled[, StableFields]) -
    as.matrix(ParentFit$Pooled[, StableFields]))) else NA_real_
  Assert(!SameDraws || (Difference <= 1e-11 && identical(Fit$ParameterSummary, ParentFit$ParameterSummary)),
    "Unchanged posterior draws produced changed parameter or point summaries.")
  Audit <- data.frame(Label = Job$Label, Scenario = Job$Scenario, Replicate = Job$Replicate,
    OriginalDrawsPerChain = ParentFit$DrawsPerChain, UpdatedDrawsPerChain = Fit$DrawsPerChain,
    MaximumLegacyDifference = max(Migration$Chunks$MaximumLegacyDifference),
    MaximumPointDifference = Difference, OriginalDrawsPreserved = OriginalDrawsPreserved,
    MinimumVarianceIncrement = min(Fit$Pooled$WithinVariance - ParentFit$Pooled$WithinVariance),
    Converged = Fit$Converged, Status = Fit$Status, ReplaySeconds = proc.time()[[3]] - Started)
  SaveTable(Audit, file.path(Output, "VarianceReplayAudit.csv"))
  Result <- ParentMarker
  Result$StudyKey <- Manifest$Key
  Result$ParentStudyKey <- Manifest$VarianceMigration$ParentStudyKey
  Result$Status <- Fit$Status
  Result$Converged <- Fit$Converged
  Result$ReplaySeconds <- Audit$ReplaySeconds
  Result$CompletedUtc <- format(Sys.time(), tz = "UTC", usetz = TRUE)
  SaveCheckpoint(Result, Marker)
  gc(verbose = FALSE)
  Result[c("Label", "Status", "ReplaySeconds")]
}

RunVarianceReplay <- function(Path, Workers = 8, Limit = Inf, Labels = NULL) {
  Plan <- ReadSimulationPlan(Path)
  ResultsPath <- SimulationResultsPath(Path)
  Manifest <- readRDS(file.path(ResultsPath, "StudyManifest.rds"))
  VerifyStudy(Path, Plan, Manifest)
  Assert(!is.null(Manifest$VarianceMigration), "No explicit variance migration is prepared.")
  Selected <- seq_along(Manifest$Jobs)
  if (!is.null(Labels)) Selected <- Selected[vapply(Manifest$Jobs, function(Job) Job$Label %in% Labels, logical(1))]
  Pending <- Selected[!vapply(Manifest$Jobs[Selected], function(Job)
    file.exists(file.path(ResultsPath, "Formal", Job$Label, "Complete.rds")), logical(1))]
  Pending <- head(Pending, Limit)
  if (!length(Pending)) {
    SessionFile <- file.path(ResultsPath, "CurrentRun.json")
    Session <- if (file.exists(SessionFile)) jsonlite::fromJSON(SessionFile) else list()
    Session$Completed <- sum(vapply(Manifest$Jobs, function(Job)
      file.exists(file.path(ResultsPath, "Formal", Job$Label, "Complete.rds")), logical(1)))
    Session$Planned <- length(Manifest$Jobs)
    Session$ReplicatesPerScenario <- Plan$FormalStudy$MaximumReplicatesPerScenario
    Session$Status <- if (Session$Completed == Session$Planned) "Complete" else "PausedAfterLimit"
    jsonlite::write_json(Session, SessionFile, pretty = TRUE, auto_unbox = TRUE)
    ReportStudy(Path, Plan, Plan$FormalStudy$MaximumReplicatesPerScenario)
    AuditFiles <- list.files(file.path(ResultsPath, "Formal"), pattern = "^VarianceReplayAudit.csv$", recursive = TRUE, full.names = TRUE)
    if (length(AuditFiles)) SaveTable(do.call(rbind, lapply(AuditFiles, read.csv)), file.path(ResultsPath, "VarianceReplayAudit.csv"))
    return(invisible(Session))
  }
  Cap <- max(1, min(Plan$Parallel$MaximumWorkers, floor(Plan$Parallel$CoreFraction*parallel::detectCores())))
  Assert(Workers >= 1 && Workers == floor(Workers) && Workers <= Cap, "Invalid replay worker count.")
  Lock <- file.path(ResultsPath, "RunLock")
  Assert(dir.create(Lock, showWarnings = FALSE), "An analysis run is active or its run lock needs checking.")
  Lock <- normalizePath(Lock, winslash = "/", mustWork = TRUE)
  Assert(startsWith(Lock, paste0(normalizePath(ResultsPath, winslash = "/"), "/")), "Invalid replay lock path.")
  on.exit(unlink(Lock, recursive = TRUE), add = TRUE)
  writeLines(c(paste("Pid", Sys.getpid()), format(Sys.time(), tz = "UTC", usetz = TRUE)), file.path(Lock, "Owner.txt"))
  Started <- Sys.time()
  Session <- list(Status = "Running", Purpose = "PopulationStandardizationVarianceReplay",
    StudyKey = Manifest$Key, StartedUtc = format(Started, tz = "UTC", usetz = TRUE),
    ReplicatesPerScenario = Plan$FormalStudy$MaximumReplicatesPerScenario, Planned = length(Manifest$Jobs), Workers = Workers)
  Finished <- FALSE
  on.exit({ if (!Finished) {
    Session$Status <- "InterruptedOrFailed"
    jsonlite::write_json(Session, file.path(ResultsPath, "CurrentRun.json"), pretty = TRUE, auto_unbox = TRUE)
  } }, add = TRUE)
  Cluster <- parallel::makePSOCKcluster(min(Workers, length(Pending)),
    outfile = file.path(ResultsPath, "VarianceReplayWorkerLog.txt"), rscript_args = "--vanilla")
  on.exit(parallel::stopCluster(Cluster), add = TRUE)
  InitializeSimulationWorkers(Cluster, Path, Study = TRUE)
  for (Batch in split(Pending, ceiling(seq_along(Pending)/max(Workers, 16)))) {
    Results <- parallel::parLapplyLB(Cluster, Batch, function(Index) ReplayVarianceTrial(Index), chunk.size = 1)
    print(Results)
    Session$Completed <- sum(vapply(Manifest$Jobs, function(Job)
      file.exists(file.path(ResultsPath, "Formal", Job$Label, "Complete.rds")), logical(1)))
    Session$ElapsedSeconds <- as.numeric(difftime(Sys.time(), Started, units = "secs"))
    Session$UpdatedUtc <- format(Sys.time(), tz = "UTC", usetz = TRUE)
    Session$Status <- if (Session$Completed == Session$Planned) "Complete" else "Running"
    jsonlite::write_json(Session, file.path(ResultsPath, "CurrentRun.json"), pretty = TRUE, auto_unbox = TRUE)
    message(Session$Completed, "/", Session$Planned, " corrected trials complete.")
  }
  Session$Status <- if (Session$Completed == Session$Planned) "Complete" else "PausedAfterLimit"
  jsonlite::write_json(Session, file.path(ResultsPath, "CurrentRun.json"), pretty = TRUE, auto_unbox = TRUE)
  ReportStudy(Path, Plan, Plan$FormalStudy$MaximumReplicatesPerScenario)
  AuditFiles <- list.files(file.path(ResultsPath, "Formal"), pattern = "^VarianceReplayAudit.csv$", recursive = TRUE, full.names = TRUE)
  SaveTable(do.call(rbind, lapply(AuditFiles, read.csv)), file.path(ResultsPath, "VarianceReplayAudit.csv"))
  Finished <- TRUE
  invisible(Session)
}
