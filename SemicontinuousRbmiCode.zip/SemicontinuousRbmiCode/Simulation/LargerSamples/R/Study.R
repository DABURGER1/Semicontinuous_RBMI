# The dataset is the unit of parallel work. Its chains run sequentially.
StudySourceHashes <- function(Path) {
  # Run controls and table exporters are recorded separately from the frozen implementation.
  Files <- c(list.files(file.path(Path, "R"), full.names = TRUE),
    list.files(file.path(Path, "src"), full.names = TRUE),
    list.files(file.path(Path, "replay"), full.names = TRUE))
  setNames(vapply(Files, FileHash, character(1)), basename(Files))
}

MakeStudyJobs <- function(Plan, Settings,
                          Replicates = Plan$FormalStudy$MaximumReplicatesPerScenario) {
  Assert(length(Replicates) == 1 && is.finite(Replicates) &&
    Replicates >= 1 && Replicates == floor(Replicates), "Use a positive whole-number trial count.")
  RNGkind("L'Ecuyer-CMRG", "Inversion", "Rejection")
  set.seed(Plan$FormalStudy$MasterSeed)
  State <- get(".Random.seed", .GlobalEnv)
  TakeStream <- function() {
    Current <- State
    State <<- parallel::nextRNGStream(State)
    Current
  }
  Jobs <- list()
  for (Replicate in seq_len(Replicates)) {
    for (Scenario in Plan$CoreScenarios) {
      Jobs[[length(Jobs) + 1]] <- list(Label = sprintf("%sRep%03d", Scenario$Id, Replicate),
        Scenario = Scenario$Id, Replicate = Replicate,
        Streams = list(Generation = TakeStream(),
          Posterior = lapply(seq_len(Settings$Chains), function(Index) TakeStream()),
          Imputation = lapply(seq_len(Settings$Chains), function(Index) TakeStream())))
    }
  }
  Jobs
}

MakeStudyManifest <- function(Path, Plan, Settings, Calibration, Truth,
                              Replicates = Plan$FormalStudy$MaximumReplicatesPerScenario) {
  Hashes <- StudySourceHashes(Path)
  Jobs <- MakeStudyJobs(Plan, Settings, Replicates)
  Key <- digest::digest(list(Plan, Settings, Hashes, Calibration, Truth, Jobs), algo = "sha256")
  list(Key = Key, PlanHash = digest::digest(Plan), SourceHashes = Hashes, Jobs = Jobs,
    CalibrationHash = digest::digest(Calibration), TruthHash = digest::digest(Truth),
    Settings = Settings, CreatedUtc = format(Sys.time(), tz = "UTC", usetz = TRUE))
}

PrepareStudy <- function(Path, Plan, Settings) {
  Assert(Plan$FormalStudy$TotalReplicates ==
    length(Plan$CoreScenarios)*Plan$FormalStudy$ReplicatesPerScenario, "Replicate counts disagree.")
  File <- file.path(SimulationResultsPath(Path), "Calibration.rds")
  if (file.exists(File)) {
    Calibration <- readRDS(File)
    Assert(identical(Calibration$PlanHash, digest::digest(Plan)), "Calibration settings have changed.")
  } else {
    Calibration <- CalibrateDropout(Plan, Plan$Truth$StartingPairedPopulationSize)
    SaveCheckpoint(Calibration, File)
  }
  SaveTable(Calibration$Validation, file.path(SimulationResultsPath(Path), "Calibration.csv"))
  File <- file.path(SimulationResultsPath(Path), "Truth.rds")
  if (file.exists(File)) {
    Truth <- readRDS(File)
    Assert(identical(Truth$PlanHash, digest::digest(Plan)) &&
      identical(Truth$CalibrationHash, digest::digest(Calibration)), "Population targets have changed.")
  } else {
    Truth <- PopulationTruth(Plan, Calibration,
      BatchSize = Plan$Truth$StartingPairedPopulationSize/20)
    SaveCheckpoint(Truth, File)
  }
  SaveTable(Truth$Summary, file.path(SimulationResultsPath(Path), "PopulationTruth.csv"))
  ValidateSimulation(Path, Plan, Settings)
  ValidateExecution(Path, Plan, Settings)
  Manifest <- MakeStudyManifest(Path, Plan, Settings, Calibration, Truth)
  File <- file.path(SimulationResultsPath(Path), "StudyManifest.rds")
  if (file.exists(File)) {
    Assert(identical(readRDS(File)$Key, Manifest$Key), "The frozen study specification has changed.")
  } else SaveCheckpoint(Manifest, File)
  writeLines(capture.output(sessionInfo()), file.path(SimulationResultsPath(Path), "StudySession.txt"))
  VerifyProtectedFiles(Path)
  message("Study prepared: ", Plan$FormalStudy$TotalReplicates, " initial trials; ",
    length(Manifest$Jobs), " reserved streams permit a later extension. ", Settings$Chains, " chains each.")
}

VerifyStudy <- function(Path, Plan, Manifest, ReportOnly = FALSE) {
  Pointer <- file.path(Path, "Results", "CurrentAnalysis.json")
  if (file.exists(Pointer)) Assert(identical(jsonlite::fromJSON(Pointer)$StudyKey, Manifest$Key),
    "The active analysis pointer and study manifest disagree.")
  Assert(identical(Manifest$PlanHash, digest::digest(Plan)), "The frozen study settings changed.")
  CurrentHashes <- StudySourceHashes(Path)
  if (!identical(Manifest$SourceHashes, CurrentHashes)) {
    Assert(ReportOnly, "The sampling sources changed. Use reporting stages for the completed study.")
    File <- file.path(SimulationResultsPath(Path), "SourceMaintenance.rds")
    Assert(file.exists(File), "No audited source maintenance record is available.")
    Maintenance <- readRDS(File)
    Assert(identical(Maintenance$Purpose, "ReportOnly") &&
      identical(Maintenance$StudyKey, Manifest$Key) &&
      identical(Maintenance$ManifestHash, FileHash(file.path(SimulationResultsPath(Path), "StudyManifest.rds"))) &&
      identical(Maintenance$FrozenSourceHashes, Manifest$SourceHashes) &&
      identical(Maintenance$MaintainedSourceHashes, CurrentHashes),
      "The source maintenance record does not match this study and code.")
    Assert(identical(setNames(vapply(Maintenance$FrozenFiles, FileHash, character(1)),
      names(Manifest$SourceHashes)), Manifest$SourceHashes), "The archived study sources changed.")
    if (!is.null(Maintenance$StorageIndexFile)) Assert(
      identical(FileHash(Maintenance$StorageIndexFile), Maintenance$StorageIndexHash),
      "The consolidated storage index changed.")
  }
  VerifyVarianceMigration(Manifest)
  VerifyStudyExtension(Manifest)
  Assert(all(readRDS(file.path(SimulationResultsPath(Path), "Validation.rds"))$Passed) &&
    all(readRDS(file.path(SimulationResultsPath(Path), "ExecutionChecks.rds"))$Passed),
    "Validation must pass before running the study.")
}

VerifyProtectedFiles <- function(Path) {
  File <- file.path(SimulationResultsPath(Path), "ProtectedFiles.json")
  if (!file.exists(File)) return(invisible(NULL))
  Original <- unlist(jsonlite::fromJSON(File))
  Current <- vapply(file.path(dirname(Path), names(Original)), FileHash, character(1))
  Changed <- names(Original)[unname(Current) != unname(Original)]
  jsonlite::write_json(list(Checked = length(Original), Changed = Changed,
    CheckedUtc = format(Sys.time(), tz = "UTC", usetz = TRUE)),
    file.path(SimulationResultsPath(Path), "ProtectedFileAudit.json"), pretty = TRUE, auto_unbox = TRUE)
  if (length(Changed)) warning("Application or manuscript files changed during the study.", call. = FALSE)
  invisible(Changed)
}

CompleteDataBenchmark <- function(Trial, Plan) {
  Analysis <- RbmiAnalysisDesign(Trial$Data)
  do.call(rbind, lapply(names(Trial$Complete), function(Rule) {
    Final <- Trial$Complete[[Rule]][, Plan$VisitCount]
    Coefficients <- as.vector(Analysis$Projection %*% Final)
    Residual <- Final - as.vector(Analysis$Design %*% Coefficients)
    CoefficientVariance <- sum((Analysis$Projection[2, ]*Residual/(1 - Analysis$Leverage))^2)
    StandardizationVariance <- Coefficients[4]^2*Analysis$StandardizationFactor
    Variance <- CoefficientVariance + StandardizationVariance
    Critical <- qt(.975, Analysis$DfComplete)
    data.frame(Rule = Rule, Estimate = Coefficients[2], TotalVariance = Variance,
      Lower = Coefficients[2] - Critical*sqrt(Variance),
      Upper = Coefficients[2] + Critical*sqrt(Variance))
  }))
}

InitializeStudyWorker <- function(Path) {
  LoadSimulation(Path, Compile = TRUE)
  assign("StudyPath", Path, .GlobalEnv)
  assign("StudyPlan", ReadSimulationPlan(Path), .GlobalEnv)
  assign("StudyManifest", readRDS(file.path(SimulationResultsPath(Path), "StudyManifest.rds")), .GlobalEnv)
  assign("StudyCalibration", readRDS(file.path(SimulationResultsPath(Path), "Calibration.rds")), .GlobalEnv)
  VerifyStudy(Path, StudyPlan, StudyManifest)
  LoadVarianceReplayKernel(Path, StudyManifest)
  list(Pid = Sys.getpid(), Threads = Sys.getenv(c("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS")))
}

RunFormalTrial <- function(Index) {
  Path <- StudyPath
  Plan <- StudyPlan
  Manifest <- StudyManifest
  VerifyStudy(Path, Plan, Manifest)
  if (!is.null(Manifest$VarianceMigration)) return(ReplayVarianceTrial(Index))
  Job <- Manifest$Jobs[[Index]]
  Output <- file.path(SimulationResultsPath(Path), "Formal", Job$Label)
  dir.create(Output, recursive = TRUE, showWarnings = FALSE)
  Marker <- file.path(Output, "Complete.rds")
  if (file.exists(Marker)) {
    Result <- readRDS(Marker)
    Assert(identical(Result$StudyKey, Manifest$Key), "A completed trial belongs to another study.")
    return(Result[c("Label", "Status", "WallSeconds")])
  }
  Scenario <- Plan$CoreScenarios[[match(Job$Scenario,
    vapply(Plan$CoreScenarios, function(Value) Value$Id, character(1)))]]
  Generated <- GenerateTrial(Scenario, Job$Replicate, Plan, StudyCalibration, Job$Streams$Generation)
  TrialFile <- file.path(Output, "Trial.rds")
  if (file.exists(TrialFile)) {
    Trial <- readRDS(TrialFile)
    Assert(identical(Trial, Generated), "The saved trial does not match its assigned random stream.")
  } else {
    Trial <- Generated
    SaveCheckpoint(Trial, TrialFile)
  }
  Started <- proc.time()[[3]]
  Log <- file(file.path(Output, "RunLog.txt"), open = "at")
  sink(Log, type = "message")
  on.exit({ sink(type = "message"); close(Log) }, add = TRUE)
  Warnings <- character()
  Result <- tryCatch(withCallingHandlers({
    Benchmark <- CompleteDataBenchmark(Trial, Plan)
    SaveTable(Benchmark, file.path(Output, "CompleteDataBenchmark.csv"))
    Fit <- FitSimulationTrial(Trial$Data, Path, Job$Label, Plan, Manifest$Settings, Job$Streams)
    list(Label = Job$Label, Scenario = Job$Scenario, Replicate = Job$Replicate,
      Status = Fit$Status, Converged = Fit$Converged, Error = NULL)
  }, warning = function(Warning) {
    Warnings <<- c(Warnings, conditionMessage(Warning))
    invokeRestart("muffleWarning")
  }), error = function(Error) {
    # A failed trial stays in the denominator. It is never replaced by a new dataset.
    list(Label = Job$Label, Scenario = Job$Scenario, Replicate = Job$Replicate,
      Status = "NumericalFailure", Converged = FALSE, Error = conditionMessage(Error))
  })
  Result$StudyKey <- Manifest$Key
  Result$WallSeconds <- proc.time()[[3]] - Started
  Result$CompletedUtc <- format(Sys.time(), tz = "UTC", usetz = TRUE)
  Result$Warnings <- unique(Warnings)
  Result$Observed <- list(MissingFinal = mean(is.na(Trial$Data$Outcome[, Plan$VisitCount])),
    NoFollowup = sum(rowSums(!is.na(Trial$Data$Outcome)) == 0),
    ZeroFraction = mean(Trial$Data$Outcome == 0, na.rm = TRUE))
  writeLines(unique(Warnings), file.path(Output, "Warnings.txt"))
  if (!is.null(Result$Error)) writeLines(Result$Error, file.path(Output, "Failure.txt"))
  SaveCheckpoint(Result, Marker)
  gc(verbose = FALSE)
  Result[c("Label", "Status", "WallSeconds")]
}

RunFormalStudy <- function(Path, Plan, Settings, Workers = 8, Limit = Inf,
                           Replicates = Plan$FormalStudy$ReplicatesPerScenario) {
  Manifest <- readRDS(file.path(SimulationResultsPath(Path), "StudyManifest.rds"))
  VerifyStudy(Path, Plan, Manifest)
  Cores <- parallel::detectCores(logical = TRUE)
  Assert(is.finite(Cores) && Cores >= 1, "The logical processor count is unavailable.")
  Cap <- max(1, min(Plan$Parallel$MaximumWorkers, floor(Plan$Parallel$CoreFraction*Cores)))
  Assert(is.finite(Workers) && Workers == floor(Workers) && Workers >= 1 && Workers <= Cap,
    paste0("Use between 1 and ", Cap, " workers."))
  Assert(Limit >= 1 && (is.infinite(Limit) || Limit == floor(Limit)), "Use a positive whole-number trial limit.")
  ValidateReplicationTarget(Manifest, Replicates)
  Selected <- which(vapply(Manifest$Jobs, function(Job) Job$Replicate <= Replicates, logical(1)))
  Planned <- length(Selected)
  Lock <- file.path(SimulationResultsPath(Path), "RunLock")
  Assert(dir.create(Lock, showWarnings = FALSE), "A study run is already active or its run lock needs checking.")
  Lock <- normalizePath(Lock, winslash = "/", mustWork = TRUE)
  Assert(startsWith(Lock, paste0(normalizePath(SimulationResultsPath(Path), winslash = "/"), "/")), "Invalid run lock path.")
  on.exit(unlink(Lock, recursive = TRUE), add = TRUE)
  writeLines(c(paste("Pid", Sys.getpid()), format(Sys.time(), tz = "UTC", usetz = TRUE)), file.path(Lock, "Owner.txt"))
  Pending <- Selected[!vapply(Manifest$Jobs[Selected], function(Job)
    file.exists(file.path(SimulationResultsPath(Path), "Formal", Job$Label, "Complete.rds")), logical(1))]
  if (!length(Pending)) { ReportStudy(Path, Plan, Replicates); return(invisible(NULL)) }
  InitialCompleted <- Planned - length(Pending)
  Pending <- head(Pending, min(length(Pending), Limit))
  Started <- Sys.time()
  Session <- list(StartedUtc = format(Started, tz = "UTC", usetz = TRUE), Pid = Sys.getpid(),
    Workers = Workers, LogicalCores = Cores, ChainsPerDataset = Settings$Chains,
    InitiallyCompleted = InitialCompleted, Planned = Planned, ReplicatesPerScenario = Replicates,
    Status = "Starting")
  jsonlite::write_json(Session, file.path(SimulationResultsPath(Path), "CurrentRun.json"), pretty = TRUE, auto_unbox = TRUE)
  FinishedNormally <- FALSE
  on.exit({
    if (!FinishedNormally) {
      Session$Status <- "InterruptedOrFailed"
      Session$UpdatedUtc <- format(Sys.time(), tz = "UTC", usetz = TRUE)
      jsonlite::write_json(Session, file.path(SimulationResultsPath(Path), "CurrentRun.json"), pretty = TRUE, auto_unbox = TRUE)
    }
  }, add = TRUE)
  Cluster <- parallel::makePSOCKcluster(min(Workers, length(Pending)),
    outfile = file.path(SimulationResultsPath(Path), "WorkerLog.txt"), rscript_args = "--vanilla")
  on.exit(parallel::stopCluster(Cluster), add = TRUE, after = FALSE)
  message("Initializing ", length(Cluster), " workers; fitting starts after initialization.")
  WorkerInfo <- InitializeSimulationWorkers(Cluster, Path, Study = TRUE)
  message("All workers initialized. Starting parallel dataset fits.")
  jsonlite::write_json(WorkerInfo, file.path(SimulationResultsPath(Path), "WorkerProcesses.json"), pretty = TRUE, auto_unbox = TRUE)
  Batches <- split(Pending, ceiling(seq_along(Pending)/Plan$Parallel$BatchSize))
  for (Batch in Batches) {
    Results <- parallel::parLapplyLB(Cluster, Batch, function(Index) RunFormalTrial(Index), chunk.size = 1)
    # Infrastructure/source-check errors propagate here and halt the master.
    # Numerical failures are recorded separately by the worker without redraws.
    ReportStudy(Path, Plan, Replicates)
    Elapsed <- as.numeric(difftime(Sys.time(), Started, units = "secs"))
    Completed <- sum(vapply(Manifest$Jobs[Selected], function(Job)
      file.exists(file.path(SimulationResultsPath(Path), "Formal", Job$Label, "Complete.rds")), logical(1)))
    New <- Completed - InitialCompleted
    Session$Completed <- Completed
    Session$ElapsedSeconds <- Elapsed
    Session$EstimatedRemainingHours <- if (New > 0) (Planned - Completed)*Elapsed/New/3600 else NA_real_
    Session$UpdatedUtc <- format(Sys.time(), tz = "UTC", usetz = TRUE)
    Session$Status <- if (Completed == Planned) "Complete" else "Running"
    jsonlite::write_json(Session, file.path(SimulationResultsPath(Path), "CurrentRun.json"), pretty = TRUE, auto_unbox = TRUE)
    message(Completed, "/", Planned, " trials completed; estimated remaining hours: ",
      round(Session$EstimatedRemainingHours, 2))
  }
  Session$Status <- if (Session$Completed == Planned) "Complete" else "PausedAfterLimit"
  jsonlite::write_json(Session, file.path(SimulationResultsPath(Path), "CurrentRun.json"), pretty = TRUE, auto_unbox = TRUE)
  VerifyProtectedFiles(Path)
  FinishedNormally <- TRUE
}
