# Shared loading entry point for the driver and independent R workers.
LoadSimulation <- function(Path, Compile = FALSE) {
  options(SemicontinuousSimulationPath = normalizePath(Path, winslash = "/", mustWork = TRUE))
  Sys.setenv(OMP_NUM_THREADS = "1", OPENBLAS_NUM_THREADS = "1", MKL_NUM_THREADS = "1",
    BLIS_NUM_THREADS = "1", VECLIB_MAXIMUM_THREADS = "1", NUMEXPR_NUM_THREADS = "1")
  Packages <- c("Rcpp", "RcppArmadillo", "posterior", "digest", "jsonlite")
  Missing <- Packages[!vapply(Packages, requireNamespace, logical(1), quietly = TRUE)]
  if (length(Missing)) stop("Install required packages: ", paste(Missing, collapse = ", "))
  for (File in c("SharedSupport.R", "Storage.R", "Migration.R", "SimulationModel.R", "Generator.R", "Sampler.R",
    "Study.R", "Extension.R", "Report.R", "Validation.R", "ExecutionChecks.R")) {
    source(file.path(Path, "R", File), local = .GlobalEnv)
  }
  if (Compile) for (Name in c("GammaCopula.cpp", "GammaRbmi.cpp")) Rcpp::sourceCpp(
    file.path(Path, "src", Name), cacheDir = file.path(Path, "Results", "CompilerCache"),
    env = .GlobalEnv, showOutput = FALSE)
}

ReadSimulationPlan <- function(Path) {
  Plan <- jsonlite::fromJSON(file.path(Path, "02ScenarioPlan.json"), simplifyVector = TRUE)
  Plan$CoreScenarios <- lapply(seq_len(nrow(Plan$CoreScenarios)), function(Index) {
    Result <- as.list(Plan$CoreScenarios[Index, , drop = FALSE])
    Result$CumulativeMissingnessTargets <- unlist(Result$CumulativeMissingnessTargets)
    Result
  })
  Plan
}

# sourceCpp updates its cache index even when the DLL is already compiled.
# Initialize one worker at a time so those writes cannot overlap. Fitting
# still runs concurrently after every worker has loaded the compiled code.
InitializeSimulationWorkers <- function(Cluster, Path, Study = FALSE) {
  lapply(seq_along(Cluster), function(Index) {
    parallel::clusterCall(Cluster[Index], function(Path, Study) {
      source(file.path(Path, "R", "Load.R"), local = .GlobalEnv)
      LoadSimulation(Path, Compile = !Study)
      if (Study) InitializeStudyWorker(Path) else
        list(Pid = Sys.getpid(), Threads = Sys.getenv(
          c("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS")))
    }, Path, Study)[[1]]
  })
}
