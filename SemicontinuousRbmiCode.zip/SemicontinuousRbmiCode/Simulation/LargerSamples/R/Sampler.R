# Each generated trial uses one observed-data fit per trial and all nine borrowing rules.
CompleteSimulationChain <- function(Data, Chain, Rules, Analysis) {
  Result <- CompleteSimulationCpp(Data$Outcome, Data$Design, Data$Times, Data$UnitScale,
    Chain$Draws, Chain$LogVZeros, Chain$ZeroIndex,
    matrix(1, nrow(Data$Outcome), ncol(Data$Outcome)), 1*is.na(Data$Outcome),
    as.matrix(Rules[, c("ZeroWeight", "PositiveWeight")]), Analysis$Design,
    Analysis$Projection, Analysis$Leverage, 0)
  dimnames(Result$Statistics) <- list(NULL, Rules$Rule,
    c("Estimate", "WithinVariance", "UnadjustedDifference", "ReferenceMean", "ActiveMean", "ReferenceZero", "ActiveZero"))
  Result$Statistics
}

FitSimulationTrial <- function(Data, Path, Label, Plan, Settings, Streams, OutputRoot = "Formal") {
  Layout <- SimulationLayout(ncol(Data$Outcome))
  Rules <- RbmiRules(Plan$BorrowingWeights)
  Analysis <- RbmiAnalysisDesign(Data)
  Sources <- file.path(Path, "R", c("SharedSupport.R", "SimulationModel.R", "Sampler.R"))
  Sources <- c(Sources, list.files(file.path(Path, "src"), full.names = TRUE))
  Hashes <- setNames(vapply(Sources, FileHash, character(1)), basename(Sources))
  SamplingKey <- digest::digest(list(Data, Settings, Streams, Hashes), algo = "sha256")
  Output <- file.path(SimulationResultsPath(Path), OutputRoot, Label)
  dir.create(Output, recursive = TRUE, showWarnings = FALSE)
  Migration <- ReadTrialMigration(Output, Data, Settings, Streams, SamplingKey)
  Initial <- SimulationInitial(Data, Settings)
  Previous <- vector("list", Settings$Chains)
  ChunksByBlock <- list()
  NextBlock <- function(Block) {
    Chunks <- vector("list", Settings$Chains)
    for (Chain in seq_len(Settings$Chains)) {
      File <- file.path(Output, sprintf("Chain%02dBlock%03d.rds", Chain, Block))
      ParentKey <- if (Block == 1) NA_character_ else
        digest::digest(list(Previous[[Chain]]$ChainState, Previous[[Chain]]$RngState,
          Previous[[Chain]]$ImputationRngState))
      if (file.exists(File)) {
        Chunk <- readRDS(File)
        Assert(identical(Chunk$SamplingKey, SamplingKey) && identical(Chunk$ParentKey, ParentKey) &&
          identical(Chunk$Chain, Chain) && identical(Chunk$Block, Block) &&
          nrow(Chunk$Draws) == Settings$BlockDraws,
          "A checkpoint belongs to different code, settings, or preceding draws.")
      } else if (!is.null(Migration) &&
        sprintf("Chain%02dBlock%03d.rds", Chain, Block) %in% Migration$Chunks$File) {
        Chunk <- LoadMigratedChunk(Migration, Output, Chain, Block, ParentKey)
      } else {
        if (Block == 1) {
          assign(".Random.seed", Streams$Posterior[[Chain]], .GlobalEnv)
          Theta <- Initial$Theta
          Theta[-Layout$Correlation] <- Theta[-Layout$Correlation] + rnorm(Layout$Count - 1, sd = .25)
          Theta[Layout$Correlation] <- qlogis((1 + seq(-.6, .8, length.out = Settings$Chains)[Chain])/2)
          State <- NULL
          Warmup <- Settings$AdaptiveWarmup
        } else {
          assign(".Random.seed", Previous[[Chain]]$RngState, .GlobalEnv)
          Theta <- Previous[[Chain]]$ChainState$Theta
          State <- Previous[[Chain]]$ChainState
          Warmup <- 0
        }
        message(Label, ": chain ", Chain, ", block ", Block)
        Started <- proc.time()[[3]]
        Chunk <- RunSimulationChainCpp(Data$Outcome/Data$UnitScale, Data$Design, Data$Times, Theta,
          Settings$PriorMean, Settings$PriorSd, Initial$Covariances, Warmup, Settings$BlockDraws,
          Settings$AdaptEvery, Settings$ZeroSweeps, Settings$RhoA, Settings$RhoB, State)
        colnames(Chunk$Draws) <- Layout$Names
        Chunk$RngState <- get(".Random.seed", .GlobalEnv)
        Chunk$SamplerSeconds <- proc.time()[[3]] - Started
        # Independent streams for posterior sampling and imputation. Both states
        # continue exactly across blocks and are independent of worker scheduling.
        ImputationState <- if (Block == 1) Streams$Imputation[[Chain]] else
          Previous[[Chain]]$ImputationRngState
        assign(".Random.seed", ImputationState, .GlobalEnv)
        Chunk$Statistics <- CompleteSimulationChain(Data, Chunk, Rules, Analysis)
        Chunk$ImputationRngState <- get(".Random.seed", .GlobalEnv)
        Chunk$ElapsedSeconds <- proc.time()[[3]] - Started
        Chunk$Chain <- Chain
        Chunk$Block <- Block
        Chunk$SamplingKey <- SamplingKey
        Chunk$ParentKey <- ParentKey
        SaveCheckpoint(Chunk, File)
      }
      Chunks[[Chain]] <- Chunk
      Previous[[Chain]] <<- Chunk
    }
    ChunksByBlock[[Block]] <<- Chunks
    Chunks
  }
  Diagnose <- function(Chains) {
    Check <- SimulationDiagnostics(Chains, Settings)
    Imputed <- lapply(seq_along(Chains), function(Chain) {
      Indices <- Chains[[Chain]]$SummarizedBlocks
      if (is.null(Indices)) Indices <- Chains[[Chain]]$Block
      Parts <- lapply(Indices, function(Block) ChunksByBlock[[Block]][[Chain]]$Statistics)
      Values <- array(NA_real_, c(sum(vapply(Parts, function(Part) dim(Part)[1], numeric(1))), nrow(Rules), 7),
        dimnames = list(NULL, Rules$Rule, dimnames(Parts[[1]])[[3]]))
      Start <- 0
      for (Part in Parts) {
        Values[Start + seq_len(dim(Part)[1]), , ] <- Part
        Start <- Start + dim(Part)[1]
      }
      list(Statistics = Values)
    })
    Pooled <- PoolRbmiChains(Imputed, Rules, Analysis$DfComplete, RbmiSettings(McseFractionLimit = Plan$Diagnostics$PointMcseFractionMaximum,
        VarianceMcseFractionLimit = Plan$Diagnostics$VarianceMcseFractionMaximum),
      !anyNA(Data$Outcome[, ncol(Data$Outcome)]), Check$Converged, Settings$RhatLimit, Settings$EssLimit)
    Check$ModelSummary <- Check$Summary
    Check$ModelConverged <- Check$Converged
    Check$Pooled <- Pooled
    Additional <- Check$Summary[rep(1, nrow(Pooled)), , drop = FALSE]
    Additional[,] <- NA
    Additional$Parameter <- paste0("Imputation", Pooled$Rule)
    Additional$Rhat <- Pooled$MaximumRhat
    Additional$BulkEss <- Pooled$MinimumBulkEss
    Additional$TailEss <- Pooled$MinimumTailEss
    Check$Summary <- rbind(Check$Summary, Additional)
    Check$RhatPassed <- Check$RhatPassed && all(is.finite(Pooled$MaximumRhat) & Pooled$MaximumRhat <= Settings$RhatLimit)
    Check$EssPassed <- Check$EssPassed && all(Pooled$DiagnosticsPassed)
    Check$Converged <- Check$Converged && all(Pooled$DiagnosticsPassed & Pooled$PrecisionPassed)
    Check
  }
  Started <- proc.time()[[3]]
  Fit <- if (is.null(Migration))
    RunMcmcStages(NextBlock, Diagnose, Settings$MaxWarmupBlocks, Settings$MaxSamplingBlocks) else
    RunMigratedMcmcStages(NextBlock, Diagnose, Migration, Settings$MaxSamplingBlocks)
  TotalSeconds <- sum(vapply(ChunksByBlock, function(Chunks)
    sum(vapply(Chunks, function(Chunk) Chunk$ElapsedSeconds, numeric(1))), numeric(1)))
  Result <- list(Label = Label, Settings = Settings, SamplingKey = SamplingKey, SourceHashes = Hashes,
    Initial = Initial, Status = Fit$Status, Converged = Fit$Converged, History = Fit$History,
    SummaryBlocks = Fit$SummaryBlocks, RetainedBlocks = Fit$RetainedBlocks, WarmupBlocks = Fit$WarmupBlocks,
    SummaryScope = Fit$SummaryScope, ParameterSummary = Fit$Check$ModelSummary, Pooled = Fit$Check$Pooled,
    DrawsPerChain = nrow(Fit$Chains[[1]]$Draws), TotalSeconds = TotalSeconds,
    CurrentSessionSeconds = proc.time()[[3]] - Started, SessionInfo = capture.output(sessionInfo()))
  if (!is.null(Migration)) Result$VarianceMigration <- Migration
  saveRDS(Result, file.path(Output, "FitSummary.rds"))
  SaveTable(Result$History, file.path(Output, "ConvergenceHistory.csv"))
  SaveTable(Result$ParameterSummary, file.path(Output, "ParameterSummary.csv"))
  SaveTable(Result$Pooled, file.path(Output, "PooledResults.csv"))
  Result
}

