# Replication extensions retain explicit links to completed parent analyses.
ValidateReplicationTarget <- function(Manifest, Replicates) {
  Maximum <- max(vapply(Manifest$Jobs, function(Job) Job$Replicate, numeric(1)))
  Assert(length(Replicates) == 1 && is.finite(Replicates) && Replicates >= 1 &&
    Replicates == floor(Replicates) && Replicates <= Maximum,
    paste0("This study reserves 1 to ", Maximum,
      " trials per scenario. A larger target requires a prepared extension."))
  invisible(Maximum)
}

VerifyStudyExtension <- function(Manifest) {
  Extension <- Manifest$StudyExtension
  if (is.null(Extension)) return(invisible(NULL))
  ParentFile <- ResolveStudyFile(file.path(Extension$ParentResults, "StudyManifest.rds"))
  Assert(identical(FileHash(ParentFile), Extension$ParentManifestHash),
    "The extension's parent manifest changed.")
  Parent <- readRDS(ParentFile)
  VerifyVarianceMigration(Parent)
  Assert(identical(Parent$Key, Extension$ParentStudyKey) &&
    identical(Parent$Settings, Manifest$Settings) &&
    identical(Parent$PlanHash, Manifest$PlanHash) &&
    identical(Parent$CalibrationHash, Manifest$CalibrationHash) &&
    identical(Parent$TruthHash, Manifest$TruthHash) &&
    identical(Parent$Jobs, head(Manifest$Jobs, length(Parent$Jobs))) &&
    length(Manifest$Jobs) > length(Parent$Jobs),
    "The extension changed the parent design, targets, or random streams.")
  Assert(identical(FileHash(Extension$InheritanceFile), Extension$InheritanceHash) &&
    identical(FileHash(Extension$SourceAuditFile), Extension$SourceAuditHash) &&
    identical(FileHash(ResolveStudyFile(file.path(Extension$ParentResults, "SourceMaintenance.rds"))),
      Extension$ParentMaintenanceHash), "The extension provenance changed.")
  Audit <- readRDS(Extension$SourceAuditFile)
  Assert(identical(Audit$ParentStudyKey, Parent$Key) &&
    identical(Audit$CurrentSourceHashes, Manifest$SourceHashes),
    "The extension source audit does not match its manifest.")
  Records <- readRDS(Extension$InheritanceFile)
  Assert(identical(names(Records), vapply(Parent$Jobs, function(Job) Job$Label, character(1))) &&
    all(vapply(Records, function(Record) identical(Record$ParentStudyKey, Parent$Key), logical(1))),
    "The extension does not retain every completed parent trial.")
  invisible(Parent)
}

VerifyInheritedResults <- function(Path, Manifest) {
  Extension <- Manifest$StudyExtension
  if (is.null(Extension)) return(invisible(NULL))
  VerifyStudyExtension(Manifest)
  Records <- readRDS(Extension$InheritanceFile)
  for (Label in names(Records)) {
    Record <- Records[[Label]]
    ParentOutput <- file.path(Extension$ParentResults, "Formal", Label)
    Output <- file.path(SimulationResultsPath(Path), "Formal", Label)
    Expected <- Record$Files
    ParentHashes <- setNames(vapply(file.path(ParentOutput, names(Expected)),
      function(File) FileHash(ResolveStudyFile(File)), character(1)), names(Expected))
    CopiedHashes <- setNames(vapply(file.path(Output, names(Expected)),
      FileHash, character(1)), names(Expected))
    Assert(identical(ParentHashes, Expected) && identical(CopiedHashes, Expected),
      paste("Inherited trial files changed:", Label))
    Assert(identical(FileHash(ResolveStudyFile(file.path(ParentOutput, "Complete.rds"))), Record$MarkerHash),
      paste("The parent completion marker changed:", Label))
    Marker <- readRDS(file.path(Output, "Complete.rds"))
    ExpectedMarker <- readRDS(ResolveStudyFile(file.path(ParentOutput, "Complete.rds")))
    ExpectedMarker$StudyKey <- Manifest$Key
    ExpectedMarker$InheritedFrom <- list(StudyKey = Record$ParentStudyKey,
      ResultsDirectory = Extension$ParentResults, MarkerHash = Record$MarkerHash)
    Assert(identical(Marker, ExpectedMarker), paste("Inherited completion marker changed:", Label))
  }
  invisible(length(Records))
}
