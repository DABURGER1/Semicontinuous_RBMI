# This generator uses distribution functions in R and never calls the sampler.
GeneratingTheta <- function(Plan) {
  O <- Plan$Outcome
  c(rep(qlogis(O$ReferenceZeroProbabilityAtBaselineZero), Plan$VisitCount),
    log(O$ZeroTreatmentOddsRatio), O$ZeroBaselineCoefficient,
    log(O$ReferencePositiveMeansAtBaselineZero), log(O$PositiveTreatmentMeanRatio), O$PositiveBaselineCoefficient,
    log(sqrt(log1p(1/O$GammaShapes))), qlogis((1 + O$AdjacentLatentCorrelation)/2))
}

GenerateLatents <- function(Count, Plan) {
  R <- Plan$Outcome$AdjacentLatentCorrelation^
    abs(outer(seq_len(Plan$VisitCount), seq_len(Plan$VisitCount), "-"))
  list(Baseline = rnorm(Count), Uniform = pnorm(matrix(rnorm(Count*Plan$VisitCount), Count) %*% chol(R)))
}

GenerateOutcomes <- function(Latents, Treatment, Plan, Weights = c(0, 0)) {
  O <- Plan$Outcome
  Values <- matrix(0, length(Latents$Baseline), Plan$VisitCount)
  for (Visit in seq_len(Plan$VisitCount)) {
    Zero <- plogis(qlogis(O$ReferenceZeroProbabilityAtBaselineZero) +
      O$ZeroBaselineCoefficient*Latents$Baseline + (1 - Weights[1])*log(O$ZeroTreatmentOddsRatio)*Treatment)
    Mean <- O$ReferencePositiveMeansAtBaselineZero[Visit]*exp(O$PositiveBaselineCoefficient*Latents$Baseline +
      (1 - Weights[2])*log(O$PositiveTreatmentMeanRatio)*Treatment)
    Positive <- Latents$Uniform[, Visit] > Zero
    Values[Positive, Visit] <- qgamma((Latents$Uniform[Positive, Visit] - Zero[Positive])/(1 - Zero[Positive]),
      shape = O$GammaShapes[Visit], scale = Mean[Positive]/O$GammaShapes[Visit])
  }
  Assert(all(is.finite(Values)), "The generating outcomes are nonfinite.")
  Values
}

DropoutPredictors <- function(Outcome, Treatment, Baseline, Plan) {
  Previous <- cbind(0, Outcome[, seq_len(Plan$VisitCount - 1), drop = FALSE])
  Plan$Dropout$TreatmentCoefficient*Treatment + Plan$Dropout$BaselineCoefficient*Baseline +
    Plan$Dropout$PreviousAmountCoefficient*log1p(Previous/Plan$Outcome$UnitScale)
}

CalibrateDropout <- function(Plan, Count = 1000000) {
  RNGkind("Mersenne-Twister", "Inversion", "Rejection")
  set.seed(120261022)
  Latents <- GenerateLatents(Count, Plan)
  Treatment <- rep(0 : 1, length.out = Count)
  Outcome <- GenerateOutcomes(Latents, Treatment, Plan)
  Predictors <- DropoutPredictors(Outcome, Treatment, Latents$Baseline, Plan)
  Rows <- list()
  Intercepts <- list()
  for (Scenario in Plan$CoreScenarios) {
    Targets <- Scenario$CumulativeMissingnessTargets
    Risk <- rep(1, Count)
    Coefficients <- rep(-Inf, Plan$VisitCount)
    for (Visit in seq_len(Plan$VisitCount)) {
      PreviousTarget <- if (Visit == 1) 0 else Targets[Visit - 1]
      Increment <- Targets[Visit] - PreviousTarget
      if (Increment > 0) {
        Equation <- function(Value) mean(Risk*plogis(Value + Predictors[, Visit])) - Increment
        Coefficients[Visit] <- uniroot(Equation, c(-30, 30), tol = 1e-10)$root
        Risk <- Risk*(1 - plogis(Coefficients[Visit] + Predictors[, Visit]))
      }
    }
    Intercepts[[Scenario$Id]] <- Coefficients
  }
  # Validate the fixed coefficients against an independent population.
  set.seed(120261023)
  Latents <- GenerateLatents(Count, Plan)
  Treatment <- rep(0 : 1, length.out = Count)
  Outcome <- GenerateOutcomes(Latents, Treatment, Plan)
  Predictors <- DropoutPredictors(Outcome, Treatment, Latents$Baseline, Plan)
  for (Scenario in Plan$CoreScenarios) {
    Risk <- rep(1, Count)
    for (Visit in seq_len(Plan$VisitCount)) {
      Risk <- Risk*(1 - plogis(Intercepts[[Scenario$Id]][Visit] + Predictors[, Visit]))
      Rows[[length(Rows) + 1]] <- data.frame(Scenario = Scenario$Id, Visit = Visit,
        Intercept = Intercepts[[Scenario$Id]][Visit], Target = Scenario$CumulativeMissingnessTargets[Visit],
        Achieved = mean(1 - Risk), Mcse = sd(1 - Risk)/sqrt(Count))
    }
  }
  list(Intercepts = Intercepts, Validation = do.call(rbind, Rows), PopulationSize = Count,
    Seeds = c(120261022, 120261023), PlanHash = digest::digest(Plan))
}

GenerateTrial <- function(Scenario, Replicate, Plan, Calibration, RngState = NULL) {
  ScenarioIndex <- match(Scenario$Id, vapply(Plan$CoreScenarios, function(Value) Value$Id, character(1)))
  Seed <- 220261022 + 10000*ScenarioIndex + Replicate
  if (is.null(RngState)) set.seed(Seed) else assign(".Random.seed", RngState, .GlobalEnv)
  Count <- Scenario$SampleSize
  Treatment <- sample(rep(0 : 1, length.out = Count))
  Latents <- GenerateLatents(Count, Plan)
  Continuation <- GenerateOutcomes(Latents, Treatment, Plan)
  Predictors <- DropoutPredictors(Continuation, Treatment, Latents$Baseline, Plan)
  Hazard <- plogis(sweep(Predictors, 2, Calibration$Intercepts[[Scenario$Id]], "+"))
  Dropout <- rep(Plan$VisitCount + 1, Count)
  for (Visit in seq_len(Plan$VisitCount)) {
    New <- Dropout > Visit & runif(Count) < Hazard[, Visit]
    Dropout[New] <- Visit
  }
  Missing <- outer(Dropout, seq_len(Plan$VisitCount), "<=")
  Observed <- Continuation
  Observed[Missing] <- NA_real_
  Rules <- RbmiRules(Plan$BorrowingWeights)
  Complete <- lapply(seq_len(nrow(Rules)), function(Index) {
    Modified <- GenerateOutcomes(Latents, Treatment, Plan, unlist(Rules[Index, 2 : 3]))
    Result <- Continuation
    Result[Missing] <- Modified[Missing]
    Result
  })
  names(Complete) <- Rules$Rule
  # Only this Data object is supplied to fitting and imputation.
  Data <- list(Outcome = Observed, Design = cbind(Treatment = Treatment, Baseline = Latents$Baseline),
    Times = Plan$VisitTimes, UnitScale = Plan$Outcome$UnitScale)
  list(Data = Data, Complete = Complete, Dropout = Dropout,
    Seed = if (is.null(RngState)) Seed else NA_real_, InitialRngState = RngState,
    Scenario = Scenario$Id, Replicate = Replicate)
}

PopulationTruth <- function(Plan, Calibration, Batches = 20, BatchSize = 50000) {
  Rules <- RbmiRules(Plan$BorrowingWeights)
  Rows <- list()
  RNGkind("Mersenne-Twister", "Inversion", "Rejection")
  set.seed(320261022)
  for (Batch in seq_len(Batches)) {
    Latents <- GenerateLatents(BatchSize, Plan)
    Reference <- GenerateOutcomes(Latents, rep(0, BatchSize), Plan)
    Active <- GenerateOutcomes(Latents, rep(1, BatchSize), Plan)
    Predictors <- DropoutPredictors(Active, rep(1, BatchSize), Latents$Baseline, Plan)
    # Integrating dropout uniforms reduces numerical error without changing the law.
    Modified <- lapply(seq_len(nrow(Rules)), function(Rule)
      GenerateOutcomes(Latents, rep(1, BatchSize), Plan, unlist(Rules[Rule, 2 : 3]))[, Plan$VisitCount])
    for (Scenario in Plan$CoreScenarios) {
      Risk <- apply(1 - plogis(sweep(Predictors, 2, Calibration$Intercepts[[Scenario$Id]], "+")), 1, prod)
      for (Rule in seq_len(nrow(Rules))) {
        FinalActive <- Risk*Active[, Plan$VisitCount] + (1 - Risk)*Modified[[Rule]]
        Difference <- FinalActive - Reference[, Plan$VisitCount]
        Rows[[length(Rows) + 1]] <- data.frame(Batch = Batch, Scenario = Scenario$Id,
          Rule = Rules$Rule[Rule], Contrast = mean(Difference))
      }
    }
  }
  BatchResults <- do.call(rbind, Rows)
  Groups <- split(BatchResults, interaction(BatchResults$Scenario, BatchResults$Rule, drop = TRUE))
  Summary <- do.call(rbind, lapply(Groups, function(Values) data.frame(
    Scenario = Values$Scenario[1], Rule = Values$Rule[1], Truth = mean(Values$Contrast),
    TruthMcse = sd(Values$Contrast)/sqrt(nrow(Values)))))
  rownames(Summary) <- NULL
  O <- Plan$Outcome
  ArmMean <- function(Treatment) integrate(function(X) {
    (1 - plogis(qlogis(O$ReferenceZeroProbabilityAtBaselineZero) + O$ZeroBaselineCoefficient*X +
      Treatment*log(O$ZeroTreatmentOddsRatio)))*
      O$ReferencePositiveMeansAtBaselineZero[Plan$VisitCount]*
      exp(O$PositiveBaselineCoefficient*X + Treatment*log(O$PositiveTreatmentMeanRatio))*dnorm(X)
  }, -10, 10, rel.tol = 1e-11)$value
  ExactContinuation <- ArmMean(1) - ArmMean(0)
  list(Summary = Summary, Batches = BatchResults, ExactContinuation = ExactContinuation,
    PopulationSize = Batches*BatchSize, Seed = 320261022,
    Method = "Paired arms with dropout uniforms integrated analytically",
    PlanHash = digest::digest(Plan), CalibrationHash = digest::digest(Calibration))
}
