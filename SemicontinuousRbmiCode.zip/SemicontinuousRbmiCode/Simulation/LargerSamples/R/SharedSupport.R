# Stable utilities reused from the application; source hashes are in SourceProvenance.json.

Assert <- function(Condition, Message) {
  if (!isTRUE(Condition)) stop(Message, call. = FALSE)
}

SaveTable <- function(Values, Path) {
  write.csv(Values, Path, row.names = FALSE, na = "", fileEncoding = "UTF-8")
}

SaveCheckpoint <- function(Object, Path) {
  Assert(!file.exists(Path), "A checkpoint already exists at the requested path.")
  TemporaryPath <- tempfile(pattern = "Checkpoint", tmpdir = dirname(Path), fileext = ".rds")
  on.exit(unlink(TemporaryPath), add = TRUE)
  saveRDS(Object, TemporaryPath, compress = "gzip")
  Assert(file.rename(TemporaryPath, Path), "Could not finalize the chain checkpoint.")
  invisible(Path)
}

FileHash <- function(Path) {
  digest::digest(readBin(Path, what = "raw", n = file.info(Path)$size),
    algo = "sha256", serialize = FALSE
  )
}

SummarizeDrawArray <- function(DrawArray) {
  Summary <- as.data.frame(posterior::summarise_draws(
    posterior::as_draws_array(DrawArray),
    Mean = mean, Median = median, Sd = sd,
    Lower = function(Values) unname(quantile(Values, .025)),
    Upper = function(Values) unname(quantile(Values, .975)),
    Rhat = posterior::rhat, BulkEss = posterior::ess_bulk,
    TailEss = posterior::ess_tail, McseMean = posterior::mcse_mean
  ))
  names(Summary)[1] <- "Parameter"
  Summary
}

CombineChainBlocks <- function(BlockSets) {
  Assert(length(BlockSets) > 0, "No sampling blocks are available.")
  lapply(seq_along(BlockSets[[1]]), function(Index) {
    Parts <- lapply(BlockSets, function(Blocks) Blocks[[Index]])
    Combined <- Parts[[length(Parts)]]
    for (Field in c("Draws", "LogVZeros")) {
      Combined[[Field]] <- do.call(rbind, lapply(Parts, function(Part) Part[[Field]]))
    }
    for (Field in c("LogAugmentedLikelihood", "LogPosterior")) {
      Combined[[Field]] <- unlist(lapply(Parts, function(Part) Part[[Field]]), use.names = FALSE)
    }
    Counts <- vapply(Parts, function(Part) nrow(Part$Draws), numeric(1))
    Combined$Acceptance <- Reduce(`+`, lapply(
      seq_along(Parts),
      function(Position) Parts[[Position]]$Acceptance*Counts[Position]
    ))/sum(Counts)
    Combined$ElapsedSeconds <- sum(vapply(Parts, function(Part) Part$ElapsedSeconds, numeric(1)))
    Combined$InvalidProposals <- sum(vapply(Parts, function(Part) Part$InvalidProposals, numeric(1)))
    Combined$SummarizedBlocks <- vapply(Parts, function(Part) Part$Block, numeric(1))
    Combined
  })
}

RunMcmcStages <- function(NextBlock, Diagnose, MaxWarmupBlocks = 5, MaxSamplingBlocks = 5) {
  Blocks <- list()
  History <- list()
  AddHistory <- function(Stage, Block, SummaryBlocks, Check) {
    Table <- Check$Summary
    FiniteMaximum <- function(Values) if (all(is.finite(Values))) max(Values) else NA_real_
    FiniteMinimum <- function(Values) if (all(is.finite(Values))) min(Values) else NA_real_
    History[[length(History) + 1]] <<- data.frame(
      Stage = Stage, Block = Block,
      FirstSummaryBlock = min(SummaryBlocks), LastSummaryBlock = max(SummaryBlocks),
      MaxRhat = FiniteMaximum(Table$Rhat), MinBulkEss = FiniteMinimum(Table$BulkEss),
      MinTailEss = FiniteMinimum(Table$TailEss), RhatPassed = Check$RhatPassed,
      EssPassed = Check$EssPassed, Converged = Check$Converged
    )
  }
  FirstPassingBlock <- NA_real_
  for (Block in seq_len(MaxWarmupBlocks)) {
    Blocks[[Block]] <- NextBlock(Block)
    Check <- Diagnose(Blocks[[Block]])
    AddHistory("WarmupScreen", Block, Block, Check)
    message("Warmup block ", Block, ": R-hat ", if (Check$RhatPassed) "passed." else "not yet passed.")
    if (Check$RhatPassed) {
      FirstPassingBlock <- Block
      break
    }
  }
  if (is.na(FirstPassingBlock)) {
    LastBlock <- length(Blocks)
    return(list(
      Chains = Blocks[[LastBlock]], Check = Check,
      History = do.call(rbind, History), FirstPassingBlock = NA_real_,
      WarmupBlocks = seq_len(LastBlock), RetainedBlocks = numeric(),
      SummaryBlocks = LastBlock, SummaryScope = "LatestBlockWithoutRhatPass",
      Converged = FALSE, Status = "WarmupLimitReached"
    ))
  }
  SummaryBlocks <- FirstPassingBlock
  for (StageBlock in seq_len(MaxSamplingBlocks)) {
    if (StageBlock > 1) {
      Block <- length(Blocks) + 1
      Blocks[[Block]] <- NextBlock(Block)
      SummaryBlocks <- c(SummaryBlocks, Block)
    }
    Chains <- CombineChainBlocks(Blocks[SummaryBlocks])
    Check <- Diagnose(Chains)
    AddHistory("RetainedSample", max(SummaryBlocks), SummaryBlocks, Check)
    message(
      "Retained block ", StageBlock, ": ",
      if (Check$Converged) "R-hat and ESS passed." else "more sampling is needed."
    )
    if (Check$Converged) break
  }
  list(
    Chains = Chains, Check = Check, History = do.call(rbind, History),
    FirstPassingBlock = FirstPassingBlock,
    WarmupBlocks = if (FirstPassingBlock > 1) seq_len(FirstPassingBlock - 1) else numeric(),
    RetainedBlocks = SummaryBlocks, SummaryBlocks = SummaryBlocks,
    SummaryScope = "AllRetainedDraws", Converged = Check$Converged,
    Status = if (Check$Converged) "Converged" else "SamplingLimitReached"
  )
}

RbmiRules <- function(Weights = c(0, .5, 1)) {
  Assert(is.numeric(Weights) && length(Weights) && all(is.finite(Weights)) &&
    all(Weights >= 0 & Weights <= 1) && !anyDuplicated(Weights), "Invalid borrowing weights.")
  Rules <- expand.grid(ZeroWeight = Weights, PositiveWeight = Weights)
  Rules$Rule <- paste0("Zero", format(100*Rules$ZeroWeight, trim = TRUE, scientific = FALSE), "Positive", format(100*Rules$PositiveWeight, trim = TRUE, scientific = FALSE))
  Rules$Rule[Rules$ZeroWeight == 0 & Rules$PositiveWeight == 0] <- "Continuation"
  Rules$Rule[Rules$ZeroWeight == 1 & Rules$PositiveWeight == 0] <- "AbstinenceReference"
  Rules$Rule[Rules$ZeroWeight == 0 & Rules$PositiveWeight == 1] <- "PositiveReference"
  Rules$Rule[Rules$ZeroWeight == 1 & Rules$PositiveWeight == 1] <- "JumpToReference"
  Rules[, c("Rule", "ZeroWeight", "PositiveWeight")]
}

RbmiSettings <- function(Seed = 20261022, Confidence = .95, ExampleCount = 1,
                         McseFractionLimit = .05, VarianceMcseFractionLimit = .05) {
  Assert(length(Seed) == 1 && is.finite(Seed) && Seed == floor(Seed) && Seed >= 0,
    "Use a nonnegative whole-number imputation seed.")
  Assert(length(ExampleCount) == 1 && is.finite(ExampleCount) && ExampleCount >= 0 &&
    ExampleCount == floor(ExampleCount), "Use a nonnegative whole-number example count.")
  Assert(length(Confidence) == 1 && is.finite(Confidence) && Confidence > 0 && Confidence < 1,
    "Specify a confidence level between zero and one.")
  Assert(all(is.finite(c(McseFractionLimit, VarianceMcseFractionLimit))) &&
    McseFractionLimit > 0 && VarianceMcseFractionLimit > 0, "Specify positive Monte Carlo precision limits.")
  list(Seed = Seed, Confidence = Confidence, ExampleCount = ExampleCount,
    McseFractionLimit = McseFractionLimit, VarianceMcseFractionLimit = VarianceMcseFractionLimit)
}

RbmiAnalysisDesign <- function(Data) {
  Design <- Data$Design
  Assert(is.matrix(Design) && ncol(Design) == 2 && nrow(Design) == nrow(Data$Outcome) &&
    all(is.finite(Design)) && all(Design[, 1] %in% c(0, 1)), "Invalid treatment or baseline design.")
  Baseline <- Design[, 2] - mean(Design[, 2])
  Treatment <- Design[, 1]
  W <- cbind(Intercept = 1, Treatment = Treatment, Baseline = Baseline, Interaction = Treatment*Baseline)
  Decomposition <- qr(W)
  Assert(nrow(W) > ncol(W) && Decomposition$rank == ncol(W), "The completed-data design is not full rank.")
  Projection <- qr.coef(Decomposition, diag(nrow(W)))
  Leverage <- rowSums(W*t(Projection))
  Assert(all(is.finite(Projection)) && all(Leverage < 1 - 1e-10), "The completed-data design has excessive leverage.")
  StandardizationFactor <- sum(Baseline^2)/(nrow(W)*(nrow(W) - 1))
  list(Design = W, Projection = Projection, Leverage = Leverage,
    StandardizationFactor = StandardizationFactor, VarianceMethod = "HC3PlusEmpiricalStandardization",
    DfComplete = nrow(W) - ncol(W))
}

RbmiMonteCarlo <- function(Values) {
  Assert(is.matrix(Values) && all(is.finite(Values)), "Invalid Monte Carlo diagnostic input.")
  Constant <- diff(range(Values)) <= 1e-12*max(1, max(abs(Values)))
  if (Constant) return(c(Rhat = 1, BulkEss = length(Values), TailEss = length(Values), Mcse = 0))
  c(Rhat = posterior::rhat(Values), BulkEss = posterior::ess_bulk(Values),
    TailEss = posterior::ess_tail(Values), Mcse = posterior::mcse_mean(Values))
}

RubinPool <- function(Estimates, Variances, DfComplete, Confidence = .95, CompleteOutcome = FALSE) {
  Assert(length(Estimates) >= 2 && length(Estimates) == length(Variances) &&
    all(is.finite(Estimates)) && all(is.finite(Variances)) && all(Variances >= 0), "Invalid estimates for Rubin pooling.")
  Assert(length(DfComplete) == 1 && is.finite(DfComplete) && DfComplete > 0 &&
    Confidence > 0 && Confidence < 1, "Invalid confidence or complete-data degrees of freedom.")
  M <- length(Estimates)
  Estimate <- mean(Estimates)
  Within <- mean(Variances)
  Between <- if (CompleteOutcome) 0 else var(Estimates)
  Total <- Within + (1 + 1/M)*Between
  if (CompleteOutcome) {
    Assert(diff(range(Estimates)) <= 1e-10*max(1, abs(Estimate)) &&
      diff(range(Variances)) <= 1e-10*max(1, Within), "A complete outcome produced different analyses.")
  }
  Lambda <- if (Total > 0) (1 + 1/M)*Between/Total else 0
  OldDf <- if (Lambda > 0) (M - 1)/Lambda^2 else Inf
  ObservedDf <- (DfComplete + 1)/(DfComplete + 3)*DfComplete*(1 - Lambda)
  Df <- if (CompleteOutcome || Total == 0) DfComplete else 1/(1/OldDf + 1/ObservedDf)
  Assert(is.finite(Df) && Df > 0, "Rubin degrees of freedom are undefined.")
  Se <- sqrt(Total)
  Critical <- qt((1 + Confidence)/2, Df)
  c(Estimate = Estimate, StandardError = Se, Lower = Estimate - Critical*Se,
    Upper = Estimate + Critical*Se, WithinVariance = Within, BetweenVariance = Between,
    TotalVariance = Total, Lambda = Lambda, Df = Df, Imputations = M)
}

PoolRbmiChains <- function(Chains, Rules, DfComplete, Settings, CompleteOutcome = FALSE,
                           FitConverged = TRUE, RhatLimit = 1.05, EssLimit = 400) {
  Sizes <- vapply(Chains, function(Chain) dim(Chain$Statistics)[1], numeric(1))
  Assert(length(Sizes) >= 2 && length(unique(Sizes)) == 1 && Sizes[1] >= 4,
    "Pooling diagnostics require equal chain lengths and at least four draws per chain.")
  Rows <- lapply(seq_len(nrow(Rules)), function(Rule) {
    Q <- vapply(Chains, function(Chain) Chain$Statistics[, Rule, "Estimate"], numeric(Sizes[1]))
    U <- vapply(Chains, function(Chain) Chain$Statistics[, Rule, "WithinVariance"], numeric(Sizes[1]))
    Pooled <- RubinPool(as.vector(Q), as.vector(U), DfComplete, Settings$Confidence, CompleteOutcome)
    M <- length(Q)
    Influence <- U + (1 + 1/M)*M/(M - 1)*(Q - mean(Q))^2
    PointCheck <- RbmiMonteCarlo(Q)
    VarianceCheck <- RbmiMonteCarlo(Influence)
    Fraction <- if (Pooled["StandardError"] > 0) PointCheck["Mcse"]/Pooled["StandardError"] else 0
    VarianceFraction <- if (Pooled["TotalVariance"] > 0) VarianceCheck["Mcse"]/Pooled["TotalVariance"] else 0
    DiagnosticValues <- rbind(PointCheck, VarianceCheck)
    DiagnosticsPassed <- all(is.finite(DiagnosticValues)) && all(DiagnosticValues[, "Rhat"] <= RhatLimit) &&
      all(DiagnosticValues[, "BulkEss"] >= EssLimit) && all(DiagnosticValues[, "TailEss"] >= EssLimit)
    PrecisionPassed <- is.finite(Fraction) && is.finite(VarianceFraction) &&
      Fraction <= Settings$McseFractionLimit && VarianceFraction <= Settings$VarianceMcseFractionLimit
    Status <- if (!FitConverged) "InputFitFlagged" else if (!DiagnosticsPassed) "ImputationDiagnosticsFlagged" else if (!PrecisionPassed) "MonteCarloPrecisionFlagged" else "ChecksPassed"
    Supporting <- vapply(c("UnadjustedDifference", "ReferenceMean", "ActiveMean", "ReferenceZero", "ActiveZero"),
      function(Name) mean(unlist(lapply(Chains, function(Chain) Chain$Statistics[, Rule, Name]))), numeric(1))
    cbind(Rules[Rule, , drop = FALSE], as.data.frame(as.list(Pooled)), as.data.frame(as.list(Supporting)), data.frame(
      McseEstimate = unname(PointCheck["Mcse"]), McseVariance = unname(VarianceCheck["Mcse"]),
      McseFraction = unname(Fraction), VarianceMcseFraction = unname(VarianceFraction),
      MaximumRhat = max(DiagnosticValues[, "Rhat"]), MinimumBulkEss = min(DiagnosticValues[, "BulkEss"]),
      MinimumTailEss = min(DiagnosticValues[, "TailEss"]), FitConverged = FitConverged,
      DiagnosticsPassed = DiagnosticsPassed, PrecisionPassed = PrecisionPassed, Status = Status,
      DegenerateVariance = Pooled["TotalVariance"] == 0, CompleteFinalOutcome = CompleteOutcome))
  })
  Result <- do.call(rbind, Rows)
  rownames(Result) <- NULL
  Result
}
