# Numerical checks compare independent calculations and preserve the existing
# application's four-visit behavior. No trial is regenerated to make a check pass.
ValidateSimulation <- function(Path, Plan, Settings) {
  Results <- list()
  Check <- function(Name, Passed, Detail = "") {
    Results[[length(Results) + 1]] <<- data.frame(Check = Name, Passed = isTRUE(Passed), Detail = Detail)
    if (!isTRUE(Passed)) stop("Validation failed: ", Name)
    message("Passed: ", Name)
  }
  Near <- function(First, Second, Tolerance = 1e-10) isTRUE(all.equal(as.numeric(First), as.numeric(Second),
    tolerance = Tolerance, check.attributes = FALSE))
  Layout <- SimulationLayout(3)
  Check("FourteenCoordinates", Layout$Count == 14 && length(Settings$PriorMean) == 13)
  set.seed(920261022)
  Latents <- GenerateLatents(80, Plan)
  Treatment <- rep(0 : 1, 40)
  Y <- GenerateOutcomes(Latents, Treatment, Plan)
  Design <- cbind(Treatment, Latents$Baseline)
  Theta <- GeneratingTheta(Plan)
  LogV <- matrix(log(.4), 80, 3)
  # Independent R normal-copula density, including all eight observed patterns.
  Patterns <- as.matrix(expand.grid(rep(list(c(FALSE, TRUE)), 3)))
  YPatterns <- Y
  for (Subject in seq_len(nrow(YPatterns))) YPatterns[Subject, !Patterns[(Subject - 1)%%8 + 1, ]] <- NA
  RLikelihood <- function(Outcome, Parameter) {
    J <- ncol(Outcome)
    L <- SimulationLayout(J)
    Shapes <- 1/expm1(exp(2*Parameter[L$Shape]))
    R <- tanh(Parameter[L$Correlation]/2)^abs(outer(seq_len(J), seq_len(J), "-"))
    vapply(seq_len(nrow(Outcome)), function(Subject) {
      Visits <- which(!is.na(Outcome[Subject, ]))
      if (!length(Visits)) return(0)
      P <- plogis(Parameter[Visits] + Parameter[L$ZeroTreatment]*Design[Subject, 1] +
        Parameter[L$ZeroBaseline]*Design[Subject, 2])
      M <- exp(Parameter[J + 2 + Visits] + Parameter[L$PositiveTreatment]*Design[Subject, 1] +
        Parameter[L$PositiveBaseline]*Design[Subject, 2])
      Values <- Outcome[Subject, Visits]
      Positive <- Values > 0
      U <- P*exp(LogV[Subject, Visits])
      Density <- log(P)
      U[Positive] <- P[Positive] + (1 - P[Positive])*pgamma(Values[Positive],
        shape = Shapes[Visits[Positive]], scale = M[Positive]/Shapes[Visits[Positive]])
      Density[Positive] <- log1p(-P[Positive]) + dgamma(Values[Positive],
        shape = Shapes[Visits[Positive]], scale = M[Positive]/Shapes[Visits[Positive]], log = TRUE)
      Z <- qnorm(U)
      Sub <- R[Visits, Visits, drop = FALSE]
      sum(Density) - as.numeric(determinant(Sub, logarithm = TRUE)$modulus)/2 -
        as.numeric(t(Z) %*% (solve(Sub) - diag(length(Visits))) %*% Z)/2
    }, numeric(1))
  }
  for (Shapes in list(c(1.3, 1.3, 1.3), c(.7, 1.8, 3.2))) {
    Parameter <- Theta
    Parameter[Layout$Shape] <- log(sqrt(log1p(1/Shapes)))
    Evaluated <- EvaluateSimulationCpp(Parameter, YPatterns, Design, 1 : 3, LogV,
      Settings$PriorMean, Settings$PriorSd, Settings$RhoA, Settings$RhoB)
    Check(paste0("AllPatternsLikelihood", length(Results)), Evaluated$Valid &&
      Near(Evaluated$LogBySubject, RLikelihood(YPatterns, Parameter)))
    LogPrior <- sum(dnorm(Parameter[1 : 13], Settings$PriorMean, Settings$PriorSd, log = TRUE)) +
      dbeta(plogis(Parameter[14]), Settings$RhoA, Settings$RhoB, log = TRUE) +
      log(plogis(Parameter[14])) + log(plogis(-Parameter[14]))
    Check(paste0("PriorJacobian", length(Results)), Near(LogPrior, Evaluated$LogPrior))
  }
  for (Rho in c(-.9, -.4, 0, .4, .9)) {
    Parameter <- Theta
    Parameter[Layout$Correlation] <- qlogis((1 + Rho)/2)
    Evaluated <- EvaluateSimulationCpp(Parameter, YPatterns, Design, 1 : 3, LogV,
      Settings$PriorMean, Settings$PriorSd, Settings$RhoA, Settings$RhoB)
    Check(paste0("SignedCorrelationLikelihood", length(Results)), Evaluated$Valid &&
      Near(Evaluated$LogBySubject, RLikelihood(YPatterns, Parameter)))
    Q <- (1 + Rho)/2
    RhoLogDensity <- Evaluated$LogPrior -
      sum(dnorm(Parameter[1 : 13], Settings$PriorMean, Settings$PriorSd, log = TRUE)) -
      log(2*Q*(1 - Q))
    Check(paste0("ScaledBetaDensity", length(Results)),
      Near(RhoLogDensity, dbeta(Q, Settings$RhoA, Settings$RhoB, log = TRUE) - log(2)))
  }
  Original <- new.env(parent = globalenv())
  for (Name in c("GammaCopula.cpp", "GammaRbmi.cpp")) Rcpp::sourceCpp(
    file.path(dirname(dirname(Path)), "Application", "src", Name), env = Original,
    cacheDir = file.path(Path, "Results", "ReferenceCompilerCache"), showOutput = FALSE)
  J <- 4
  L4 <- SimulationLayout(J)
  Theta4 <- c(rep(qlogis(.15), J), log(1.5), -.25, log(c(1.4, 1.2, 1.1, 1)),
    log(.9), .3, log(sqrt(log1p(1/c(.8, 1.1, 1.7, 2.3)))), qlogis((1 + .8)/2))
  Y4 <- cbind(Y, Y[, 3]/2)
  Y4[1 : 5, 3 : 4] <- NA
  LogV4 <- matrix(log(.4), 80, 4)
  Prior4 <- rep(0, 16)
  Sd4 <- rep(5, 16)
  Times4 <- c(4, 12, 20, 26)
  Old <- Original$EvaluateGammaCpp(Theta4, Y4, Design, Times4, LogV4, Prior4, Sd4)
  New <- EvaluateSimulationCpp(Theta4, Y4, Design, Times4, LogV4, Prior4, Sd4)
  Check("ApplicationLikelihoodUnchanged", identical(Old, New))
  Cov4 <- list(diag(.03, 6), diag(.03, 10), matrix(.1))
  set.seed(10)
  OldChain <- Original$RunGammaChainCpp(Y4, Design, Times4, Theta4, Prior4, Sd4, Cov4, 100, 200)
  set.seed(10)
  NewChain <- RunSimulationChainCpp(Y4, Design, Times4, Theta4, Prior4, Sd4, Cov4, 100, 200)
  Check("ApplicationSamplerSameDraws", identical(OldChain, NewChain))
  Analysis <- RbmiAnalysisDesign(list(Outcome = Y4, Design = Design))
  Rules <- RbmiRules()
  Arguments <- list(Y4, Design, Times4, 1, OldChain$Draws, OldChain$LogVZeros, OldChain$ZeroIndex,
    matrix(1, 80, 4), 1*is.na(Y4), as.matrix(Rules[, 2 : 3]), Analysis$Design,
    Analysis$Projection, Analysis$Leverage, 1)
  set.seed(11)
  OldComplete <- do.call(Original$CompleteGammaRbmiCpp, Arguments)
  set.seed(11)
  NewComplete <- do.call(CompleteSimulationCpp, Arguments)
  Check("ApplicationImputationsUnchanged", identical(OldComplete, NewComplete))
  Data <- list(Outcome = YPatterns, Design = Design, Times = 1 : 3, UnitScale = 1)
  Initial <- SimulationInitial(Data, Settings)
  Run <- function(Count, Warmup, State = NULL) RunSimulationChainCpp(YPatterns, Design, 1 : 3,
    Initial$Theta, Settings$PriorMean, Settings$PriorSd, Initial$Covariances,
    Warmup, Count, RhoA = Settings$RhoA, RhoB = Settings$RhoB, Continuation = State)
  set.seed(21)
  Full <- Run(200, 100)
  set.seed(21)
  First <- Run(100, 100)
  Second <- Run(100, 0, First$ChainState)
  Check("ExactChainContinuation", identical(Full$Draws, rbind(First$Draws, Second$Draws)) &&
    identical(Full$LogVZeros, rbind(First$LogVZeros, Second$LogVZeros)))
  Analysis <- RbmiAnalysisDesign(Data)
  Complete <- CompleteSimulationCpp(YPatterns, Design, 1 : 3, 1, Full$Draws, Full$LogVZeros,
    Full$ZeroIndex, matrix(1, 80, 3), 1*is.na(YPatterns), as.matrix(Rules[, 2 : 3]),
    Analysis$Design, Analysis$Projection, Analysis$Leverage, 1)
  for (Rule in seq_len(nrow(Rules))) {
    Values <- Complete$Examples[, , Rule]
    Check(paste0("PreserveObservedRule", Rule), identical(Values[!is.na(YPatterns)], YPatterns[!is.na(YPatterns)]))
    Fitted <- lm(Values[, 3] ~ Analysis$Design - 1)
    W <- model.matrix(Fitted)
    Bread <- solve(crossprod(W))
    Meat <- crossprod(W, W*as.vector((residuals(Fitted)/(1 - hatvalues(Fitted)))^2))
    Hc3 <- Bread %*% Meat %*% Bread
    StandardizationVariance <- unname(coef(Fitted)[4]^2*var(W[, 3])/nrow(W))
    Check(paste0("IndependentPopulationVarianceRule", Rule), Near(coef(Fitted)[2], Complete$Statistics[1, Rule, 1]) &&
      Near(Hc3[2, 2], Complete$CoefficientVariance[1, Rule]) &&
      Near(StandardizationVariance, Complete$StandardizationVariance[1, Rule]) &&
      Near(Hc3[2, 2] + StandardizationVariance, Complete$Statistics[1, Rule, 2]))
  }
  Check("PopulationVarianceComponents", all(Complete$CoefficientVariance >= 0) &&
    all(Complete$StandardizationVariance >= 0) &&
    Near(Complete$Statistics[, , 2], Complete$CoefficientVariance + Complete$StandardizationVariance))
  BenchmarkTrial <- list(Data = Data, Complete = setNames(lapply(seq_len(nrow(Rules)),
    function(Rule) Complete$Examples[, , Rule]), Rules$Rule))
  Benchmark <- CompleteDataBenchmark(BenchmarkTrial, Plan)
  Check("CompleteBenchmarkUsesPopulationVariance", Near(Benchmark$Estimate, Complete$Statistics[1, , 1]) &&
    Near(Benchmark$TotalVariance, Complete$Statistics[1, , 2]))
  # Visit-order dependence is invariant to elapsed-time labels.
  Rescaled <- EvaluateSimulationCpp(Theta, YPatterns, Design, 4*(1 : 3), LogV,
    Settings$PriorMean, Settings$PriorSd, Settings$RhoA, Settings$RhoB)
  OriginalTime <- EvaluateSimulationCpp(Theta, YPatterns, Design, 1 : 3, LogV,
    Settings$PriorMean, Settings$PriorSd, Settings$RhoA, Settings$RhoB)
  Check("CorrelationUsesVisitOrder", identical(Rescaled, OriginalTime))
  # Quantile transform moments and latent Gaussian covariance use a fresh sample.
  set.seed(920261023)
  Large <- GenerateLatents(200000, Plan)
  Z <- qnorm(Large$Uniform)
  ExpectedR <- .8^abs(outer(1 : 3, 1 : 3, "-"))
  Check("LatentCorrelation", max(abs(cor(Z) - ExpectedR)) < .01)
  Large$Baseline[] <- 0
  Values <- GenerateOutcomes(Large, rep(0, length(Large$Baseline)), Plan)
  ExpectedMean <- .85*Plan$Outcome$ReferencePositiveMeansAtBaselineZero
  ExpectedSecond <- .85*Plan$Outcome$ReferencePositiveMeansAtBaselineZero^2*(1 + 1/Plan$Outcome$GammaShapes)
  Check("MixtureMeans", all(abs(colMeans(Values) - ExpectedMean) < 5*apply(Values, 2, sd)/sqrt(nrow(Values))))
  Check("MixtureSecondMoments", all(abs(colMeans(Values^2) - ExpectedSecond) <
    5*apply(Values^2, 2, sd)/sqrt(nrow(Values))))
  Check("MixtureZeroMass", max(abs(colMeans(Values == 0) - .15)) < .004)
  for (Case in c("AllZero", "AllPositive", "EmptyVisit", "AllMissing")) {
    Sparse <- Data
    if (Case == "AllZero") Sparse$Outcome[!is.na(Sparse$Outcome)] <- 0
    if (Case == "AllPositive") Sparse$Outcome[!is.na(Sparse$Outcome)] <- 1
    if (Case == "EmptyVisit") Sparse$Outcome[, 3] <- NA_real_
    if (Case == "AllMissing") Sparse$Outcome[,] <- NA_real_
    Candidate <- SimulationInitial(Sparse, Settings)
    Value <- EvaluateSimulationCpp(Candidate$Theta, Sparse$Outcome, Design, 1 : 3, LogV,
      Settings$PriorMean, Settings$PriorSd, Settings$RhoA, Settings$RhoB)
    Check(paste0("FiniteInitialization", Case), Value$Valid)
  }
  ZeroEffects <- Plan
  ZeroEffects$Outcome$ZeroTreatmentOddsRatio <- 1
  ZeroEffects$Outcome$PositiveTreatmentMeanRatio <- 1
  Reference <- GenerateOutcomes(Latents, rep(0, 80), ZeroEffects)
  for (Rule in seq_len(nrow(Rules))) {
    Active <- GenerateOutcomes(Latents, rep(1, 80), ZeroEffects, unlist(Rules[Rule, 2 : 3]))
    Check(paste0("NullPairedTruthRule", Rule), identical(Reference, Active))
  }
  # Complete data have identical analyses across all completions and rules.
  Data$Outcome <- Y
  CompleteInitial <- SimulationInitial(Data, Settings)
  LogZeros <- matrix(log(.4), 5, sum(Y == 0))
  ZeroIndex <- which(t(Y) == 0, arr.ind = TRUE)[, 2 : 1, drop = FALSE]
  Draws <- matrix(rep(CompleteInitial$Theta, each = 5), 5)
  Completed <- CompleteSimulationCpp(Y, Design, 1 : 3, 1, Draws, LogZeros, ZeroIndex,
    matrix(1, 80, 3), matrix(0, 80, 3), as.matrix(Rules[, 2 : 3]),
    Analysis$Design, Analysis$Projection, Analysis$Leverage, 0)
  Check("CompleteDataIdenticalRules", diff(range(Completed$Statistics[, , 1])) == 0 &&
    diff(range(Completed$Statistics[, , 2])) == 0)
  Pooled <- RubinPool(as.vector(Completed$Statistics[, , 1]), as.vector(Completed$Statistics[, , 2]),
    76, CompleteOutcome = TRUE)
  Check("CompleteDataRubinBZero", Pooled["BetweenVariance"] == 0)
  Constant <- RbmiMonteCarlo(matrix(Completed$Statistics[, , 1], 5))
  Check("ConstantAnalysisNoMcse", Constant["Mcse"] == 0 && Constant["Rhat"] == 1)
  # Draw-array ordering must preserve parameters and separate chains.
  Mock <- replicate(4, Full, simplify = FALSE)
  for (Chain in seq_along(Mock)) colnames(Mock[[Chain]]$Draws) <- Layout$Names
  Diagnostic <- SimulationDiagnostics(Mock, Settings)
  Check("ThirtyOneMonitoredQuantities", nrow(Diagnostic$Summary) == 31 &&
    Near(Diagnostic$Summary$Mean[1], mean(Full$Draws[, 1])))
  # Independently validate Gaussian conditioning in the completion kernel.
  # Tiny zero mass keeps every sampled completion positive so its latent score
  # can be recovered from the ordinary gamma CDF.
  ConditionalY <- matrix(NA_real_, 8, 3)
  ConditionalY[1 : 2, 1] <- 1
  ConditionalY[3 : 4, 2] <- 1
  ConditionalY[7 : 8, 1 : 2] <- 1
  ConditionalDesign <- cbind(rep(0 : 1, 4), seq(-1, 1, length.out = 8))
  ConditionalAnalysis <- RbmiAnalysisDesign(list(Outcome = ConditionalY, Design = ConditionalDesign))
  ConditionalTheta <- c(rep(qlogis(1e-20), 3), 0, 0, rep(0, 3), 0, 0,
    log(sqrt(log1p(1/c(.7, 1.8, 3.2)))), qlogis((1 + .8)/2))
  ConditionalDraws <- matrix(rep(ConditionalTheta, each = 20000), 20000)
  set.seed(920261024)
  Completed <- CompleteSimulationCpp(ConditionalY, ConditionalDesign, 1 : 3, 1,
    ConditionalDraws, matrix(numeric(), 20000, 0), matrix(integer(), 0, 2),
    matrix(1, 8, 3), 1*is.na(ConditionalY), matrix(c(0, 0), 1),
    ConditionalAnalysis$Design, ConditionalAnalysis$Projection, ConditionalAnalysis$Leverage, 20000)
  for (Subject in c(1, 3, 5, 7)) {
    Observed <- which(!is.na(ConditionalY[Subject, ]))
    Missing <- which(is.na(ConditionalY[Subject, ]))
    Shapes <- c(.7, 1.8, 3.2)
    Scores <- t(Completed$Examples[Subject, Missing, , drop = FALSE][1, , ])
    if (length(Missing) == 1) Scores <- matrix(Scores, ncol = 1)
    for (Index in seq_along(Missing)) Scores[, Index] <- qnorm(pgamma(Scores[, Index],
      shape = Shapes[Missing[Index]], scale = 1/Shapes[Missing[Index]]))
    R <- ExpectedR
    Mean <- rep(0, length(Missing))
    Variance <- R[Missing, Missing, drop = FALSE]
    if (length(Observed)) {
      Regression <- R[Missing, Observed, drop = FALSE] %*% solve(R[Observed, Observed, drop = FALSE])
      Mean <- as.vector(Regression %*% qnorm(pgamma(rep(1, length(Observed)),
        shape = Shapes[Observed], scale = 1/Shapes[Observed])))
      Variance <- Variance - Regression %*% R[Observed, Missing, drop = FALSE]
    }
    Check(paste0("GaussianConditionalMean", Subject),
      all(abs(colMeans(Scores) - Mean) < 5*sqrt(diag(Variance)/nrow(Scores))))
    Check(paste0("GaussianConditionalCovariance", Subject), max(abs(cov(Scores) - Variance)) < .03)
  }
  if (file.exists(file.path(SimulationResultsPath(Path), "Truth.rds"))) {
    Calibration <- readRDS(file.path(SimulationResultsPath(Path), "Calibration.rds"))
    Truth <- readRDS(file.path(SimulationResultsPath(Path), "Truth.rds"))
    Check("IndependentCalibrationTargets", max(abs(Calibration$Validation$Achieved - Calibration$Validation$Target)) < .001)
    Check("TruthAbsolutePrecision", max(Truth$Summary$TruthMcse) <= Plan$Truth$MaximumAbsoluteMcse)
    Continued <- Truth$Summary[Truth$Summary$Rule == "Continuation", ]
    Check("TruthVersusNormalQuadrature", all(abs(Continued$Truth - Truth$ExactContinuation) < 5*Continued$TruthMcse))
    Check("ContinuationInvariantToDropout", diff(range(Continued$Truth)) < 1e-12)
    Trial <- GenerateTrial(Plan$CoreScenarios[[2]], 1, Plan, Calibration)
    for (Rule in names(Trial$Complete)) Check(paste0("SameObservedData", Rule),
      identical(Trial$Complete[[Rule]][!is.na(Trial$Data$Outcome)], Trial$Data$Outcome[!is.na(Trial$Data$Outcome)]))
    Final <- vapply(Trial$Complete, function(Values) mean(Values[, 3]), numeric(1))
    Check("BorrowingDirection", Final["JumpToReference"] >= Final["Continuation"])
  }
  Table <- do.call(rbind, Results)
  SaveTable(Table, file.path(SimulationResultsPath(Path), "Validation.csv"))
  saveRDS(Table, file.path(SimulationResultsPath(Path), "Validation.rds"))
  writeLines(capture.output(sessionInfo()), file.path(SimulationResultsPath(Path), "ValidationSession.txt"))
  writeLines(capture.output(warnings()), file.path(SimulationResultsPath(Path), "ValidationWarnings.txt"))
  message(nrow(Table), " validation checks passed.")
}
