# All finite fits contribute, including fits flagged by the convergence checks.
# Numerical failures are reported and retained in coverage bounds.
ParameterTargets <- function(Plan) {
  Layout <- SimulationLayout(Plan$VisitCount)
  Theta <- GeneratingTheta(Plan)
  O <- Plan$Outcome
  Values <- setNames(Theta, Layout$Names)
  Values <- c(Values, ZeroOddsRatio = O$ZeroTreatmentOddsRatio,
    PositiveMeanRatio = O$PositiveTreatmentMeanRatio,
    setNames(O$GammaShapes, paste0("GammaShapeVisit", seq_len(Plan$VisitCount))),
    AdjacentCorrelation = O$AdjacentLatentCorrelation,
    BaselineZeroOddsRatio = exp(O$ZeroBaselineCoefficient),
    BaselinePositiveMeanRatio = exp(O$PositiveBaselineCoefficient))
  for (Visit in seq_len(Plan$VisitCount)) {
    ReferenceZero <- O$ReferenceZeroProbabilityAtBaselineZero
    ActiveZero <- plogis(qlogis(ReferenceZero) + log(O$ZeroTreatmentOddsRatio))
    ReferenceMean <- O$ReferencePositiveMeansAtBaselineZero[Visit]
    ActiveMean <- ReferenceMean*O$PositiveTreatmentMeanRatio
    Values <- c(Values, setNames(c(ActiveZero - ReferenceZero, ActiveMean - ReferenceMean,
      (1 - ActiveZero)*ActiveMean - (1 - ReferenceZero)*ReferenceMean),
      paste0(c("ZeroDifference", "PositiveDifference", "OverallDifference"), "AtXZeroVisit", Visit)))
  }
  Values
}

PerformanceSummary <- function(Values, Grouping, CompletedByScenario) {
  if (is.null(Values) || !nrow(Values)) return(data.frame())
  Groups <- split(Values, interaction(Values[, Grouping, drop = FALSE], drop = TRUE, lex.order = TRUE))
  do.call(rbind, lapply(Groups, function(Group) {
    Attempted <- unname(CompletedByScenario[Group$Scenario[1]])
    Good <- is.finite(Group$Estimate) & is.finite(Group$TotalVariance) &
      is.finite(Group$Lower) & is.finite(Group$Upper) & is.finite(Group$Truth)
    Finite <- Group[Good, , drop = FALSE]
    Count <- nrow(Finite)
    Error <- Finite$Estimate - Finite$Truth
    Covered <- sum(Finite$Lower <= Finite$Truth & Finite$Upper >= Finite$Truth)
    Coverage <- if (Count) Covered/Count else NA_real_
    BiasMcse <- if (Count > 1) sd(Error)/sqrt(Count) else NA_real_
    Width <- Finite$Upper - Finite$Lower
    EmpiricalSd <- if (Count > 1) sd(Finite$Estimate) else NA_real_
    Rmse <- if (Count) sqrt(mean(Error^2)) else NA_real_
    CoverageInterval <- if (Count) binom.test(Covered, Count)$conf.int else c(NA_real_, NA_real_)
    cbind(Group[1, Grouping, drop = FALSE], data.frame(Attempted = Attempted, Finite = Count,
      Unavailable = Attempted - Count, Bias = if (Count) mean(Error) else NA_real_, BiasMcse = BiasMcse,
      EmpiricalSd = EmpiricalSd, RootMeanSquaredError = Rmse,
      RmseMcse = if (Count > 1 && Rmse > 0) sd(Error^2)/sqrt(Count)/(2*Rmse) else NA_real_,
      MeanEstimatedVariance = if (Count) mean(Finite$TotalVariance) else NA_real_,
      VarianceRatio = if (is.finite(EmpiricalSd) && EmpiricalSd > 0)
        mean(Finite$TotalVariance)/EmpiricalSd^2 else NA_real_,
      Coverage = Coverage,
      CoverageMcse = if (Count) sqrt(Coverage*(1 - Coverage)/Count) else NA_real_,
      CoverageIntervalLower = CoverageInterval[1], CoverageIntervalUpper = CoverageInterval[2],
      CoverageLowerIncludingFailures = if (Attempted) Covered/Attempted else NA_real_,
      CoverageUpperIncludingFailures = if (Attempted) (Covered + Attempted - Count)/Attempted else NA_real_,
      MeanIntervalWidth = if (Count) mean(Width) else NA_real_,
      WidthMcse = if (Count > 1) sd(Width)/sqrt(Count) else NA_real_,
      TruthMcse = if ("TruthMcse" %in% names(Finite) && Count) Finite$TruthMcse[1] else 0))
  }))
}

HtmlTable <- function(Table) {
  Escape <- function(Text) {
    Text <- gsub("&", "&amp;", as.character(Text), fixed = TRUE)
    Text <- gsub("<", "&lt;", Text, fixed = TRUE)
    gsub(">", "&gt;", Text, fixed = TRUE)
  }
  if (!nrow(Table)) return("<p>No completed trials yet.</p>")
  for (Name in names(Table)) if (is.numeric(Table[[Name]])) Table[[Name]] <- signif(Table[[Name]], 4)
  Header <- paste0("<tr>", paste0("<th>", Escape(names(Table)), "</th>", collapse = ""), "</tr>")
  Rows <- apply(Table, 1, function(Row) paste0("<tr>", paste0("<td>", Escape(Row), "</td>", collapse = ""), "</tr>"))
  paste0("<table><thead>", Header, "</thead><tbody>", paste(Rows, collapse = ""), "</tbody></table>")
}

ReportStudy <- function(Path, Plan, Replicates = NULL) {
  if (is.null(Replicates)) {
    Current <- file.path(SimulationResultsPath(Path), "CurrentRun.json")
    Replicates <- if (file.exists(Current)) jsonlite::fromJSON(Current)$ReplicatesPerScenario else
      Plan$FormalStudy$ReplicatesPerScenario
  }
  Manifest <- readRDS(file.path(SimulationResultsPath(Path), "StudyManifest.rds"))
  ValidateReplicationTarget(Manifest, Replicates)
  Truth <- readRDS(file.path(SimulationResultsPath(Path), "Truth.rds"))$Summary
  Targets <- ParameterTargets(Plan)
  Fits <- Pooled <- Parameters <- Benchmarks <- list()
  ScenarioIds <- vapply(Plan$CoreScenarios, function(Scenario) Scenario$Id, character(1))
  for (Job in Manifest$Jobs) {
    if (Job$Replicate > Replicates) next
    Output <- file.path(SimulationResultsPath(Path), "Formal", Job$Label)
    Marker <- file.path(Output, "Complete.rds")
    if (!file.exists(Marker)) next
    Finished <- readRDS(Marker)
    Assert(identical(Finished$StudyKey, Manifest$Key), "A trial does not belong to the frozen study.")
    Row <- data.frame(Label = Job$Label, Scenario = Job$Scenario, Replicate = Job$Replicate,
      Status = Finished$Status, Converged = Finished$Converged, WallSeconds = Finished$WallSeconds,
      MissingFinal = Finished$Observed$MissingFinal, NoFollowup = Finished$Observed$NoFollowup,
      ZeroFraction = Finished$Observed$ZeroFraction, DrawsPerChain = NA_real_,
      SamplerImputationSeconds = NA_real_, MaxRhat = NA_real_, MinBulkEss = NA_real_, MinTailEss = NA_real_,
      MaximumEstimateMcseFraction = NA_real_, MaximumVarianceMcseFraction = NA_real_,
      WarningCount = length(Finished$Warnings))
    Common <- data.frame(Label = Job$Label, Scenario = Job$Scenario, Replicate = Job$Replicate)
    BenchmarkFile <- file.path(Output, "CompleteDataBenchmark.csv")
    if (file.exists(BenchmarkFile)) Benchmarks[[length(Benchmarks) + 1]] <- cbind(Common, read.csv(BenchmarkFile))
    if (Finished$Status != "NumericalFailure") {
      Fit <- readRDS(file.path(Output, "FitSummary.rds"))
      Last <- tail(Fit$History, 1)
      Row$DrawsPerChain <- Fit$DrawsPerChain
      Row$SamplerImputationSeconds <- Fit$TotalSeconds
      Row$MaxRhat <- Last$MaxRhat
      Row$MinBulkEss <- Last$MinBulkEss
      Row$MinTailEss <- Last$MinTailEss
      Row$MaximumEstimateMcseFraction <- max(Fit$Pooled$McseFraction)
      Row$MaximumVarianceMcseFraction <- max(Fit$Pooled$VarianceMcseFraction)
      Pooled[[length(Pooled) + 1]] <- cbind(Common, Fit$Pooled)
      Parameter <- Fit$ParameterSummary
      Parameter$Truth <- unname(Targets[Parameter$Parameter])
      Parameter$Estimate <- Parameter$Mean
      Parameter$TotalVariance <- Parameter$Sd^2
      Parameters[[length(Parameters) + 1]] <- cbind(Common, Parameter)
    }
    Fits[[length(Fits) + 1]] <- Row
  }
  FitTable <- if (length(Fits)) do.call(rbind, Fits) else data.frame()
  CompletedByScenario <- if (length(Fits)) table(factor(FitTable$Scenario, levels = ScenarioIds)) else
    setNames(rep(0, length(ScenarioIds)), ScenarioIds)
  Progress <- do.call(rbind, lapply(ScenarioIds, function(Id) {
    Selected <- if (length(Fits)) FitTable[FitTable$Scenario == Id, , drop = FALSE] else FitTable
    data.frame(Scenario = Id, Planned = Replicates, Completed = nrow(Selected),
      Pending = Replicates - nrow(Selected),
      Converged = if (nrow(Selected)) sum(Selected$Converged) else 0,
      Flagged = if (nrow(Selected)) sum(!Selected$Converged & Selected$Status != "NumericalFailure") else 0,
      Failed = if (nrow(Selected)) sum(Selected$Status == "NumericalFailure") else 0)
  }))
  Output <- SimulationResultsPath(Path)
  SaveTable(Progress, file.path(Output, "Progress.csv"))
  if (nrow(FitTable)) SaveTable(FitTable, file.path(Output, "Fits.csv"))
  MatchedSummary <- data.frame()
  if (length(Pooled)) {
    Pooled <- merge(do.call(rbind, Pooled), Truth, by = c("Scenario", "Rule"), sort = FALSE)
    Pooled$Error <- Pooled$Estimate - Pooled$Truth
    Pooled$CoversTruth <- Pooled$Lower <= Pooled$Truth & Pooled$Upper >= Pooled$Truth
    SaveTable(Pooled, file.path(Output, "Estimates.csv"))
    MatchedSummary <- PerformanceSummary(Pooled, c("Scenario", "Rule"), CompletedByScenario)
    SaveTable(MatchedSummary, file.path(Output, "MatchedPerformance.csv"))
    DifferentTargets <- Truth
    names(DifferentTargets)[names(DifferentTargets) == "Rule"] <- "GeneratingRule"
    Crossed <- merge(Pooled[, setdiff(names(Pooled), c("Truth", "TruthMcse", "Error", "CoversTruth"))],
      DifferentTargets, by = "Scenario", sort = FALSE)
    Crossed$Matched <- Crossed$Rule == Crossed$GeneratingRule
    SaveTable(Crossed, file.path(Output, "AssumptionComparisons.csv"))
    SaveTable(PerformanceSummary(Crossed, c("Scenario", "GeneratingRule", "Rule"), CompletedByScenario),
      file.path(Output, "AssumptionPerformance.csv"))
    Precision <- MatchedSummary[, c("Scenario", "Rule", "Finite", "BiasMcse", "TruthMcse")]
    Precision$Ratio <- Precision$TruthMcse/Precision$BiasMcse
    Precision$AbsolutePassed <- Precision$TruthMcse <= Plan$Truth$MaximumAbsoluteMcse
    Precision$RelativePassed <- is.finite(Precision$Ratio) &
      Precision$Ratio <= Plan$Truth$MaximumMcseFractionOfStudyBiasMcse
    SaveTable(Precision, file.path(Output, "TruthPrecision.csv"))
  }
  if (length(Parameters)) {
    Parameters <- do.call(rbind, Parameters)
    SaveTable(Parameters, file.path(Output, "ParameterEstimates.csv"))
    SaveTable(PerformanceSummary(Parameters, c("Scenario", "Parameter"), CompletedByScenario),
      file.path(Output, "ParameterPerformance.csv"))
  }
  if (length(Benchmarks)) {
    Benchmarks <- merge(do.call(rbind, Benchmarks), Truth, by = c("Scenario", "Rule"), sort = FALSE)
    SaveTable(Benchmarks, file.path(Output, "CompleteDataBenchmarks.csv"))
    SaveTable(PerformanceSummary(Benchmarks, c("Scenario", "Rule"), CompletedByScenario),
      file.path(Output, "CompleteDataPerformance.csv"))
  }
  Complete <- sum(Progress$Pending) == 0
  Summary <- c(if (Complete) "FORMAL SIMULATION: COMPLETE" else "FORMAL SIMULATION: IN PROGRESS",
    paste("Completed:", sum(Progress$Completed), "of", sum(Progress$Planned)),
    paste("Converged:", sum(Progress$Converged), "; flagged:", sum(Progress$Flagged), "; numerical failures:", sum(Progress$Failed)),
    "All finite flagged fits are included. Failures are not replaced.",
    "Coverage is reported among finite fits together with bounds including failures.",
    "Pending trials are not counted as failures. Pilot trials are excluded.",
    "Intervals use Rubin pooling with HC3 within-imputation variances augmented for empirical covariate standardization; no bootstrap.",
    paste("Updated UTC:", format(Sys.time(), tz = "UTC", usetz = TRUE)))
  writeLines(Summary, file.path(Output, "Summary.txt"))
  Display <- MatchedSummary
  if (nrow(Display)) Display <- Display[, c("Scenario", "Rule", "Finite", "Bias", "BiasMcse",
    "Coverage", "CoverageMcse", "MeanIntervalWidth")]
  Html <- paste0('<!doctype html><html lang="en"><meta charset="utf-8"><title>Formal simulation</title>',
    '<style>body{font:16px/1.5 system-ui,sans-serif;color:#203045;max-width:1200px;margin:36px auto;padding:0 24px}',
    'table{border-collapse:collapse;width:100%;font-size:13px}th,td{text-align:right;padding:7px;border-bottom:1px solid #dbe3ec}',
    'th{background:#edf3f8}th:first-child,td:first-child{text-align:left}</style>',
    '<h1>Semicontinuous copula RBMI: formal simulation</h1><p>',
    if (Complete) 'Completed' else 'Interim results', ': ', Replicates, ' trials per scenario. Four chains per trial.</p>',
    '<p>Three post-baseline visits, one baseline covariate, separate visit-specific gamma shapes, and nine borrowing rules. ',
    'One observed-data fit serves all rules. Every retained draw contributes to imputation and Rubin pooling.</p>',
    HtmlTable(Progress), '<h2>Matched assumptions</h2>', HtmlTable(Display),
    '<p>Bias and coverage are accompanied by Monte Carlo standard errors. All finite flagged fits remain included; ',
    'coverage bounds including unavailable fits are in the CSV summaries. These bounds are not confidence intervals.</p>',
    '<p><a href="ParameterPerformance.csv">Parameter recovery</a> | <a href="CompleteDataPerformance.csv">Complete-data benchmarks</a> | ',
    '<a href="AssumptionPerformance.csv">Mismatched assumptions</a> | <a href="Fits.csv">Convergence and timing</a> | ',
    '<a href="TruthPrecision.csv">Population-target precision</a> | <a href="Validation.csv">Numerical checks</a> | ',
    '<a href="ExecutionChecks.csv">Parallel execution checks</a></p>',
    '<p>Regenerate this report with --stage=Report. The run also refreshes it after each batch.</p></html>')
  writeLines(Html, file.path(Output, "StudyReport.html"))
  invisible(Progress)
}
