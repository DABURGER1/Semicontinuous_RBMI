# Parameter order follows Appendix A: zero regression, positive regression,
# independent visit-specific dispersion coordinates, then logit of the rescaled correlation.
SimulationLayout <- function(Visits = 3) {
  list(Visits = Visits, Count = 3*Visits + 5,
    Zero = seq_len(Visits + 2), ZeroTreatment = Visits + 1, ZeroBaseline = Visits + 2,
    Positive = Visits + 2 + seq_len(Visits + 2),
    PositiveTreatment = 2*Visits + 3, PositiveBaseline = 2*Visits + 4,
    Shape = 2*Visits + 4 + seq_len(Visits), Correlation = 3*Visits + 5,
    Names = c(paste0("ZeroInterceptVisit", seq_len(Visits)), "ZeroTreatment", "ZeroBaseline",
      paste0("PositiveInterceptVisit", seq_len(Visits)), "PositiveTreatment", "PositiveBaseline",
      paste0("LogDispersionVisit", seq_len(Visits)), "LogitScaledAdjacentCorrelation"))
}

SimulationSettings <- function(Plan) {
  Visits <- Plan$VisitCount
  list(Chains = Plan$Diagnostics$Chains, AdaptiveWarmup = Plan$Diagnostics$AdaptiveWarmup,
    BlockDraws = Plan$Diagnostics$BlockDraws,
    MaxWarmupBlocks = Plan$Diagnostics$MaximumBlocksPerStage,
    MaxSamplingBlocks = Plan$Diagnostics$MaximumBlocksPerStage,
    AdaptEvery = Plan$Diagnostics$AdaptEvery, ZeroSweeps = Plan$Diagnostics$ZeroSweeps,
    RhatLimit = Plan$Diagnostics$RhatMaximum,
    EssLimit = max(Plan$Diagnostics$BulkEssMinimum, Plan$Diagnostics$TailEssMinimum),
    PriorMean = c(rep(0, 2*Visits + 4), rep(Plan$Priors$TransformedShapeMean, Visits)),
    PriorSd = c(rep(Plan$Priors$ZeroInterceptSd, Visits), rep(Plan$Priors$TreatmentAndBaselineSd, 2),
      rep(Plan$Priors$PositiveInterceptSd, Visits), rep(Plan$Priors$TreatmentAndBaselineSd, 2),
      rep(Plan$Priors$TransformedShapeSd, Visits)),
    RhoA = Plan$Priors$CorrelationBetaShape[1], RhoB = Plan$Priors$CorrelationBetaShape[2])
}

SimulationInitial <- function(Data, Settings) {
  Layout <- SimulationLayout(ncol(Data$Outcome))
  Positions <- which(!is.na(Data$Outcome), arr.ind = TRUE)
  Y <- Data$Outcome[Positions]
  W <- cbind(diag(Layout$Visits)[Positions[, 2], , drop = FALSE],
    Data$Design[Positions[, 1], , drop = FALSE])
  Start <- rep(0, Layout$Count)
  for (Visit in seq_len(Layout$Visits)) {
    Values <- Data$Outcome[, Visit]
    Observed <- sum(!is.na(Values))
    Start[Visit] <- qlogis((sum(Values == 0, na.rm = TRUE) + .5)/(Observed + 1))
    Positive <- Values[!is.na(Values) & Values > 0]
    Start[Layout$Visits + 2 + Visit] <- if (length(Positive)) log(mean(Positive)) else 0
  }
  Start[Layout$Shape] <- log(sqrt(log(2)))
  Start[Layout$Correlation] <- qlogis((1 + .8)/2)
  # Proper marginal posterior modes are initialization only. This also handles
  # an empty visit or no observed zeros without replacing the trial dataset.
  ZeroObjective <- function(Coefficients) {
    Eta <- as.vector(W %*% Coefficients)
    Soft <- pmax(Eta, 0) + log1p(exp(-abs(Eta)))
    sum(Soft - (Y == 0)*Eta) - sum(dnorm(Coefficients, Settings$PriorMean[Layout$Zero],
      Settings$PriorSd[Layout$Zero], log = TRUE))
  }
  PositiveIndices <- c(Layout$Positive, Layout$Shape)
  PositiveObjective <- function(Coefficients) {
    Selected <- Y > 0
    Mean <- exp(as.vector(W[Selected, , drop = FALSE] %*% Coefficients[seq_len(Layout$Visits + 2)]))
    Shape <- 1/expm1(exp(2*Coefficients[Layout$Visits + 2 + Positions[Selected, 2]]))
    if (any(!is.finite(Mean)) || any(Mean <= 0) || any(!is.finite(Shape)) || any(Shape <= 0) ||
      any(!is.finite(Mean/Shape)) || any(Mean/Shape <= 0)) return(1e100)
    Value <- -sum(dgamma(Y[Selected], shape = Shape, scale = Mean/Shape, log = TRUE)) -
      sum(dnorm(Coefficients, Settings$PriorMean[PositiveIndices], Settings$PriorSd[PositiveIndices], log = TRUE))
    if (is.finite(Value)) Value else 1e100
  }
  Objectives <- list(ZeroObjective, PositiveObjective)
  Indices <- list(Layout$Zero, PositiveIndices)
  Covariances <- list()
  Codes <- numeric(2)
  for (Block in 1 : 2) {
    Selected <- Indices[[Block]]
    Fit <- optim(Start[Selected], Objectives[[Block]], method = "BFGS", hessian = TRUE,
      control = list(maxit = 1000, reltol = 1e-9))
    Codes[Block] <- Fit$convergence
    if (all(is.finite(Fit$par)) && is.finite(Fit$value)) Start[Selected] <- Fit$par
    Hessian <- Fit$hessian
    Covariance <- diag(.05, length(Selected))
    if (all(is.finite(Hessian))) {
      E <- eigen((Hessian + t(Hessian))/2, symmetric = TRUE)
      Covariance <- E$vectors %*% diag(pmin(2, pmax(1e-4, 1/pmax(E$values, .5)))) %*% t(E$vectors)
    }
    Covariances[[Block]] <- Covariance
  }
  Covariances[[3]] <- matrix(.15)
  names(Start) <- Layout$Names
  list(Theta = Start, Covariances = Covariances, OptimizationCodes = Codes)
}

SimulationDiagnostics <- function(Chains, Settings) {
  Layout <- SimulationLayout((ncol(Chains[[1]]$Draws) - 5)/3)
  Values <- lapply(Chains, function(Chain) {
    Draws <- Chain$Draws
    Extra <- cbind(exp(Draws[, Layout$ZeroTreatment]), exp(Draws[, Layout$PositiveTreatment]),
      1/expm1(exp(2*Draws[, Layout$Shape, drop = FALSE])), tanh(Draws[, Layout$Correlation]/2),
      exp(Draws[, Layout$ZeroBaseline]), exp(Draws[, Layout$PositiveBaseline]))
    colnames(Extra) <- c("ZeroOddsRatio", "PositiveMeanRatio", paste0("GammaShapeVisit", seq_len(Layout$Visits)),
      "AdjacentCorrelation", "BaselineZeroOddsRatio", "BaselinePositiveMeanRatio")
    for (Visit in seq_len(Layout$Visits)) {
      ReferenceZero <- plogis(Draws[, Visit])
      ActiveZero <- plogis(Draws[, Visit] + Draws[, Layout$ZeroTreatment])
      ReferenceMean <- exp(Draws[, Layout$Visits + 2 + Visit])
      ActiveMean <- ReferenceMean*exp(Draws[, Layout$PositiveTreatment])
      Profile <- cbind(ActiveZero - ReferenceZero, ActiveMean - ReferenceMean,
        (1 - ActiveZero)*ActiveMean - (1 - ReferenceZero)*ReferenceMean)
      colnames(Profile) <- paste0(c("ZeroDifference", "PositiveDifference", "OverallDifference"), "AtXZeroVisit", Visit)
      Extra <- cbind(Extra, Profile)
    }
    cbind(Draws, Extra)
  })
  DrawArray <- array(unlist(Values), c(nrow(Values[[1]]), ncol(Values[[1]]), length(Values)))
  DrawArray <- aperm(DrawArray, c(1, 3, 2))
  dimnames(DrawArray) <- list(NULL, paste0("Chain", seq_along(Chains)), colnames(Values[[1]]))
  Summary <- SummarizeDrawArray(DrawArray)
  Summary$RhatPassed <- is.finite(Summary$Rhat) & Summary$Rhat <= Settings$RhatLimit
  Summary$EssPassed <- is.finite(Summary$BulkEss) & is.finite(Summary$TailEss) &
    Summary$BulkEss >= Settings$EssLimit & Summary$TailEss >= Settings$EssLimit
  list(Summary = Summary, RhatPassed = all(Summary$RhatPassed), EssPassed = all(Summary$EssPassed),
    Converged = all(Summary$RhatPassed & Summary$EssPassed))
}
