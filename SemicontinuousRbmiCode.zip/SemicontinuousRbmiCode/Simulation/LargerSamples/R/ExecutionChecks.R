# Small numerical checks of task streams, scheduling and checkpoint reuse.
ExecutionFingerprint <- function(Job, Plan, Calibration, Settings) {
  Scenario <- Plan$CoreScenarios[[match(Job$Scenario,
    vapply(Plan$CoreScenarios, function(Value) Value$Id, character(1)))]]
  Trial <- GenerateTrial(Scenario, Job$Replicate, Plan, Calibration, Job$Streams$Generation)
  Data <- Trial$Data
  Initial <- SimulationInitial(Data, Settings)
  assign(".Random.seed", Job$Streams$Posterior[[1]], .GlobalEnv)
  Chain <- RunSimulationChainCpp(Data$Outcome, Data$Design, Data$Times, Initial$Theta,
    Settings$PriorMean, Settings$PriorSd, Initial$Covariances, 50, 80,
    Settings$AdaptEvery, Settings$ZeroSweeps, Settings$RhoA, Settings$RhoB, NULL)
  State <- get(".Random.seed", .GlobalEnv)
  assign(".Random.seed", Job$Streams$Imputation[[1]], .GlobalEnv)
  Completed <- CompleteSimulationChain(Data, Chain, RbmiRules(Plan$BorrowingWeights), RbmiAnalysisDesign(Data))
  list(Outcome = Data$Outcome, Draws = Chain$Draws, LogVZeros = Chain$LogVZeros,
    PosteriorState = State, Statistics = Completed, ImputationState = get(".Random.seed", .GlobalEnv))
}

ValidateExecution <- function(Path, Plan, Settings) {
  Results <- list()
  Check <- function(Name, Passed) {
    Results[[length(Results) + 1]] <<- data.frame(Check = Name, Passed = isTRUE(Passed))
    Assert(Passed, paste("Execution validation failed:", Name))
  }
  Jobs <- MakeStudyJobs(Plan, Settings)
  Count <- Plan$FormalStudy$MaximumReplicatesPerScenario
  Check("ReservedTrialCount", length(Jobs) == length(Plan$CoreScenarios)*Count)
  Check("BalancedReservedScenarios", all(table(vapply(Jobs, function(Job) Job$Scenario, character(1))) == Count))
  Streams <- unlist(lapply(Jobs, function(Job)
    c(list(Job$Streams$Generation), Job$Streams$Posterior, Job$Streams$Imputation)), recursive = FALSE)
  Keys <- vapply(Streams, function(State) paste(State, collapse = ","), character(1))
  Check("DistinctDatasetChainImputationStreams", !anyDuplicated(Keys))
  Check("DeterministicStreamLedger", identical(Jobs, MakeStudyJobs(Plan, Settings)))
  Calibration <- if (file.exists(file.path(SimulationResultsPath(Path), "Calibration.rds")))
    readRDS(file.path(SimulationResultsPath(Path), "Calibration.rds")) else CalibrateDropout(Plan)
  Selected <- Jobs[1 : 4]
  Serial <- lapply(Selected, ExecutionFingerprint, Plan, Calibration, Settings)
  Cluster <- parallel::makePSOCKcluster(2, outfile = file.path(SimulationResultsPath(Path), "ExecutionWorkerLog.txt"),
    rscript_args = "--vanilla")
  on.exit(parallel::stopCluster(Cluster), add = TRUE)
  InitializeSimulationWorkers(Cluster, Path)
  Parallel <- parallel::parLapplyLB(Cluster, rev(Selected),
    function(Job, Plan, Calibration, Settings) ExecutionFingerprint(Job, Plan, Calibration, Settings),
    Plan, Calibration, Settings, chunk.size = 1)
  Check("SerialEqualsParallelAfterReordering", identical(Serial, rev(Parallel)))
  Check("DistinctTrialsAcrossStreams", !identical(Serial[[1]]$Outcome, Serial[[2]]$Outcome))
  ThreadLimits <- parallel::clusterCall(Cluster, function()
    Sys.getenv(c("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS")))
  Check("OneComputationalThreadPerWorker", all(unlist(ThreadLimits) == "1"))
  Trial <- GenerateTrial(Plan$CoreScenarios[[2]], 1, Plan, Calibration, Jobs[[2]]$Streams$Generation)
  Small <- Settings
  Small$AdaptiveWarmup <- 30
  Small$BlockDraws <- 40
  Small$MaxWarmupBlocks <- 1
  Small$MaxSamplingBlocks <- 1
  Root <- file.path("ExecutionValidation", paste0("Run", format(Sys.time(), "%Y%m%d%H%M%S")))
  First <- FitSimulationTrial(Trial$Data, Path, "ResumeCheck", Plan, Small, Jobs[[2]]$Streams, Root)
  Folder <- file.path(SimulationResultsPath(Path), Root, "ResumeCheck")
  Files <- list.files(Folder, pattern = "^Chain.*rds$", full.names = TRUE)
  Hashes <- vapply(Files, FileHash, character(1))
  Second <- FitSimulationTrial(Trial$Data, Path, "ResumeCheck", Plan, Small, Jobs[[2]]$Streams, Root)
  Fields <- c("ParameterSummary", "Pooled", "DrawsPerChain", "Status", "SummaryBlocks")
  Check("ResumePreservesPosteriorAndImputationSummaries", identical(First[Fields], Second[Fields]))
  Check("ResumePreservesImmutableCheckpoints", identical(Hashes, vapply(Files, FileHash, character(1))))
  Check("FlaggedFiniteFitRetained", !First$Converged && nrow(First$ParameterSummary) == 31 &&
    nrow(First$Pooled) == 9 && all(is.finite(First$Pooled$Estimate)))
  Changed <- Jobs[[2]]$Streams
  Changed$Posterior[[1]] <- parallel::nextRNGStream(Changed$Posterior[[1]])
  Rejected <- tryCatch({
    FitSimulationTrial(Trial$Data, Path, "ResumeCheck", Plan, Small, Changed, Root)
    FALSE
  }, error = function(Error) grepl("checkpoint belongs", conditionMessage(Error), fixed = TRUE))
  Check("ChangedCheckpointSpecificationRejected", Rejected)
  Example <- data.frame(Scenario = "M1", Rule = "Continuation", Estimate = c(1, 2, NA),
    TotalVariance = c(1, 1, NA), Lower = c(-1, 0, NA), Upper = c(3, 4, NA), Truth = 1)
  Summary <- PerformanceSummary(Example, c("Scenario", "Rule"), c(M1 = 4))
  Check("FailureDenominatorPreserved", Summary$Attempted == 4 && Summary$Finite == 2 &&
    Summary$Unavailable == 2 && Summary$Coverage == 1 &&
    Summary$CoverageLowerIncludingFailures == .5 && Summary$CoverageUpperIncludingFailures == 1)
  Check("BiasAndMonteCarloError", abs(Summary$Bias - .5) < 1e-12 && abs(Summary$BiasMcse - .5) < 1e-12)
  Check("AllMonitoredParametersHaveTruth", length(ParameterTargets(Plan)) == 31 &&
    setequal(names(ParameterTargets(Plan)), First$ParameterSummary$Parameter))
  Table <- do.call(rbind, Results)
  SaveTable(Table, file.path(SimulationResultsPath(Path), "ExecutionChecks.csv"))
  saveRDS(Table, file.path(SimulationResultsPath(Path), "ExecutionChecks.rds"))
  message(nrow(Table), " execution checks passed.")
  invisible(Table)
}
