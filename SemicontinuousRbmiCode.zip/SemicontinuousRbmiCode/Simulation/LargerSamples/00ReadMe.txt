FINAL MANUSCRIPT SIMULATION

Scenario   Participants   Missing at final visit   Datasets
C1         200            0%                       300
M1         200            40%                      300
M2         300            40%                      300
M3         200            55%                      300

Every dataset has balanced randomized arms, three postbaseline visits, and
one standard normal baseline covariate. Missingness percentages are population
targets. The cumulative targets are 10%, 25%, and 40% for M1/M2, and 15%,
35%, and 55% for M3. The full design is in 02ScenarioPlan.json.

Reference zero probability at baseline zero is 0.15; positive means are 1.4,
1.2, and 1.1. The treatment odds ratio for zero is 1.5; the ratio of means
among positive responses is 0.9. Generating shapes are 1.3 and latent AR(1)
correlation is 0.8. Fitted shapes vary by visit and are shared across arms.
All normal priors have mean zero and SD 5; correlation is Uniform(-1, 1).
Nine rules cross weights 0, 0.5, and 1 for the two marginal components.

RUN FROM THE PACKAGE ROOT
  source("Simulation/LargerSamples/01RunOvernight.R")
  source("Simulation/LargerSamples/02RefreshReport.R")
  source("Simulation/LargerSamples/03ExportTables.R")

The first launcher defaults to 300 datasets per scenario and eight dataset
workers. Set Workers to at most min(8, max(1, floor(0.7 * available logical
cores))). Four chains run sequentially within each worker; computational
libraries use one thread per worker. No external data are needed.

Fresh preparation calibrates missingness, calculates population targets,
runs numerical and execution checks, and creates the study manifest.
The master seed is 720261101. Generation, sampling, and imputation have
separate random streams. Compatible completed datasets are reused; unfinished
chains resume from saved blocks. Do not run two copies concurrently.
After interruption, verify that the associated R workers have stopped before
removing a stale Results/RunLock directory.

SEPARATE VALIDATION AND COMMISSIONING
Validation without the formal study:
  Rscript --vanilla Simulation/LargerSamples/00RunSimulation.R --stage=Validate

A fresh commissioning run (preparation still calculates population targets):
  Rscript --vanilla Simulation/LargerSamples/00RunSimulation.R --stage=Prepare
  Rscript --vanilla Simulation/LargerSamples/00RunSimulation.R --stage=Run --workers=2 --limit=4 --replicates=300

Use --workers=1 if two workers exceed the machine's limit. The limit bounds
the number of pending jobs, not the number per scenario. Later run
01RunOvernight.R to finish the remaining jobs. Reports and manuscript tables
should be generated after the chosen target is complete.

SAMPLING AND INFERENCE
Four chains begin with 8000 adaptive iterations and then use blocks of 4000.
R-hat screening uses 1.05; cumulative bulk and tail ESS must be at least 400.
The first passing block and all later draws contribute. Five blocks per stage
are allowed. Monte Carlo precision targets for pooled estimates and variances
are 5%. Finite flagged fits remain in summaries; failures are reported.

The analysis after imputation regresses the final response on treatment,
centered baseline, and their interaction. HC3 variance plus empirical
standardization uncertainty enters Rubin pooling. Parameter recovery reports
14 model coordinates. See the manuscript and JSON plan for the estimands
under each completion assumption.

OUTPUTS
Results/ contains the manifest, calibration, population targets, progress,
summary CSVs, and StudyReport.html. Results/Formal contains saved datasets
and checkpoints. Results/Tables contains three LaTeX tables, numerical macros,
and matching CSVs. The exporter uses only local files and requires no
Overleaf checkout or LaTeX installation.

KEEP THE FOLDER STRUCTURE
Validation uses ../../Application/src relative to this study folder.
R/, src/, replay/, SourceProvenance.json, and the numbered files must remain
together. Migration and Extension modules support checkpoint compatibility;
they are loaded utilities, not extra stages of the manuscript analysis.

This source distribution contains no saved study results. Fresh preparation
creates its own manifest from the supplied plan and source hashes.
