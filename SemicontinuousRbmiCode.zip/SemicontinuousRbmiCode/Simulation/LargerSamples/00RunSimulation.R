# Run from Rscript --vanilla or source this file to validate without launching the study.
# Order: --stage=Prepare, --stage=Run, --stage=Report.
# Run resumes existing immutable checkpoints; --limit=8 bounds a commissioning run.
local({
  SourceFiles <- unlist(lapply(sys.frames(), function(Frame) Frame[["ofile"]]))
  Argument <- grep("^--file=", commandArgs(), value = TRUE)
  Path <- if (length(SourceFiles)) dirname(normalizePath(tail(SourceFiles, 1))) else
    if (length(Argument)) dirname(normalizePath(sub("^--file=", "", Argument[1]))) else "Simulation/LargerSamples"
  Path <- normalizePath(Path, winslash = "/")
  Arguments <- commandArgs(trailingOnly = TRUE)
  GetArgument <- function(Name, Default) {
    Value <- grep(paste0("^--", Name, "="), Arguments, value = TRUE)
    if (length(Value)) sub(paste0("^--", Name, "="), "", Value[1]) else Default
  }
  Stage <- GetArgument("stage", "Validate")
  source(file.path(Path, "R", "Load.R"), local = .GlobalEnv)
  LoadSimulation(Path, Compile = Stage %in% c("Prepare", "Validate", "Run"))
  Plan <- ReadSimulationPlan(Path)
  Settings <- SimulationSettings(Plan)
  Assert(Stage %in% c("Prepare", "Validate", "Run", "Report"), "Unknown simulation stage.")
  if (Stage == "Prepare") PrepareStudy(Path, Plan, Settings)
  if (Stage == "Validate") {
    ValidateSimulation(Path, Plan, Settings)
    ValidateExecution(Path, Plan, Settings)
  }
  if (Stage == "Run") RunFormalStudy(Path, Plan, Settings,
    Workers = as.numeric(GetArgument("workers", "8")), Limit = as.numeric(GetArgument("limit", "Inf")),
    Replicates = as.numeric(GetArgument("replicates", "300")))
  if (Stage == "Report") ReportStudy(Path, Plan)
})
