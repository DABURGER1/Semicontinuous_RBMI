# Final manuscript simulation: 300 trials per scenario, with n = 200 or 300.
# Source in RStudio or run through Rscript --vanilla.
# Completed trials are reused; unfinished trials resume from saved chain blocks.
local({
  Replicates <- 300
  Workers <- 8
  SourceFiles <- unlist(lapply(sys.frames(), function(Frame) Frame[["ofile"]]))
  Argument <- grep("^--file=", commandArgs(), value = TRUE)
  Path <- if (length(SourceFiles)) dirname(normalizePath(tail(SourceFiles, 1))) else
    if (length(Argument)) dirname(normalizePath(sub("^--file=", "", Argument[1]))) else
      if (file.exists("Simulation/LargerSamples/R/Load.R")) "Simulation/LargerSamples" else
      if (file.exists("LargerSamples/R/Load.R")) "LargerSamples" else "."
  Path <- normalizePath(Path, winslash = "/")
  if (!file.exists(file.path(Path, "R", "Load.R"))) stop("Source this file from the project, Simulation or LargerSamples folder.")
  source(file.path(Path, "R", "Load.R"), local = .GlobalEnv)
  LoadSimulation(Path)
  if (dir.exists(file.path(SimulationResultsPath(Path), "RunLock"))) stop("A study run is active or its run lock needs checking.")
  Plan <- ReadSimulationPlan(Path)
  Settings <- SimulationSettings(Plan)
  ManifestFile <- file.path(SimulationResultsPath(Path), "StudyManifest.rds")
  if (!file.exists(ManifestFile)) {
    LoadSimulation(Path, Compile = TRUE)
    PrepareStudy(Path, Plan, Settings)
  }
  Manifest <- readRDS(ManifestFile)
  VerifyStudy(Path, Plan, Manifest, ReportOnly = TRUE)
  ValidateReplicationTarget(Manifest, Replicates)
  VerifyInheritedResults(Path, Manifest)
  Jobs <- Filter(function(Job) Job$Replicate <= Replicates, Manifest$Jobs)
  Completed <- vapply(Jobs, function(Job) {
    Marker <- file.path(SimulationResultsPath(Path), "Formal", Job$Label, "Complete.rds")
    if (!file.exists(Marker)) return(FALSE)
    Result <- readRDS(Marker)
    Assert(identical(Result$StudyKey, Manifest$Key) && identical(Result$Label, Job$Label),
      "A completed trial does not match the frozen study.")
    TRUE
  }, logical(1))
  Scenario <- vapply(Jobs, function(Job) Job$Scenario, character(1))
  Progress <- do.call(rbind, lapply(unique(Scenario), function(Id) {
    Selected <- Scenario == Id
    data.frame(Scenario = Id, Target = sum(Selected), Completed = sum(Completed[Selected]),
      Pending = sum(!Completed[Selected]))
  }))
  message("Completed trials will be reused; only pending trials will run.")
  print(Progress, row.names = FALSE)
  if (any(!Completed)) {
    VerifyStudy(Path, Plan, Manifest)
    LoadSimulation(Path, Compile = TRUE)
    RunFormalStudy(Path, Plan, Settings, Workers = Workers, Replicates = Replicates)
  } else ReportStudy(Path, Plan, Replicates = Replicates)
  message("The larger-sample study is complete. Source LargerSamples/03ExportTables.R to stage its tables for manuscript review.")
})
