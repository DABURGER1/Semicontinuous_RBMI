// Conditional gamma-copula completion and final-visit analysis.
// Visit-specific shapes are shared across arms. Each parameter row retains its matching
// observed-zero auxiliaries. Missing Gaussian draws are shared across rules.
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::plugins(cpp17)]]
#include <RcppArmadillo.h>
#include <map>
#include <vector>
#include <cmath>

namespace {
  double Softplus(double Value) {
    return Value > 0 ? Value + std::log1p(std::exp(-Value)) : std::log1p(std::exp(Value));
  }

  double LogSum(double First, double Second) {
    double Maximum = std::max(First, Second);
    return Maximum + std::log1p(std::exp(std::min(First, Second) - Maximum));
  }

  double PositiveScore(double Value, double ZeroPredictor, double PositivePredictor, double Shape) {
    double LogZero = -Softplus(-ZeroPredictor);
    double LogPositive = -Softplus(ZeroPredictor);
    double Scale = std::exp(PositivePredictor)/Shape;
    if (!std::isfinite(Scale) || Scale <= 0) Rcpp::stop("Invalid positive scale during imputation.");
    double LogCdf = LogSum(LogZero, LogPositive + R::pgamma(Value, Shape, Scale, true, true));
    double LogSurvival = LogPositive + R::pgamma(Value, Shape, Scale, false, true);
    double Score = LogCdf < -std::log(2.) ? R::qnorm(LogCdf, 0, 1, true, true) :
      R::qnorm(LogSurvival, 0, 1, false, true);
    if (!std::isfinite(Score)) Rcpp::stop("A retained positive outcome has a nonfinite latent score.");
    return Score;
  }

  double MixtureQuantile(double Score, double ZeroPredictor, double PositivePredictor, double Shape) {
    double LogZero = -Softplus(-ZeroPredictor);
    double Threshold = R::qnorm(LogZero, 0, 1, true, true);
    if (Score <= Threshold) return 0;
    double LogPositive = -Softplus(ZeroPredictor);
    double LogU = R::pnorm(Score, 0, 1, true, true);
    double LogSurvival = R::pnorm(Score, 0, 1, false, true) - LogPositive;
    // Use a log difference near the zero threshold and a survival probability
    // in the upper tail. Do not clip probabilities or convert underflow to zeros.
    double LogCdf = LogU + std::log(-std::expm1(LogZero - LogU)) - LogPositive;
    bool Lower = LogCdf < -std::log(2.);
    double Probability = Lower ? LogCdf : LogSurvival;
    double Scale = std::exp(PositivePredictor)/Shape;
    if (!std::isfinite(Shape) || Shape <= 0 || !std::isfinite(Scale) || Scale <= 0 ||
      !std::isfinite(Probability) || Probability >= 0) {
      Rcpp::stop("A positive gamma completion is outside the numerical range.");
    }
    double Value = R::qgamma(Probability, Shape, Scale, Lower, true);
    if (!std::isfinite(Value) || Value <= 0) {
      Rcpp::stop("A positive gamma completion is outside the numerical range.");
    }
    // A finite positive quantile can still be inaccurate near underflow.
    // Check the same log tail used for inversion; never clip or redraw.
    double Recovered = R::pgamma(Value, Shape, Scale, Lower, true);
    if (!std::isfinite(Recovered) ||
      std::abs(Recovered - Probability) > 1e-8*(1 + std::abs(Probability))) {
      Rcpp::stop("A positive gamma completion cannot be represented accurately.");
    }
    return Value;
  }

  struct Pattern {
    arma::uvec Observed, Missing;
    arma::mat Regression, Cholesky;
  };
}

// [[Rcpp::export]]
Rcpp::List CompleteSimulationCpp(const arma::mat& Outcome, const arma::mat& Design,
  const arma::vec& Weeks, double UnitScale, const arma::mat& Draws,
  const arma::mat& LogVZeros, const arma::imat& ZeroIndex, const arma::umat& Eligible,
  const arma::umat& Borrow, const arma::mat& Rules, const arma::mat& AnalysisDesign,
  const arma::mat& Projection, const arma::vec& Leverage, int ExampleCount = 1) {
  int SubjectCount = Outcome.n_rows, VisitCount = Outcome.n_cols;
  int DrawCount = Draws.n_rows, RuleCount = Rules.n_rows;
  if ((VisitCount < 2 || VisitCount > 15) || Design.n_rows != Outcome.n_rows || Design.n_cols != 2 ||
    Weeks.n_elem != (unsigned) VisitCount || Draws.n_cols != (unsigned) (3*VisitCount + 5) || DrawCount < 1 || Rules.n_cols != 2 ||
    RuleCount < 1 || Eligible.n_rows != Outcome.n_rows || Eligible.n_cols != (unsigned) VisitCount ||
    Borrow.n_rows != Outcome.n_rows || Borrow.n_cols != (unsigned) VisitCount ||
    AnalysisDesign.n_rows != Outcome.n_rows || AnalysisDesign.n_cols != 4 ||
    Projection.n_rows != 4 || Projection.n_cols != Outcome.n_rows ||
    Leverage.n_elem != Outcome.n_rows || LogVZeros.n_rows != Draws.n_rows ||
    ZeroIndex.n_cols != 2 || LogVZeros.n_cols != ZeroIndex.n_rows) {
    Rcpp::stop("RBMI input dimensions are inconsistent.");
  }
  if (!Design.is_finite() || !Draws.is_finite() || !Rules.is_finite() ||
    !Weeks.is_finite() || arma::any(arma::diff(Weeks) <= 0) ||
    !AnalysisDesign.is_finite() || !Projection.is_finite() || !Leverage.is_finite() ||
    !std::isfinite(UnitScale) || UnitScale <= 0 || ExampleCount < 0 || ExampleCount > DrawCount ||
    arma::any(arma::vectorise(Rules) < 0) || arma::any(arma::vectorise(Rules) > 1) ||
    arma::any(Leverage >= 1) || arma::any(arma::vectorise(Eligible) > 1) ||
    arma::any(arma::vectorise(Borrow) > 1)) Rcpp::stop("Invalid RBMI inputs.");
  arma::uvec Reference = arma::find(Design.col(0) == 0), Active = arma::find(Design.col(0) == 1);
  if (Reference.n_elem < 2 || Active.n_elem < 2 || Reference.n_elem + Active.n_elem != Outcome.n_rows) {
    Rcpp::stop("Both treatment arms must be represented.");
  }
  double BaselineTolerance = 1e-10*std::max(1., arma::abs(AnalysisDesign.col(2)).max());
  if (SubjectCount <= 4 || arma::abs(AnalysisDesign.col(0) - 1).max() > 1e-12 ||
    arma::abs(AnalysisDesign.col(1) - Design.col(0)).max() > 1e-12 ||
    std::abs(arma::mean(AnalysisDesign.col(2))) > BaselineTolerance ||
    arma::abs(AnalysisDesign.col(3) - Design.col(0)%AnalysisDesign.col(2)).max() > BaselineTolerance) {
    Rcpp::stop("Use the centered baseline and treatment interaction analysis design.");
  }
  // The population target includes sampling variation in the empirical baseline mean.
  double StandardizationFactor = arma::dot(AnalysisDesign.col(2), AnalysisDesign.col(2))/
    (static_cast<double>(SubjectCount)*(SubjectCount - 1));
  if (!std::isfinite(StandardizationFactor)) Rcpp::stop("The baseline variance exceeds the numerical range.");
  arma::imat ZeroLookup(SubjectCount, VisitCount);
  ZeroLookup.fill(-1);
  for (arma::uword Index = 0; Index < ZeroIndex.n_rows; ++Index) {
    int Subject = ZeroIndex(Index, 0) - 1, Visit = ZeroIndex(Index, 1) - 1;
    if (Subject < 0 || Subject >= SubjectCount || Visit < 0 || Visit >= VisitCount ||
      Outcome(Subject, Visit) != 0 || ZeroLookup(Subject, Visit) >= 0) {
      Rcpp::stop("Observed-zero indices do not match the fitted outcomes.");
    }
    ZeroLookup(Subject, Visit) = Index;
  }
  if (!LogVZeros.is_finite() || arma::any(arma::vectorise(LogVZeros) >= 0)) {
    Rcpp::stop("Observed-zero auxiliaries must be finite negative log probabilities.");
  }
  std::vector<Pattern> Patterns;
  std::vector<int> SubjectPattern;
  std::map<unsigned, int> Lookup;
  for (int Subject = 0; Subject < SubjectCount; ++Subject) {
    unsigned Key = 0;
    std::vector<unsigned> Observed, Missing;
    for (int Visit = 0; Visit < VisitCount; ++Visit) {
      double Value = Outcome(Subject, Visit);
      if (std::isnan(Value)) {
        if (Eligible(Subject, Visit)) {
          Missing.push_back(Visit);
          Key |= 1u << (Visit + VisitCount);
        } else if (Borrow(Subject, Visit)) Rcpp::stop("Borrowing requires an eligible missing outcome.");
      } else {
        if (!std::isfinite(Value) || Value < 0 || !Eligible(Subject, Visit) || Borrow(Subject, Visit)) {
          Rcpp::stop("Invalid retained outcome or borrowing mask.");
        }
        if (Value == 0 && ZeroLookup(Subject, Visit) < 0) Rcpp::stop("An observed zero has no auxiliary draw.");
        Observed.push_back(Visit);
        Key |= 1u << Visit;
      }
    }
    if (!Eligible(Subject, VisitCount - 1)) Rcpp::stop("The final-visit analysis requires a defined outcome for every included participant.");
    if (!Lookup.count(Key)) {
      Pattern Item;
      Item.Observed = arma::uvec(Observed);
      Item.Missing = arma::uvec(Missing);
      Lookup[Key] = Patterns.size();
      Patterns.push_back(Item);
    }
    SubjectPattern.push_back(Lookup[Key]);
  }
  arma::cube Statistics(DrawCount, RuleCount, 7, arma::fill::zeros);
  arma::mat CoefficientVariance(DrawCount, RuleCount), StandardizationVariance(DrawCount, RuleCount);
  arma::cube Examples(SubjectCount, VisitCount, ExampleCount*RuleCount);
  arma::vec VarianceWeights = Projection.row(1).t()/(1 - Leverage);
  for (int Draw = 0; Draw < DrawCount; ++Draw) {
    if (Draw % 100 == 0) Rcpp::checkUserInterrupt();
    arma::rowvec Theta = Draws.row(Draw);
    arma::vec Shapes(VisitCount);
    for (int Visit = 0; Visit < VisitCount; ++Visit) {
      double DispersionSquared = std::exp(2*Theta[2*VisitCount + 4 + Visit]);
      double LogShape = DispersionSquared > std::log(2.) ?
        -DispersionSquared - std::log1p(-std::exp(-DispersionSquared)) : -std::log(std::expm1(DispersionSquared));
      Shapes[Visit] = std::exp(LogShape);
      if (!std::isfinite(Shapes[Visit]) || Shapes[Visit] <= 0) {
        Rcpp::stop("Invalid visit-specific shape in a retained draw.");
      }
    }
    double AdjacentCorrelation = std::tanh(Theta[3*VisitCount + 4]/2.);
    if (!std::isfinite(AdjacentCorrelation) || AdjacentCorrelation <= -1 || AdjacentCorrelation >= 1) {
      Rcpp::stop("Invalid correlation in a retained draw.");
    }
    arma::mat Correlation(VisitCount, VisitCount);
    for (int Row = 0; Row < VisitCount; ++Row) for (int Column = 0; Column < VisitCount; ++Column) {
      Correlation(Row, Column) = (Row == Column ? 1. : std::pow(AdjacentCorrelation, std::abs(Row - Column)));
    }
    for (auto& Item : Patterns) {
      if (Item.Missing.n_elem == 0) continue;
      arma::mat Variance = Correlation.submat(Item.Missing, Item.Missing);
      if (Item.Observed.n_elem) {
        arma::mat Solved;
        if (!arma::solve(Solved, Correlation.submat(Item.Observed, Item.Observed),
          Correlation.submat(Item.Observed, Item.Missing), arma::solve_opts::likely_sympd)) {
          Rcpp::stop("Could not condition on the retained outcomes.");
        }
        Item.Regression = Solved.t();
        Variance -= Item.Regression*Correlation.submat(Item.Observed, Item.Missing);
      }
      Variance = (Variance + Variance.t())/2;
      if (!arma::chol(Item.Cholesky, Variance, "lower")) {
        Rcpp::stop("The conditional covariance is not numerically positive definite.");
      }
    }
    arma::mat Scores(SubjectCount, VisitCount, arma::fill::zeros);
    for (int Subject = 0; Subject < SubjectCount; ++Subject) {
      const Pattern& Item = Patterns[SubjectPattern[Subject]];
      arma::vec ObservedScores(Item.Observed.n_elem);
      for (arma::uword Index = 0; Index < Item.Observed.n_elem; ++Index) {
        int Visit = Item.Observed[Index];
        double ZeroPredictor = Theta[Visit] + Theta[VisitCount]*Design(Subject, 0) + Theta[VisitCount + 1]*Design(Subject, 1);
        double PositivePredictor = Theta[VisitCount + 2 + Visit] + Theta[2*VisitCount + 2]*Design(Subject, 0) + Theta[2*VisitCount + 3]*Design(Subject, 1);
        ObservedScores[Index] = Outcome(Subject, Visit) == 0 ?
          R::qnorm(-Softplus(-ZeroPredictor) + LogVZeros(Draw, ZeroLookup(Subject, Visit)), 0, 1, true, true) :
          PositiveScore(Outcome(Subject, Visit)/UnitScale, ZeroPredictor, PositivePredictor, Shapes[Visit]);
      }
      if (!ObservedScores.is_finite()) Rcpp::stop("A retained zero has a nonfinite latent score.");
      if (Item.Missing.n_elem) {
        arma::vec Innovation(Item.Missing.n_elem);
        for (arma::uword Index = 0; Index < Innovation.n_elem; ++Index) Innovation[Index] = R::rnorm(0, 1);
        arma::vec MissingScores = Item.Cholesky*Innovation;
        if (Item.Observed.n_elem) MissingScores += Item.Regression*ObservedScores;
        for (arma::uword Index = 0; Index < Item.Missing.n_elem; ++Index) {
          Scores(Subject, Item.Missing[Index]) = MissingScores[Index];
        }
      }
    }
    for (int Rule = 0; Rule < RuleCount; ++Rule) {
      arma::mat Completed = Outcome;
      for (int Subject = 0; Subject < SubjectCount; ++Subject) {
        const Pattern& Item = Patterns[SubjectPattern[Subject]];
        for (arma::uword Index = 0; Index < Item.Missing.n_elem; ++Index) {
          int Visit = Item.Missing[Index];
          double ZeroPredictor = Theta[Visit] + (1 - Rules(Rule, 0)*Borrow(Subject, Visit))*Theta[VisitCount]*
            Design(Subject, 0) + Theta[VisitCount + 1]*Design(Subject, 1);
          double PositivePredictor = Theta[VisitCount + 2 + Visit] + (1 - Rules(Rule, 1)*Borrow(Subject, Visit))*Theta[2*VisitCount + 2]*
            Design(Subject, 0) + Theta[2*VisitCount + 3]*Design(Subject, 1);
          Completed(Subject, Visit) = UnitScale*MixtureQuantile(Scores(Subject, Visit), ZeroPredictor, PositivePredictor, Shapes[Visit]);
          if (!std::isfinite(Completed(Subject, Visit))) Rcpp::stop("A completed amount exceeds the numerical range.");
        }
      }
      arma::vec Final = Completed.col(VisitCount - 1), Coefficients = Projection*Final;
      arma::vec Residual = Final - AnalysisDesign*Coefficients;
      arma::vec Weighted = VarianceWeights%Residual;
      double ReferenceMean = arma::mean(Final.elem(Reference)), ActiveMean = arma::mean(Final.elem(Active));
      Statistics(Draw, Rule, 0) = Coefficients[1];
      CoefficientVariance(Draw, Rule) = arma::dot(Weighted, Weighted);
      StandardizationVariance(Draw, Rule) = Coefficients[3]*Coefficients[3]*StandardizationFactor;
      Statistics(Draw, Rule, 1) = CoefficientVariance(Draw, Rule) + StandardizationVariance(Draw, Rule);
      Statistics(Draw, Rule, 2) = ActiveMean - ReferenceMean;
      Statistics(Draw, Rule, 3) = ReferenceMean;
      Statistics(Draw, Rule, 4) = ActiveMean;
      Statistics(Draw, Rule, 5) = arma::mean(arma::conv_to<arma::vec>::from(Final.elem(Reference) == 0));
      Statistics(Draw, Rule, 6) = arma::mean(arma::conv_to<arma::vec>::from(Final.elem(Active) == 0));
      if (Draw < ExampleCount) Examples.slice(Draw*RuleCount + Rule) = Completed;
    }
  }
  if (!Statistics.is_finite()) Rcpp::stop("A completed-data estimate or variance is nonfinite.");
  return Rcpp::List::create(Rcpp::Named("Statistics") = Statistics, Rcpp::Named("Examples") = Examples,
    Rcpp::Named("CoefficientVariance") = CoefficientVariance,
    Rcpp::Named("StandardizationVariance") = StandardizationVariance);
}
