// Gamma semicontinuous Gaussian copula.
// A continuation restores parameters, zero auxiliaries and frozen proposal
// factors. R restores the random-number state before requesting the next block.
// The augmented likelihood is defined with respect to v, not log(v).
// log(v) is stored only for numerical stability; exact zero Gibbs updates
// transform a truncated Gaussian draw back to v. Missing values are integrated out.
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::plugins(cpp17)]]
#include <RcppArmadillo.h>
#include <vector>
#include <map>
#include <cmath>
using namespace Rcpp;

namespace {
  double Softplus(double Value) {
    return Value > 0 ? Value + std::log1p(std::exp(-Value)) : std::log1p(std::exp(Value));
  }
  double LogUniform() {
    double Uniform = R::runif(0, 1);
    while (Uniform <= 0) Uniform = R::runif(0, 1);
    return std::log(Uniform);
  }
  struct Pattern {
    arma::uvec Visits;
    arma::mat Precision;
    double LogDeterminant = 0;
  };
  struct Model {
    arma::mat Outcome, Design;
    arma::vec VisitTimes;
    int SubjectCount, VisitCount;
    std::vector<Pattern> Patterns;
    std::vector<bool> HasPositive;
    std::vector<int> SubjectPattern, ZeroSubject, ZeroVisit;
    Model(const arma::mat& InputOutcome, const arma::mat& InputDesign,
      const arma::vec& InputTimes) : Outcome(InputOutcome), Design(InputDesign), VisitTimes(InputTimes) {
      SubjectCount = Outcome.n_rows;
      VisitCount = Outcome.n_cols;
      if ((VisitCount < 2 || VisitCount > 15) || Design.n_rows != Outcome.n_rows || Design.n_cols != 2 ||
        VisitTimes.n_elem != (unsigned) VisitCount) stop("Supply two to fifteen visits and two covariates.");
      if (!Design.is_finite() || !VisitTimes.is_finite()) stop("Nonfinite design or times.");
      if (arma::any(arma::diff(VisitTimes) <= 0)) stop("Visit times must increase.");
      HasPositive.assign(VisitCount, false);
      std::map<unsigned, int> PatternLookup;
      for (int Subject = 0; Subject < SubjectCount; ++Subject) {
        unsigned Mask = 0;
        std::vector<unsigned> Indices;
        for (int Index = 0; Index < VisitCount; ++Index) {
          if (std::isnan(Outcome(Subject, Index))) continue;
          if (!std::isfinite(Outcome(Subject, Index)) || Outcome(Subject,
            Index) < 0) stop("Outcome must be nonnegative or missing.");
          Mask |= 1u << Index;
          Indices.push_back(Index);
          if (Outcome(Subject, Index) == 0) {
            ZeroSubject.push_back(Subject);
            ZeroVisit.push_back(Index);
          } else HasPositive[Index] = true;
        }
        if (!PatternLookup.count(Mask)) {
          Pattern PatternValue;
          PatternValue.Visits = arma::uvec(Indices);
          PatternLookup[Mask] = Patterns.size();
          Patterns.push_back(PatternValue);
        }
        SubjectPattern.push_back(PatternLookup[Mask]);
      }
    }
    bool UpdateGeometry(double ScaledLogitCorrelation) {
      double Correlation = std::tanh(ScaledLogitCorrelation/2.);
      if (!std::isfinite(Correlation) || Correlation <= -1 || Correlation >= 1) return false;
      arma::mat CorrelationMatrix(VisitCount, VisitCount);
      for (int Row = 0; Row < VisitCount; ++Row) for (int Column =
        0; Column < VisitCount; ++Column) CorrelationMatrix(Row, Column) =
        (Row == Column ? 1. : std::pow(Correlation, std::abs(Row - Column)));
      for (auto& PatternValue : Patterns) {
        unsigned Dimension = PatternValue.Visits.n_elem;
        if (Dimension == 0) {
          PatternValue.Precision.set_size(0, 0);
          PatternValue.LogDeterminant = 0;
          continue;
        }
        arma::mat Submatrix = CorrelationMatrix.submat(PatternValue.Visits, PatternValue.Visits), Cholesky;
        if (!arma::chol(Cholesky, Submatrix, "lower")) return false;
        if (!arma::inv_sympd(PatternValue.Precision, Submatrix)) return false;
        PatternValue.LogDeterminant = 2*arma::sum(arma::log(Cholesky.diag()));
      }
      return true;
    }
  };
  struct State {
    arma::mat Scores, LogZeroProbability;
    arma::vec BySubject;
    double Marginal = 0, Copula = 0, Prior = 0, Target = -INFINITY;
    bool Valid = false;
  };
  double EvaluatePrior(const arma::vec& Theta, const arma::vec& Mean, const arma::vec& Sd, double RhoA,
    double RhoB) {
    double Result = 0;
    for (int Index = 0; Index < (int) Theta.n_elem - 1; ++Index) Result += R::dnorm(Theta[Index], Mean[Index], Sd[Index], true);
    // Q = (rho + 1)/2 has a Beta prior; zeta = logit(Q).
    // The scaled-beta factor 1/2 cancels the 2 in d rho/d zeta.
    return Result - RhoA*Softplus(-Theta[Theta.n_elem - 1]) - RhoB*Softplus(Theta[Theta.n_elem - 1]) - R::lbeta(RhoA, RhoB);
  }
  State EvaluateState(Model& ModelValue, const arma::vec& Theta, const arma::mat& LogV,
    const arma::vec& PriorMean, const arma::vec& PriorSd, double RhoA, double RhoB,
    bool RebuildGeometry = true) {
    State Current;
    if (Theta.n_elem != (unsigned) (3*ModelValue.VisitCount + 5) || !Theta.is_finite()) return Current;
    if (RebuildGeometry && !ModelValue.UpdateGeometry(Theta[Theta.n_elem - 1])) return Current;
    // Each visit has an independent log(d), where d=sqrt(log(1+CV^2)).
    // Gamma shape=1/expm1(d^2); its scale is the positive mean divided by shape.
    int Visits = ModelValue.VisitCount;
    arma::vec Shapes(Visits), LogShapes(Visits);
    for (int Visit = 0; Visit < Visits; ++Visit) {
      // With no observed positives, this shape is absent from the likelihood.
      // Keep its prior contribution without evaluating an unused transform.
      if (!ModelValue.HasPositive[Visit]) continue;
      double DispersionSquared = std::exp(2*Theta[2*Visits + 4 + Visit]);
      if (!std::isfinite(DispersionSquared) || DispersionSquared <= 0) return Current;
      LogShapes[Visit] = DispersionSquared > std::log(2.) ? -DispersionSquared -
        std::log1p(-std::exp(-DispersionSquared)) : -std::log(std::expm1(DispersionSquared));
      Shapes[Visit] = std::exp(LogShapes[Visit]);
      if (!std::isfinite(Shapes[Visit]) || Shapes[Visit] <= 0) return Current;
    }
    Current.Scores = arma::mat(ModelValue.SubjectCount, ModelValue.VisitCount, arma::fill::zeros);
    Current.LogZeroProbability = Current.Scores;
    Current.BySubject = arma::vec(ModelValue.SubjectCount, arma::fill::zeros);
    for (int Subject = 0; Subject < ModelValue.SubjectCount; ++Subject) {
      const Pattern& PatternValue = ModelValue.Patterns[ModelValue.SubjectPattern[Subject]];
      for (unsigned Position = 0; Position < PatternValue.Visits.n_elem; ++Position) {
        int Index = PatternValue.Visits[Position];
        double Outcome = ModelValue.Outcome(Subject, Index);
        double ZeroPredictor = Theta[Index] + Theta[Visits]*ModelValue.Design(Subject, 0) +
          Theta[Visits + 1]*ModelValue.Design(Subject, 1);
        double PositivePredictor = Theta[Visits + 2 + Index] + Theta[2*Visits + 2]*ModelValue.Design(Subject, 0) +
          Theta[2*Visits + 3]*ModelValue.Design(Subject, 1);
        double LogZero = -Softplus(-ZeroPredictor), LogPositive = -Softplus(ZeroPredictor);
        Current.LogZeroProbability(Subject, Index) = LogZero;
        double Scores, LogMarginal;
        if (Outcome == 0) {
          if (!std::isfinite(LogV(Subject, Index)) || LogV(Subject, Index) >= 0) return Current;
          Scores = R::qnorm(LogZero + LogV(Subject, Index), 0, 1, true, true);
          LogMarginal = LogZero;
        } else {
          double Shape = Shapes[Index], Scale = std::exp(PositivePredictor - LogShapes[Index]);
          if (!std::isfinite(Scale) || Scale <= 0) return Current;
          double LogPositiveCdf = LogPositive + R::pgamma(Outcome, Shape, Scale, true, true);
          double MaxLog = std::max(LogZero, LogPositiveCdf);
          double LogCdf = MaxLog + std::log1p(std::exp(std::min(LogZero, LogPositiveCdf) - MaxLog));
          double LogSurvival = LogPositive + R::pgamma(Outcome, Shape, Scale, false, true);
          Scores = LogCdf < -0.6931471805599453 ? R::qnorm(LogCdf, 0, 1, true,
            true) : R::qnorm(LogSurvival, 0, 1, false, true);
          LogMarginal = LogPositive + R::dgamma(Outcome, Shape, Scale, true);
        }
        if (!std::isfinite(Scores) || !std::isfinite(LogMarginal)) return Current;
        Current.Scores(Subject, Index) = Scores;
        Current.Marginal += LogMarginal;
        Current.BySubject[Subject] += LogMarginal;
      }
      if (PatternValue.Visits.n_elem > 1) {
        arma::vec SubjectScores = Current.Scores.row(Subject).t();
        SubjectScores = SubjectScores.elem(PatternValue.Visits);
        double LogCopula = -.5*PatternValue.LogDeterminant -
          .5*(arma::as_scalar(SubjectScores.t()*PatternValue.Precision*SubjectScores) -
          arma::dot(SubjectScores, SubjectScores));
        Current.Copula += LogCopula;
        Current.BySubject[Subject] += LogCopula;
      }
    }
    Current.Prior = EvaluatePrior(Theta, PriorMean, PriorSd, RhoA, RhoB);
    Current.Target = Current.Marginal + Current.Copula + Current.Prior;
    Current.Valid = std::isfinite(Current.Target);
    return Current;
  }
  void UpdateZeros(Model& ModelValue, State& Current, arma::mat& LogV) {
    for (int Subject = 0; Subject < ModelValue.SubjectCount; ++Subject) {
      const Pattern& PatternValue = ModelValue.Patterns[ModelValue.SubjectPattern[Subject]];
      for (unsigned Position = 0; Position < PatternValue.Visits.n_elem; ++Position) {
        int Index = PatternValue.Visits[Position];
        if (ModelValue.Outcome(Subject, Index) != 0) continue;
        double ConditionalPrecision = PatternValue.Precision(Position, Position), ConditionalMean = 0,
          Sd = std::sqrt(1/ConditionalPrecision);
        for (unsigned OtherPosition =
          0; OtherPosition < PatternValue.Visits.n_elem; ++OtherPosition) if (OtherPosition !=
          Position) ConditionalMean -= PatternValue.Precision(Position,
          OtherPosition)*Current.Scores(Subject, PatternValue.Visits[OtherPosition])/ConditionalPrecision;
        double Upper = R::qnorm(Current.LogZeroProbability(Subject, Index), 0, 1, true, true);
        double LogBound = R::pnorm((Upper - ConditionalMean)/Sd, 0, 1, true, true);
        double Draw = ConditionalMean + Sd*R::qnorm(LogUniform() + LogBound, 0, 1, true, true);
        double LogAuxiliary = R::pnorm(Draw, 0, 1, true, true) - Current.LogZeroProbability(Subject, Index);
        // Equality can occur from floating-point rounding at a remote boundary.
        // Redraw in that exceptional case, rather than clipping a probability.
        int Attempts = 0;
        while ((!std::isfinite(LogAuxiliary) || LogAuxiliary >= 0) && ++Attempts < 100) {
          Draw = ConditionalMean + Sd*R::qnorm(LogUniform() + LogBound, 0, 1, true, true);
          LogAuxiliary = R::pnorm(Draw, 0, 1, true, true) - Current.LogZeroProbability(Subject, Index);
        }
        if (!std::isfinite(LogAuxiliary) || LogAuxiliary >=
          0) stop("Truncated-normal update failed numerically.");
        Current.Scores(Subject, Index) = Draw;
        LogV(Subject, Index) = LogAuxiliary;
      }
    }
  }
  struct Block {
    arma::uvec Indices;
    arma::mat Initial, Cholesky, M2;
    arma::vec Mean;
    double LogScale = 0;
    int Count = 0, WindowAccepted = 0, RetainedAccepted = 0;
    Block(arma::uvec Indices, const arma::mat& Covariance) : Indices(Indices), Initial(Covariance) {
      Mean = arma::vec(Indices.n_elem, arma::fill::zeros);
      M2 = arma::mat(Indices.n_elem, Indices.n_elem, arma::fill::zeros);
      if (!arma::chol(Cholesky, Initial, "lower")) stop("Initial proposal covariance is invalid.");
    }
    void UpdateMoments(const arma::vec& Theta) {
      ++Count;
      arma::vec Value = Theta.elem(Indices), Difference = Value - Mean;
      Mean += Difference/Count;
      M2 += Difference*(Value - Mean).t();
    }
    void Adapt(int AdaptationNumber, int AdaptEvery) {
      double Target = Indices.n_elem == 1 ? .44 : .234;
      double Gain = std::min(.5, 1/std::sqrt((double) AdaptationNumber));
      LogScale = std::max(-4., std::min(3., LogScale + 2*Gain*(WindowAccepted/(double) AdaptEvery - Target)));
      if (Count > 500) {
        arma::mat Covariance = .95*M2/(Count - 1) + .05*Initial;
        Covariance = .5*(Covariance + Covariance.t());
        arma::vec Eigenvalues;
        arma::mat Eigenvectors;
        if (arma::eig_sym(Eigenvalues, Eigenvectors, Covariance)) {
          Eigenvalues = arma::clamp(Eigenvalues, 1e-6, 4.);
          Covariance = Eigenvectors*arma::diagmat(Eigenvalues)*Eigenvectors.t();
          arma::mat Candidate;
          if (arma::chol(Candidate, Covariance, "lower")) Cholesky = Candidate;
        }
      }
      WindowAccepted = 0;
    }
  };
  void ValidatePrior(const arma::vec& Mean, const arma::vec& Sd, double RhoA, double RhoB, unsigned Dimension) {
    if (Mean.n_elem != Dimension || Sd.n_elem != Dimension || !Mean.is_finite() || !Sd.is_finite() || arma::any(Sd <=
      0) || !std::isfinite(RhoA) || !std::isfinite(RhoB) || RhoA <= 0 || RhoB <=
      0) stop("Invalid prior specification.");
  }
}

// [[Rcpp::export]]
List EvaluateSimulationCpp(const arma::vec& Theta, const arma::mat& Outcome, const arma::mat& Design,
  const arma::vec& VisitTimes, const arma::mat& LogV, const arma::vec& PriorMean,
  const arma::vec& PriorSd, double RhoA = 1, double RhoB = 1) {
  ValidatePrior(PriorMean, PriorSd, RhoA, RhoB, 3*Outcome.n_cols + 4);
  Model ModelValue(Outcome, Design, VisitTimes);
  if (LogV.n_rows != Outcome.n_rows || LogV.n_cols != Outcome.n_cols) stop("Invalid logv dimensions.");
  State Current = EvaluateState(ModelValue, Theta, LogV, PriorMean, PriorSd, RhoA, RhoB);
  return List::create(_["Valid"] = Current.Valid, _["LogAugmentedLikelihood"] = Current.Marginal +
    Current.Copula, _["LogPrior"] = Current.Prior, _["LogTarget"] = Current.Target, _["Scores"] =
    Current.Scores, _["LogBySubject"] = Current.BySubject);
}

// [[Rcpp::export]]
List RunSimulationChainCpp(const arma::mat& Outcome, const arma::mat& Design, const arma::vec& VisitTimes,
  arma::vec Theta, const arma::vec& PriorMean, const arma::vec& PriorSd, List ProposalCovariances,
  int WarmupDraws = 6000, int SampleDraws = 12000, int AdaptEvery = 50, int ZeroSweeps = 2, double RhoA =
  1, double RhoB = 1, Nullable<List> Continuation = R_NilValue) {
  RNGScope Scope;
  ValidatePrior(PriorMean, PriorSd, RhoA, RhoB, 3*Outcome.n_cols + 4);
  if (WarmupDraws < 0 || SampleDraws < 1 || AdaptEvery < 1 || ZeroSweeps < 1) stop("Invalid MCMC settings.");
  Model ModelValue(Outcome, Design, VisitTimes);
  if (ProposalCovariances.size() != 3) stop("Supply three proposal covariance matrices.");
  for (int Index = 0; Index < 3; ++Index) {
    arma::mat Proposal = as<arma::mat>(ProposalCovariances[Index]);
    unsigned Dimension = Index == 0 ? ModelValue.VisitCount + 2 : (Index == 1 ? 2*ModelValue.VisitCount + 2 : 1);
    if (Proposal.n_rows != Dimension || Proposal.n_cols != Dimension ||
      !Proposal.is_finite()) stop("Proposal covariance dimensions are invalid.");
  }
  arma::mat LogV(ModelValue.SubjectCount, ModelValue.VisitCount, arma::fill::zeros);
  if (Continuation.isNotNull()) {
    if (WarmupDraws != 0) stop("A continued chain must use zero adaptive warmup draws.");
    List Saved(Continuation);
    Theta = as<arma::vec>(Saved["Theta"]);
    LogV = as<arma::mat>(Saved["LogV"]);
    if (LogV.n_rows != Outcome.n_rows || LogV.n_cols !=
      Outcome.n_cols) stop("Continued zero variables do not match the data.");
  } else {
    for (unsigned ZeroIndex =
      0; ZeroIndex < ModelValue.ZeroSubject.size(); ++ZeroIndex) LogV(ModelValue.ZeroSubject[ZeroIndex],
      ModelValue.ZeroVisit[ZeroIndex]) = LogUniform();
  }
  State CurrentState = EvaluateState(ModelValue, Theta, LogV, PriorMean, PriorSd, RhoA, RhoB);
  if (!CurrentState.Valid) stop("Nonfinite initial state.");
  std::vector<Block> Blocks;
  Blocks.emplace_back(arma::regspace<arma::uvec>(0, ModelValue.VisitCount + 1), as<arma::mat>(ProposalCovariances[0]));
  Blocks.emplace_back(arma::regspace<arma::uvec>(ModelValue.VisitCount + 2, 3*ModelValue.VisitCount + 3), as<arma::mat>(ProposalCovariances[1]));
  Blocks.emplace_back(arma::uvec{(arma::uword) (3*ModelValue.VisitCount + 4)}, as<arma::mat>(ProposalCovariances[2]));
  if (Continuation.isNotNull()) {
    List Saved(Continuation);
    List SavedCholesky = Saved["Cholesky"];
    NumericVector SavedLogScales = Saved["LogScales"];
    if (SavedCholesky.size() != 3 || SavedLogScales.size() !=
      3) stop("Continued proposal settings are incomplete.");
    for (unsigned Index = 0; Index < Blocks.size(); ++Index) {
      arma::mat Factor = as<arma::mat>(SavedCholesky[Index]);
      unsigned Dimension = Blocks[Index].Indices.n_elem;
      if (Factor.n_rows != Dimension || Factor.n_cols != Dimension || !Factor.is_finite() ||
        arma::any(Factor.diag() <= 0) ||
        !std::isfinite(SavedLogScales[Index])) stop("Continued proposal settings are invalid.");
      Blocks[Index].Cholesky = Factor;
      Blocks[Index].LogScale = SavedLogScales[Index];
    }
  }
  arma::mat Draws(SampleDraws, 3*ModelValue.VisitCount + 5), ZeroDraws(SampleDraws, ModelValue.ZeroSubject.size());
  arma::vec LogAugmented(SampleDraws), LogPosterior(SampleDraws), WarmupLogPosterior(WarmupDraws);
  int InvalidProposals = 0;
  for (int Iteration = 1; Iteration <= WarmupDraws + SampleDraws; ++Iteration) {
    if (Iteration % 100 == 0) checkUserInterrupt();
    for (unsigned BlockIndex = 0; BlockIndex < Blocks.size(); ++BlockIndex) {
      Block& BlockValue = Blocks[BlockIndex];
      arma::vec Noise(BlockValue.Indices.n_elem);
      for (unsigned Index = 0; Index < Noise.n_elem; ++Index) Noise[Index] = R::rnorm(0, 1);
      arma::vec Candidate = Theta;
      double DimensionScale = BlockValue.Indices.n_elem ==
        1 ? 1. : 2.38/std::sqrt((double) BlockValue.Indices.n_elem);
      Candidate.elem(BlockValue.Indices) +=
        DimensionScale*std::exp(BlockValue.LogScale)*BlockValue.Cholesky*Noise;
      State ProposedState = EvaluateState(ModelValue, Candidate, LogV, PriorMean, PriorSd, RhoA, RhoB,
        BlockIndex == 2);
      if (!ProposedState.Valid) ++InvalidProposals;
      bool Accepted = ProposedState.Valid && LogUniform() < ProposedState.Target - CurrentState.Target;
      if (Accepted) {
        Theta = Candidate;
        CurrentState = std::move(ProposedState);
        ++BlockValue.WindowAccepted;
        if (Iteration > WarmupDraws) ++BlockValue.RetainedAccepted;
      } else if (BlockIndex == 2) {
        if (!ModelValue.UpdateGeometry(Theta[Theta.n_elem - 1])) stop("Unable to restore valid correlation.");
      }
      if (Iteration <= WarmupDraws) BlockValue.UpdateMoments(Theta);
    }
    for (int Sweep = 0; Sweep < ZeroSweeps; ++Sweep) UpdateZeros(ModelValue, CurrentState, LogV);
    CurrentState = EvaluateState(ModelValue, Theta, LogV, PriorMean, PriorSd, RhoA, RhoB, false);
    if (!CurrentState.Valid) stop("Invalid state after zero Gibbs update.");
    if (Iteration <= WarmupDraws) {
      WarmupLogPosterior[Iteration - 1] = CurrentState.Target;
      if (Iteration % AdaptEvery ==
        0) for (auto& BlockValue : Blocks) BlockValue.Adapt(Iteration/AdaptEvery, AdaptEvery);
    } else {
      int RowIndex = Iteration - WarmupDraws - 1;
      Draws.row(RowIndex) = Theta.t();
      LogAugmented[RowIndex] = CurrentState.Marginal + CurrentState.Copula;
      LogPosterior[RowIndex] = CurrentState.Target;
      for (unsigned ZeroIndex =
        0; ZeroIndex < ModelValue.ZeroSubject.size(); ++ZeroIndex) ZeroDraws(RowIndex, ZeroIndex) =
        LogV(ModelValue.ZeroSubject[ZeroIndex], ModelValue.ZeroVisit[ZeroIndex]);
    }
  }
  NumericVector Acceptance(3), Scales(3);
  List FinalCovariances(3);
  for (int Index = 0; Index < 3; ++Index) {
    Acceptance[Index] = Blocks[Index].RetainedAccepted/(double) SampleDraws;
    Scales[Index] = std::exp(Blocks[Index].LogScale);
    FinalCovariances[Index] = Blocks[Index].Cholesky*Blocks[Index].Cholesky.t();
  }
  IntegerMatrix ZeroIndices(ModelValue.ZeroSubject.size(), 2);
  for (unsigned ZeroIndex = 0; ZeroIndex < ModelValue.ZeroSubject.size(); ++ZeroIndex) {
    ZeroIndices(ZeroIndex, 0) = ModelValue.ZeroSubject[ZeroIndex] + 1;
    ZeroIndices(ZeroIndex, 1) = ModelValue.ZeroVisit[ZeroIndex] + 1;
  }
  List SavedCholesky(3);
  NumericVector SavedLogScales(3);
  for (int Index = 0; Index < 3; ++Index) {
    SavedCholesky[Index] = Blocks[Index].Cholesky;
    SavedLogScales[Index] = Blocks[Index].LogScale;
  }
  List ChainState = List::create(_["Theta"] = Theta, _["LogV"] = LogV, _["Cholesky"] = SavedCholesky,
    _["LogScales"] = SavedLogScales);
  return List::create(_["ChainState"] = ChainState, _["Draws"] = Draws, _["LogVZeros"] = ZeroDraws,
    _["ZeroIndex"] = ZeroIndices, _["LogAugmentedLikelihood"] = LogAugmented, _["LogPosterior"] =
    LogPosterior, _["WarmupLogPosterior"] = WarmupLogPosterior, _["Acceptance"] = Acceptance,
    _["ProposalScales"] = Scales, _["ProposalCovariances"] = FinalCovariances, _["InvalidProposals"] =
    InvalidProposals, _["LastTheta"] = Theta, _["LastLogV"] = LogV);
}
