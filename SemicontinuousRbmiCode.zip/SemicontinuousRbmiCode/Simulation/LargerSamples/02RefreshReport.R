# Open in RStudio and click Source to refresh summaries from completed trials.
# The target is read from the active results directory's CurrentRun.json.
local({
  SourceFiles <- unlist(lapply(sys.frames(), function(Frame) Frame[["ofile"]]))
  Argument <- grep("^--file=", commandArgs(), value = TRUE)
  Path <- if (length(SourceFiles)) dirname(normalizePath(tail(SourceFiles, 1))) else
    if (length(Argument)) dirname(normalizePath(sub("^--file=", "", Argument[1]))) else
      if (file.exists("Simulation/LargerSamples/R/Load.R")) "Simulation/LargerSamples" else
      if (file.exists("LargerSamples/R/Load.R")) "LargerSamples" else "."
  Path <- normalizePath(Path, winslash = "/")
  source(file.path(Path, "R", "Load.R"), local = .GlobalEnv)
  LoadSimulation(Path)
  if (dir.exists(file.path(SimulationResultsPath(Path), "RunLock"))) stop("Wait for the active study run before refreshing its report.")
  Plan <- ReadSimulationPlan(Path)
  Manifest <- readRDS(file.path(SimulationResultsPath(Path), "StudyManifest.rds"))
  VerifyStudy(Path, Plan, Manifest, ReportOnly = TRUE)
  ReportStudy(Path, Plan)
})
