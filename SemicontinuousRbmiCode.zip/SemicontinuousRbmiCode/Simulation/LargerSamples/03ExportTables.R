# Generate manuscript tables from the completed simulation summaries.
# Source this file after 02RefreshReport.R. It does not fit or impute any data.
# Generated LaTeX and CSV files are saved in Results/Tables.
local({
  SourceFiles <- unlist(lapply(sys.frames(), function(Frame) Frame[["ofile"]]))
  Argument <- grep("^--file=", commandArgs(), value = TRUE)
  Path <- if (length(SourceFiles)) dirname(normalizePath(tail(SourceFiles, 1))) else
    if (length(Argument)) dirname(normalizePath(sub("^--file=", "", Argument[1]))) else
      if (file.exists("Simulation/LargerSamples/R/Load.R")) "Simulation/LargerSamples" else
      if (file.exists("LargerSamples/R/Load.R")) "LargerSamples" else "."
  Path <- normalizePath(Path, winslash = "/", mustWork = TRUE)
  source(file.path(Path, "R", "Load.R"), local = .GlobalEnv)
  LoadSimulation(Path, Compile = FALSE)
  Plan <- ReadSimulationPlan(Path)
  ResultsPath <- SimulationResultsPath(Path)
  Manifest <- readRDS(file.path(ResultsPath, "StudyManifest.rds"))
  VerifyStudy(Path, Plan, Manifest, ReportOnly = TRUE)
  Progress <- read.csv(file.path(ResultsPath, "Progress.csv"))
  Assert(all(Progress$Pending == 0), "Refresh the report after all planned datasets finish.")
  Assert(length(unique(Progress$Completed)) == 1, "The scenarios have different replicate counts.")
  Replicates <- unique(Progress$Completed)
  CurrentRun <- jsonlite::fromJSON(file.path(ResultsPath, "CurrentRun.json"))
  Assert(identical(CurrentRun$Status, "Complete") &&
    CurrentRun$ReplicatesPerScenario == Replicates && CurrentRun$Completed == sum(Progress$Completed),
    "The current run and report disagree; finish the run and refresh the report.")
  Assert(Plan$VisitCount == 3, "These tables expect three visits.")
  ScenarioIds <- vapply(Plan$CoreScenarios, function(Scenario) Scenario$Id, character(1))
  Assert(identical(ScenarioIds, c("C1", "M1", "M2", "M3")), "Unexpected simulation scenarios.")
  Inputs <- c("ParameterPerformance.csv", "ParameterEstimates.csv", "MatchedPerformance.csv",
    "CompleteDataPerformance.csv", "AssumptionPerformance.csv", "PopulationTruth.csv", "Progress.csv", "Fits.csv")
  InputHashes <- setNames(vapply(file.path(ResultsPath, Inputs), FileHash, character(1)), Inputs)
  Parameters <- read.csv(file.path(ResultsPath, "ParameterPerformance.csv"))
  Estimates <- read.csv(file.path(ResultsPath, "ParameterEstimates.csv"))
  Matched <- read.csv(file.path(ResultsPath, "MatchedPerformance.csv"))
  Benchmarks <- read.csv(file.path(ResultsPath, "CompleteDataPerformance.csv"))
  Assumptions <- read.csv(file.path(ResultsPath, "AssumptionPerformance.csv"))
  Truth <- read.csv(file.path(ResultsPath, "PopulationTruth.csv"))
  Fits <- read.csv(file.path(ResultsPath, "Fits.csv"))
  Assert(nrow(Fits) == sum(Progress$Completed), "Fit diagnostics and completed counts disagree.")
  Rules <- RbmiRules(Plan$BorrowingWeights)
  Assert(nrow(Rules) == 9, "These tables expect the nine planned borrowing rules.")
  Names <- c(paste0("ZeroInterceptVisit", 1 : 3), "ZeroTreatment", "ZeroBaseline",
    paste0("PositiveInterceptVisit", 1 : 3), "PositiveTreatment", "PositiveBaseline",
    paste0("GammaShapeVisit", 1 : 3), "AdjacentCorrelation")
  Labels <- c(paste("Intercept", 1 : 3), "Treatment", "Baseline",
    paste("Intercept", 1 : 3), "Treatment", "Baseline", "$k_1$", "$k_2$", "$k_3$", "$\\rho$")
  ParameterTruth <- vapply(Names, function(Name) {
    Values <- unique(Estimates$Truth[Estimates$Parameter == Name])
    Assert(length(Values) == 1 && is.finite(Values), "A parameter truth is unavailable or inconsistent.")
    Values
  }, numeric(1))
  Parameters <- Parameters[Parameters$Parameter %in% Names, ]
  Assert(nrow(Parameters) == length(Names)*length(ScenarioIds) &&
    !anyDuplicated(Parameters[, c("Scenario", "Parameter")]), "Parameter summaries are incomplete.")
  Assert(nrow(Matched) == length(ScenarioIds)*nrow(Rules) &&
    !anyDuplicated(Matched[, c("Scenario", "Rule")]), "Imputation summaries are incomplete.")
  Assert(all(Parameters$Attempted == Replicates) && all(Matched$Attempted == Replicates),
    "The summaries have different replicate counts; refresh the report.")
  Assert(all(Parameters$Finite == Replicates) && all(Matched$Finite == Replicates),
    "Some estimates are unavailable; add explicit row denominators before exporting.")
  Parameters <- Parameters[order(match(Parameters$Scenario, ScenarioIds),
    match(Parameters$Parameter, Names)), ]
  Parameters$Truth <- unname(ParameterTruth[Parameters$Parameter])
  Parameters$CoveragePercent <- 100*Parameters$Coverage
  Matched <- merge(Matched, Truth, by = c("Scenario", "Rule"), sort = FALSE,
    suffixes = c("", "FromTruth"))
  Matched <- merge(Matched, Rules, by = "Rule", sort = FALSE)
  Matched <- Matched[order(match(Matched$Scenario, ScenarioIds), match(Matched$Rule, Rules$Rule)), ]
  Matched$AverageSe <- sqrt(Matched$MeanEstimatedVariance)
  Matched$CoveragePercent <- 100*Matched$Coverage
  BenchmarkIndex <- match(paste(Matched$Scenario, Matched$Rule),
    paste(Benchmarks$Scenario, Benchmarks$Rule))
  Assert(!anyNA(BenchmarkIndex), "A benchmark using complete outcomes is missing.")
  Matched$CompleteDataBias <- Benchmarks$Bias[BenchmarkIndex]
  Matched$CompleteDataCoveragePercent <- 100*Benchmarks$Coverage[BenchmarkIndex]
  Format <- function(Value, Digits = 3) {
    Assert(all(is.finite(Value)), "A table contains a nonfinite value.")
    Value[abs(Value) < 0.5*10^(-Digits)] <- 0
    formatC(Value, digits = Digits, format = "f", decimal.mark = ".")
  }
  Row <- function(Cells) paste0(paste(Cells, collapse = " & "), " \\\\")
  ScenarioHeader <- function(Id) {
    Scenario <- Plan$CoreScenarios[[match(Id, ScenarioIds)]]
    paste0(Id, ": $n=", Scenario$SampleSize, "$; ",
      Format(100*tail(Scenario$CumulativeMissingnessTargets, 1), 0),
      "\\% missing at the final visit")
  }
  GeneratedComment <- c("% Generated by Simulation/LargerSamples/03ExportTables.R. Do not edit this file by hand.",
    paste0("% Frozen study: ", Manifest$Key),
    paste0("% Replicates per scenario: ", Replicates))
  SampleHeaders <- vapply(Plan$CoreScenarios, function(Scenario)
    paste0("\\multicolumn{3}{c}{\\TableHeading{$n=", Scenario$SampleSize, "$}}"), character(1))
  MissingHeaders <- vapply(Plan$CoreScenarios, function(Scenario) {
    Missing <- 100*tail(Scenario$CumulativeMissingnessTargets, 1)
    Label <- if (Missing == 0) "Complete follow-up" else paste0(Format(Missing, 0), "\\% missing")
    paste0("\\multicolumn{3}{c}{\\TableHeading{", Label, "}}")
  }, character(1))
  ParameterLines <- c(GeneratedComment,
    "\\begin{landscape}", "\\begin{table}[p]",
    paste0("\\caption{Recovery of the 14 model parameters across ", Replicates,
      " simulated datasets per scenario.}"),
    "\\label{tab:simulationparameters}", "\\centering", "\\begingroup", "\\small",
    "\\setstretch{1}", "\\setlength{\\tabcolsep}{3pt}", "\\renewcommand{\\arraystretch}{1.12}",
    "\\begin{tabular}{@{}lS[table-format=-1.3]*{4}{S[table-format=-1.3]S[table-format=1.3]S[table-format=2.1]}@{}}",
    "\\toprule",
    Row(c("", "", paste0("\\multicolumn{3}{c}{\\TableHeading{", ScenarioIds, "}}"))),
    Row(c("", "", SampleHeaders)),
    Row(c("", "", MissingHeaders)),
    "\\cmidrule(lr){3-5}\\cmidrule(lr){6-8}\\cmidrule(lr){9-11}\\cmidrule(l){12-14}",
    Row(c("{\\TableHeading{Parameter}}", "{\\TableHeading{Truth}}",
      rep(c("{\\TableHeading{Bias}}", "{\\TableHeading{ESD}}", "{\\TableHeading{CP (\\%)}}"), 4))), "\\midrule")
  GroupStarts <- c(1, 6, 11, 14)
  GroupLabels <- c("Zero probability", "Positive mean", "Gamma shape", "Dependence")
  for (Index in seq_along(Names)) {
    if (Index %in% GroupStarts) {
      if (Index > 1) ParameterLines <- c(ParameterLines, "\\addlinespace[3pt]")
      ParameterLines <- c(ParameterLines, paste0("\\multicolumn{14}{@{}l}{\\textit{",
        GroupLabels[match(Index, GroupStarts)], "}}\\\\"))
    }
    Cells <- c(Labels[Index], Format(ParameterTruth[Index]))
    for (Id in ScenarioIds) {
      Value <- Parameters[Parameters$Scenario == Id & Parameters$Parameter == Names[Index], ]
      Cells <- c(Cells, Format(Value$Bias), Format(Value$EmpiricalSd), Format(Value$CoveragePercent, 1))
    }
    ParameterLines <- c(ParameterLines, Row(Cells))
  }
  ParameterNotes <- paste0("Bias is the mean posterior estimate minus the generating value; ESD is the empirical ",
    "standard deviation of those estimates; CP is coverage of the equal-tailed 95\\% posterior interval. ",
    "The regression coefficients retain their logit or log scales; $k_j$ and $\\rho$ are shown on their model scales. ",
    "Missingness percentages in the headings are population targets at the final visit. ",
    "The Monte Carlo standard error of bias is ESD$/\\sqrt{", Replicates, "}$. ",
    "For coverage proportion $\\widehat p$, it is $100\\sqrt{\\widehat p\\left(1-\\widehat p\\right)/", Replicates,
    "}$ percentage points, approximately ", Format(100*sqrt(.95*.05/Replicates), 1), " at 95\\% coverage.")
  ParameterLines <- c(ParameterLines, "\\bottomrule", "\\end{tabular}", "\\par\\smallskip",
    "\\begin{minipage}{\\linewidth}", "\\footnotesize\\justifying", ParameterNotes,
    "\\end{minipage}", "\\endgroup", "\\end{table}", "\\end{landscape}")
  AnalysisLines <- c(GeneratedComment,
    "\\begin{table}[p]",
    paste0("\\caption{Point estimation of the final mean contrast under matched generating and imputation assumptions, with ",
      Replicates, " datasets per scenario.}"),
    "\\label{tab:simulationimputation}", "\\centering", "\\begingroup", "\\small",
    "\\setstretch{1}", "\\setlength{\\tabcolsep}{5pt}", "\\renewcommand{\\arraystretch}{1.04}",
    "\\begin{tabular}{@{}S[table-format=1.1]S[table-format=1.1]S[table-format=-1.3]S[table-format=-1.3]@{\\,(}S[table-format=1.3]@{)\\hspace{9pt}}S[table-format=1.3]S[table-format=1.3]@{}}",
    "\\toprule",
    Row(c("{\\TableHeading{$\\omega_0$}}", "{\\TableHeading{$\\omega_+$}}", "{\\TableHeading{Truth}}", "\\multicolumn{2}{c}{\\TableHeading{Bias (MCSE)}}", "{\\TableHeading{ESD}}", "{\\TableHeading{RMSE}}")),
    "\\midrule")
  CoverageLines <- c(GeneratedComment,
    "\\begin{table}[p]",
    paste0("\\caption{Calibration of uncertainty for the final mean contrast under matched generating and imputation assumptions, with ",
      Replicates, " datasets per scenario.}"),
    "\\label{tab:simulationcoverage}", "\\centering", "\\begingroup", "\\small",
    "\\setstretch{1}", "\\setlength{\\tabcolsep}{5pt}", "\\renewcommand{\\arraystretch}{1.04}",
    "\\begin{tabular}{@{}S[table-format=1.1]S[table-format=1.1]S[table-format=1.3]S[table-format=1.3]S[table-format=1.2]S[table-format=3.1]S[table-format=3.1]@{}}",
    "\\toprule",
    Row(c(rep("", 6), "{\\TableHeading{Benchmark}}")),
    Row(c("{\\TableHeading{$\\omega_0$}}", "{\\TableHeading{$\\omega_+$}}", "{\\TableHeading{ESD}}", "{\\TableHeading{ASE}}", "{\\TableHeading{VR}}", "{\\TableHeading{CP (\\%)}}", "{\\TableHeading{CP (\\%)}}")),
    "\\midrule")
  Displayed <- list()
  for (Id in ScenarioIds) {
    Header <- paste0("\\multicolumn{7}{@{}l}{\\TableHeading{", ScenarioHeader(Id), "}}\\\\")
    AnalysisLines <- c(AnalysisLines, Header)
    CoverageLines <- c(CoverageLines, Header)
    Values <- Matched[Matched$Scenario == Id, ]
    if (Id == "C1") {
      for (Name in c("Truth", "Bias", "EmpiricalSd", "RootMeanSquaredError", "MeanEstimatedVariance", "Coverage"))
        Assert(diff(range(Values[[Name]])) < 1e-10, "Complete follow-up does not give identical rules.")
      Values <- Values[Values$Rule == "Continuation", ]
    }
    for (Index in seq_len(nrow(Values))) {
      Value <- Values[Index, ]
      Weights <- if (Id == "C1") c("{All}", "{All}") else
        c(Format(Value$ZeroWeight, 1), Format(Value$PositiveWeight, 1))
      AnalysisLines <- c(AnalysisLines, Row(c(Weights, Format(Value$Truth), Format(Value$Bias),
        Format(Value$BiasMcse), Format(Value$EmpiricalSd), Format(Value$RootMeanSquaredError))))
      CoverageLines <- c(CoverageLines, Row(c(Weights, Format(Value$EmpiricalSd),
        Format(Value$AverageSe), Format(Value$VarianceRatio, 2), Format(Value$CoveragePercent, 1),
        Format(Value$CompleteDataCoveragePercent, 1))))
    }
    Displayed[[Id]] <- Values
    if (Id != tail(ScenarioIds, 1)) {
      AnalysisLines <- c(AnalysisLines, "\\addlinespace[5pt]")
      CoverageLines <- c(CoverageLines, "\\addlinespace[5pt]")
    }
  }
  AnalysisNotes <- paste0("The weights $\\left(\\omega_0,\\omega_+\\right)$ govern reference borrowing for the zero and positive ",
    "components. $\\left(0,0\\right)$ retains the treatment effects, $\\left(1,0\\right)$ removes the contrast in zero probability, ",
    "$\\left(0,1\\right)$ removes the contrast in positive means, and $\\left(1,1\\right)$ is jump to reference. All nine rules coincide in C1. ",
    "Truth is the population mean contrast, averaging over baseline covariates, outcomes, and dropout. ",
    "MCSE is the Monte Carlo standard error of bias; ESD is the empirical standard deviation of pooled estimates; ",
    "RMSE is their root mean squared error relative to the population truth. ",
    "Reference borrowing applies only after dropout. Missingness percentages are population targets. ",
    "Coverage and variance comparisons are reported in Supporting Information \\autoref{supp:simulationuncertainty}. ",
    "All ", sum(Progress$Completed), " fits contribute; ", sum(Progress$Flagged), " were flagged and ",
    sum(Progress$Failed), " failed.")
  CoverageNotes <- paste0("The borrowing weights and scenarios are defined in \\autoref{tab:simulationimputation}. ",
    "ESD is the empirical standard deviation of pooled estimates; ASE is the square root of the mean estimated variance; ",
    "VR is the mean estimated variance divided by ESD$^2$. CP is empirical coverage of the 95\\% Rubin interval, ",
    "using HC3 variances augmented for empirical covariate standardization and Barnard--Rubin degrees of freedom. Benchmark CP applies the same final visit regression ",
    "to the corresponding complete outcomes, including those concealed by dropout. ",
    "For an estimated coverage proportion $\\widehat p$, the Monte Carlo standard error is ",
    "$100\\sqrt{\\widehat p\\left(1-\\widehat p\\right)/", Replicates,
    "}$ percentage points, approximately ", Format(100*sqrt(.95*.05/Replicates), 1),
    " at 95\\% coverage. Coverage of 100\\% means that all ", Replicates,
    " intervals contained the target in this finite simulation; it does not establish population coverage of 100\\%.")
  CloseTable <- function(Lines, Notes) c(Lines, "\\bottomrule", "\\end{tabular}", "\\par\\smallskip",
    "\\begin{minipage}{\\linewidth}", "\\footnotesize\\justifying", Notes,
    "\\end{minipage}", "\\endgroup", "\\end{table}")
  AnalysisLines <- CloseTable(AnalysisLines, AnalysisNotes)
  CoverageLines <- CloseTable(CoverageLines, CoverageNotes)

  # Numerical text is generated from the same summaries as the tables.
  # Alphabetic command names are necessary for ordinary TeX control sequences.
  Numbers <- data.frame(Macro = character(), Value = numeric(), Digits = numeric())
  AddNumber <- function(Name, Value, Digits = 3) {
    Assert(length(Value) == 1 && is.finite(Value), "A manuscript number is unavailable.")
    Assert(grepl("^[A-Za-z]+$", Name) && !Name %in% Numbers$Macro, "A manuscript command name is invalid.")
    Numbers[nrow(Numbers) + 1, ] <<- list(Name, Value, Digits)
  }
  AddRange <- function(Prefix, Values, Suffix = "", Digits = 3) {
    AddNumber(paste0(Prefix, "Min", Suffix), min(Values), Digits)
    AddNumber(paste0(Prefix, "Max", Suffix), max(Values), Digits)
  }
  AddNumber("SimReplicates", Replicates, 0)
  AddNumber("SimTotalFits", sum(Progress$Completed), 0)
  AddNumber("SimFlaggedFits", sum(Progress$Flagged), 0)
  AddNumber("SimFailedFits", sum(Progress$Failed), 0)
  AddNumber("SimMaxRhat", max(Fits$MaxRhat))
  AddNumber("SimMinBulkEss", min(Fits$MinBulkEss), 0)
  AddNumber("SimMinTailEss", min(Fits$MinTailEss), 0)
  AddRange("SimRetainedDraws", Fits$DrawsPerChain, Digits = 0)
  AddNumber("SimPointMcseFractionMax", 100*max(Fits$MaximumEstimateMcseFraction), 1)
  AddNumber("SimVarianceMcseFractionMax", 100*max(Fits$MaximumVarianceMcseFraction), 1)
  AddRange("SimParameterCoverage", Parameters$CoveragePercent, Digits = 1)
  AddNumber("SimParameterCoverageBelowNinety", sum(Parameters$CoveragePercent < 90), 0)
  LowRho <- Parameters$Scenario == "M2" & Parameters$Parameter == "AdjacentCorrelation"
  LowIntercept <- Parameters$Scenario == "M3" & Parameters$Parameter == "ZeroInterceptVisit3"
  AddNumber("SimRhoCoverageMtwo", Parameters$CoveragePercent[LowRho], 1)
  AddNumber("SimZeroInterceptCoverageMthree", Parameters$CoveragePercent[LowIntercept], 1)
  AddRange("SimRecoveryUsualCoverage", Parameters$CoveragePercent[!LowRho & !LowIntercept], Digits = 1)
  AddRange("SimCompleteCoverage", 100*Benchmarks$Coverage, Digits = 1)
  AddRange("SimIncompleteCoverage", Matched$CoveragePercent[Matched$Scenario != "C1"], Digits = 1)
  AddRange("SimJtwoRVarianceRatio", Matched$VarianceRatio[Matched$Scenario != "C1" &
    Matched$Rule == "JumpToReference"], Digits = 2)
  AddNumber("SimCoverageMcseNominal", 100*sqrt(.95*.05/Replicates), 1)
  AddRange("SimCompleteBenchmarkBias", Benchmarks$Bias)
  AddNumber("SimMatchedBiasAbsoluteMax", max(abs(Matched$Bias)))
  AddNumber("SimTruthMcseMax", max(Truth$TruthMcse), 6)
  Suffixes <- c("Cone", "Mone", "Mtwo", "Mthree")
  for (Index in seq_along(ScenarioIds)) {
    Values <- Matched[Matched$Scenario == ScenarioIds[Index], ]
    Suffix <- Suffixes[Index]
    AddRange("SimBias", Values$Bias, Suffix)
    AddRange("SimBiasMcse", Values$BiasMcse, Suffix)
    AddRange("SimEsd", Values$EmpiricalSd, Suffix)
    AddRange("SimRmse", Values$RootMeanSquaredError, Suffix)
    for (Rule in c("Continuation", "JumpToReference")) {
      Value <- Values[Values$Rule == Rule, ]
      Prefix <- if (Rule == "Continuation") "SimContinuation" else "SimJtwoR"
      AddNumber(paste0(Prefix, "Bias", Suffix), Value$Bias)
      AddNumber(paste0(Prefix, "BiasMcse", Suffix), Value$BiasMcse)
    }
  }
  AddNumber("SimTruthContinuation", Truth$Truth[Truth$Scenario == "C1" & Truth$Rule == "Continuation"])
  AddNumber("SimTruthJtwoRMone", Truth$Truth[Truth$Scenario == "M1" & Truth$Rule == "JumpToReference"])
  AddNumber("SimTruthJtwoRMthree", Truth$Truth[Truth$Scenario == "M3" & Truth$Rule == "JumpToReference"])
  for (Index in 3 : 4) {
    Id <- ScenarioIds[Index]
    Suffix <- Suffixes[Index]
    Borrowing <- Assumptions[Assumptions$Scenario == Id & Assumptions$GeneratingRule == "Continuation" &
      Assumptions$Rule == "JumpToReference", ]
    Continuation <- Assumptions[Assumptions$Scenario == Id & Assumptions$GeneratingRule == "JumpToReference" &
      Assumptions$Rule == "Continuation", ]
    Assert(nrow(Borrowing) == 1 && nrow(Continuation) == 1 &&
      Borrowing$Finite == Replicates && Continuation$Finite == Replicates,
      "Assumption comparisons are incomplete.")
    AddNumber(paste0("SimBorrowingWhenContinuationBias", Suffix), Borrowing$Bias)
    AddNumber(paste0("SimBorrowingWhenContinuationMcse", Suffix), Borrowing$BiasMcse)
    AddNumber(paste0("SimContinuationWhenBorrowingBias", Suffix), Continuation$Bias)
    AddNumber(paste0("SimContinuationWhenBorrowingMcse", Suffix), Continuation$BiasMcse)
  }
  NumberLines <- c(GeneratedComment, vapply(seq_len(nrow(Numbers)), function(Index)
    paste0("\\newcommand{\\", Numbers$Macro[Index], "}{", Format(Numbers$Value[Index], Numbers$Digits[Index]), "}"),
    character(1)))
  Output <- file.path(ResultsPath, "Tables")
  dir.create(Output, recursive = TRUE, showWarnings = FALSE)
  WriteOutput <- function(Lines, Name) {
    File <- file.path(Output, Name)
    Text <- charToRaw(paste0(paste(Lines, collapse = "\n"), "\n"))
    if (file.exists(File)) {
      Previous <- readBin(File, "raw", n = file.info(File)$size)
      if (!identical(Previous, Text)) {
        BackupDirectory <- file.path(Output, "Previous")
        dir.create(BackupDirectory, recursive = TRUE, showWarnings = FALSE)
        Backup <- tempfile(pattern = paste0(Name, "."), tmpdir = BackupDirectory)
        Assert(file.copy(File, Backup, overwrite = FALSE), "Could not preserve the previous table.")
      }
    }
    writeBin(Text, File)
    File
  }
  Files <- c(WriteOutput(ParameterLines, "01ParameterRecovery.tex"),
    WriteOutput(AnalysisLines, "02ImputationAnalysis.tex"),
    WriteOutput(CoverageLines, "03ImputationCoverage.tex"),
    WriteOutput(NumberLines, "04SimulationNumbers.tex"))
  SaveTable(Parameters, file.path(Output, "01ParameterRecovery.csv"))
  Displayed <- do.call(rbind, Displayed)
  SaveTable(Displayed, file.path(Output, "02ImputationAnalysis.csv"))
  SaveTable(Displayed[, c("Scenario", "Rule", "ZeroWeight", "PositiveWeight", "Attempted", "Finite",
    "EmpiricalSd", "AverageSe", "VarianceRatio", "CoveragePercent", "CoverageMcse",
    "CoverageIntervalLower", "CoverageIntervalUpper", "MeanIntervalWidth", "CompleteDataCoveragePercent")],
    file.path(Output, "03ImputationCoverage.csv"))
  SaveTable(Numbers, file.path(Output, "04SimulationNumbers.csv"))
  Files <- c(Files, file.path(Output, c("01ParameterRecovery.csv", "02ImputationAnalysis.csv",
    "03ImputationCoverage.csv", "04SimulationNumbers.csv")))
  Provenance <- list(StudyKey = Manifest$Key, ReplicatesPerScenario = Replicates,
    CreatedUtc = format(Sys.time(), tz = "UTC", usetz = TRUE),
    ParameterSelection = Names, SourceHashes = as.list(InputHashes),
    ExporterHash = FileHash(file.path(Path, "03ExportTables.R")),
    TableHashes = as.list(setNames(vapply(Files, FileHash, character(1)), basename(Files))),
    OutputDirectory = "Results/Tables")
  jsonlite::write_json(Provenance, file.path(Output, "TableProvenance.json"), pretty = TRUE, auto_unbox = TRUE)
  VerifyStudy(Path, Plan, Manifest, ReportOnly = TRUE)
  message("Created three tables and numerical text in Results/Tables.")
})
